package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import com.example.audio.TacticalAudioEngine
import com.example.engine.TacticalMatchEngine
import com.example.model.ArenaMapId
import com.example.model.BotDifficulty
import com.example.model.GameMode
import com.example.model.TeamSide
import com.example.model.WeaponId
import com.example.model.WeaponSlot
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `app name and lobby deploy match journey`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Strike Tactical 2", context.getString(R.string.app_name))

        composeTestRule.waitForIdle()
        composeTestRule.onNodeWithTag("deploy_match_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("deploy_match_button").performClick()
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("match_screen_root").assertIsDisplayed()
        composeTestRule.onNodeWithTag("buy_menu_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("buy_menu_button").performClick()
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("buy_close_button").assertIsDisplayed()
        composeTestRule.onNodeWithTag("buy_close_button").performClick()
        composeTestRule.waitForIdle()
    }

    @Test
    fun `tactical match engine supports buying weapons and simulation step`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val audio = TacticalAudioEngine(context).apply {
            soundEnabled = false
            hapticsEnabled = false
        }
        val engine = TacticalMatchEngine(audio)
        engine.startNewMatch(
            mapId = ArenaMapId.DUST_ARENA,
            mode = GameMode.DEATHMATCH,
            playerTeam = TeamSide.T,
            botDifficulty = BotDifficulty.MASTER_GUARDIAN
        )

        val boughtAk = engine.buyWeapon(WeaponId.AK_47)
        assertTrue(boughtAk)
        assertEquals(WeaponSlot.PRIMARY, engine.hudState.value.activeSlot)

        engine.stepSimulation(0.016f, System.currentTimeMillis() + 50L, 60)
        assertTrue(engine.hudState.value.isInMatch)
        assertEquals(5, engine.hudState.value.ctAliveCount)
    }
}

package com.example.ui.hud

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.GameMode
import com.example.model.MatchHudState
import com.example.model.RoundPhase
import com.example.model.ScoreboardEntry
import com.example.model.TeamSide
import com.example.model.WeaponCategory
import com.example.model.WeaponId
import com.example.ui.theme.AmberStrike
import com.example.ui.theme.CashEmerald
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CtSteelCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SlateOutline
import com.example.ui.theme.SlateSurface
import com.example.ui.theme.SlateSurfaceElevated
import com.example.ui.theme.TerroristOchre

@Composable
fun Cs2BuyMenuOverlay(
    hudState: MatchHudState,
    preferredCtRifle: WeaponId,
    onBuyWeapon: (WeaponId) -> Unit,
    onBuyArmor: (Boolean) -> Unit,
    onBuyDefuseKit: () -> Unit,
    onRebuy: () -> Unit,
    onClose: () -> Unit
) {
    var selectedCategory by remember { mutableStateOf(WeaponCategory.RIFLE) }
    val team = hudState.playerTeam
    val isFree = hudState.gameMode == GameMode.DEATHMATCH

    val availableWeapons = remember(selectedCategory, team, preferredCtRifle) {
        WeaponId.entries.filter { w ->
            w.category == selectedCategory &&
                w != WeaponId.KNIFE &&
                w != WeaponId.C4_EXPLOSIVE &&
                (w.teamRestriction == null || w.teamRestriction == team) &&
                // Show user's equipped M4 variant + AWP
                !(team == TeamSide.CT && selectedCategory == WeaponCategory.RIFLE &&
                    (w == WeaponId.M4A1_S || w == WeaponId.M4A4) && w != preferredCtRifle)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg.copy(alpha = 0.86f))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 720.dp),
            color = SlateSurface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, AmberStrike.copy(alpha = 0.6f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "CS2 ARMORY BUY MENU",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                        Text(
                            text = if (isFree) "DEATHMATCH FREE LOADOUT" else "AVAILABLE FUNDS: $${hudState.cash}",
                            style = MaterialTheme.typography.labelMedium,
                            color = CashEmerald
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = onRebuy,
                            border = BorderStroke(1.dp, CashEmerald),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("buy_rebuy_button")
                        ) {
                            Text(stringResource(R.string.hud_rebuy), color = CashEmerald)
                        }
                        Button(
                            onClick = onClose,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AmberStrike,
                                contentColor = ObsidianBg
                            ),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("buy_close_button")
                        ) {
                            Text(stringResource(R.string.hud_close))
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Category Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    WeaponCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat.label) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AmberStrike,
                                selectedLabelColor = ObsidianBg
                            ),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("buy_cat_${cat.name.lowercase()}")
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                // Gear Quick Row when in Utility category (Kevlar, Helmet, Defuse Kit)
                if (selectedCategory == WeaponCategory.UTILITY) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        GearBuyCard(
                            modifier = Modifier.weight(1f),
                            title = "Kevlar Vest",
                            costText = if (isFree) "$0" else "$650",
                            owned = hudState.playerArmor == 100,
                            affordable = isFree || hudState.cash >= 650,
                            onClick = { onBuyArmor(false) }
                        )
                        GearBuyCard(
                            modifier = Modifier.weight(1f),
                            title = "Vest + Helmet",
                            costText = if (isFree) "$0" else "$1000",
                            owned = hudState.hasHelmet && hudState.playerArmor == 100,
                            affordable = isFree || hudState.cash >= 1000,
                            onClick = { onBuyArmor(true) }
                        )
                        if (team == TeamSide.CT) {
                            GearBuyCard(
                                modifier = Modifier.weight(1f),
                                title = "Defuse Kit",
                                costText = if (isFree) "$0" else "$400",
                                owned = hudState.hasDefuseKit,
                                affordable = isFree || hudState.cash >= 400,
                                onClick = onBuyDefuseKit
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                }

                // Weapon Grid
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 152.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 4.dp),
                    modifier = Modifier.height(220.dp)
                ) {
                    items(availableWeapons) { weapon ->
                        val owned = hudState.equippedWeapons[weapon.slot]?.weaponId == weapon
                        val cost = if (isFree) 0 else weapon.price
                        val affordable = hudState.cash >= cost
                        Card(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable(enabled = affordable && !owned) { onBuyWeapon(weapon) }
                                .testTag("buy_item_${weapon.name.lowercase()}"),
                            colors = CardDefaults.cardColors(
                                containerColor = when {
                                    owned -> CtSteelCyan.copy(alpha = 0.20f)
                                    affordable -> SlateSurfaceElevated
                                    else -> ObsidianBg.copy(alpha = 0.5f)
                                }
                            ),
                            border = BorderStroke(
                                width = 1.dp,
                                color = when {
                                    owned -> CtSteelCyan
                                    affordable -> CashEmerald.copy(alpha = 0.65f)
                                    else -> SlateOutline.copy(alpha = 0.4f)
                                }
                            )
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = weapon.displayName,
                                    style = MaterialTheme.typography.titleLarge,
                                    color = if (affordable || owned) Color.White else Color.Gray
                                )
                                Text(
                                    text = "DMG ${weapon.baseDamage} • PEN ${(weapon.armorPenetration * 100).toInt()}%",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = if (owned) "EQUIPPED" else "$$cost",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = when {
                                        owned -> CtSteelCyan
                                        affordable -> CashEmerald
                                        else -> CrimsonAlert
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GearBuyCard(
    modifier: Modifier = Modifier,
    title: String,
    costText: String,
    owned: Boolean,
    affordable: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(enabled = affordable && !owned, onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (owned) CtSteelCyan.copy(alpha = 0.2f) else SlateSurfaceElevated
        ),
        border = BorderStroke(1.dp, if (owned) CtSteelCyan else CashEmerald.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(text = title, style = MaterialTheme.typography.titleMedium, color = Color.White)
            Text(
                text = if (owned) "OWNED" else costText,
                style = MaterialTheme.typography.labelMedium,
                color = if (owned) CtSteelCyan else CashEmerald
            )
        }
    }
}

@Composable
fun ScoreboardPauseOverlay(
    hudState: MatchHudState,
    onResume: () -> Unit,
    onPlayAgain: () -> Unit,
    onToggleOrientation: () -> Unit,
    onLeaveMatch: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg.copy(alpha = 0.88f))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 720.dp),
            color = SlateSurface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, SlateOutline)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${stringResource(R.string.hud_scoreboard)} — ROUND ${hudState.roundNumber}",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                        Text(
                            text = "CT ${hudState.ctScore}  :  ${hudState.tScore} T",
                            style = MaterialTheme.typography.labelMedium,
                            color = AmberStrike
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = onToggleOrientation,
                            modifier = Modifier.height(48.dp)
                        ) {
                            Text("Rotate")
                        }
                        if (hudState.phase == RoundPhase.MATCH_OVER) {
                            Button(
                                onClick = onPlayAgain,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AmberStrike,
                                    contentColor = ObsidianBg
                                ),
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("play_again_button")
                            ) {
                                Text(stringResource(R.string.hud_play_again))
                            }
                        } else {
                            Button(
                                onClick = onResume,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AmberStrike,
                                    contentColor = ObsidianBg
                                ),
                                modifier = Modifier
                                    .height(48.dp)
                                    .testTag("resume_match_button")
                            ) {
                                Text(stringResource(R.string.hud_resume_match))
                            }
                        }
                    }
                }

                Spacer(Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier.height(240.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    item {
                        Text("COUNTER-TERRORISTS", style = MaterialTheme.typography.labelSmall, color = CtSteelCyan)
                    }
                    items(hudState.scoreboard.filter { it.team == TeamSide.CT }) { row ->
                        ScoreboardOperatorRow(row, CtSteelCyan)
                    }
                    item {
                        Spacer(Modifier.height(6.dp))
                        Text("TERRORISTS", style = MaterialTheme.typography.labelSmall, color = TerroristOchre)
                    }
                    items(hudState.scoreboard.filter { it.team == TeamSide.T }) { row ->
                        ScoreboardOperatorRow(row, TerroristOchre)
                    }
                }

                Spacer(Modifier.height(12.dp))

                OutlinedButton(
                    onClick = onLeaveMatch,
                    border = BorderStroke(1.dp, CrimsonAlert),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CrimsonAlert),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("leave_match_button")
                ) {
                    Text(stringResource(R.string.hud_leave_match))
                }
            }
        }
    }
}

@Composable
private fun ScoreboardOperatorRow(row: ScoreboardEntry, accent: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                if (row.isLocalPlayer) accent.copy(alpha = 0.16f) else SlateSurfaceElevated,
                RoundedCornerShape(8.dp)
            )
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = row.name,
                style = MaterialTheme.typography.titleMedium,
                color = if (row.isAlive) Color.White else Color.Gray
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = if (row.isAlive) "${row.hp} HP" else "DEAD",
                style = MaterialTheme.typography.labelSmall,
                color = if (row.isAlive) CashEmerald else CrimsonAlert
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(text = "K ${row.kills}", style = MaterialTheme.typography.labelMedium, color = Color.White)
            Text(text = "D ${row.deaths}", style = MaterialTheme.typography.labelMedium, color = Color.LightGray)
            Text(text = "$${row.cash}", style = MaterialTheme.typography.labelMedium, color = CashEmerald)
        }
    }
}

package com.example.ui.theme

import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val StrikeTacticalColorScheme = darkColorScheme(
    primary = AmberStrike,
    onPrimary = Color(0xFF140D00),
    primaryContainer = AmberStrikeContainer,
    onPrimaryContainer = AmberStrikeBright,
    secondary = CtSteelCyan,
    onSecondary = Color(0xFF001E30),
    secondaryContainer = CtCyanContainer,
    onSecondaryContainer = Color(0xFFBAE6FD),
    tertiary = CashEmerald,
    onTertiary = Color(0xFF002114),
    background = ObsidianBg,
    onBackground = TextPrimary,
    surface = SlateSurface,
    onSurface = TextPrimary,
    surfaceVariant = SlateSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    surfaceContainerHigh = SlateSurfaceHigh,
    outline = SlateOutline,
    error = CrimsonAlert,
    onError = Color.White
)

val TacticalShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = CutCornerShape(topStart = 0.dp, topEnd = 14.dp, bottomEnd = 0.dp, bottomStart = 14.dp),
    extraLarge = RoundedCornerShape(18.dp)
)

@Composable
fun StrikeTacticalTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = StrikeTacticalColorScheme,
        typography = TacticalTypography,
        shapes = TacticalShapes,
        content = content
    )
}

package com.example.ui.lobby

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.CrosshairColorPreset
import com.example.model.PlayerSettings
import com.example.model.WeaponFinish
import com.example.model.WeaponId
import com.example.ui.hud.CrosshairReticleCanvas
import com.example.ui.theme.AmberStrike
import com.example.ui.theme.CashEmerald
import com.example.ui.theme.CtSteelCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SlateOutline
import com.example.ui.theme.SlateSurface
import com.example.ui.theme.SlateSurfaceElevated

@Composable
fun ArmoryLoadoutTab(
    inspectedWeapon: WeaponId,
    settings: PlayerSettings,
    onSelectWeapon: (WeaponId) -> Unit,
    onUpdateSettings: ((PlayerSettings) -> PlayerSettings) -> Unit
) {
    val showcaseWeapons = listOf(
        WeaponId.AK_47,
        WeaponId.M4A1_S,
        WeaponId.M4A4,
        WeaponId.AWP,
        WeaponId.DESERT_EAGLE,
        WeaponId.USP_S,
        WeaponId.GLOCK_18,
        WeaponId.MP9,
        WeaponId.SSG_08
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = stringResource(R.string.armory_title),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = stringResource(R.string.armory_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Weapon horizontal selector
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(showcaseWeapons) { weapon ->
                    val selected = weapon == inspectedWeapon
                    FilterChip(
                        selected = selected,
                        onClick = { onSelectWeapon(weapon) },
                        label = {
                            Text(
                                text = "${weapon.displayName} ($${weapon.price})",
                                style = MaterialTheme.typography.labelLarge
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AmberStrike,
                            selectedLabelColor = ObsidianBg
                        ),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("armory_weapon_${weapon.name.lowercase()}")
                    )
                }
            }
        }

        // Weapon blueprint & ballistics card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SlateSurfaceElevated),
                border = BorderStroke(1.dp, SlateOutline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = inspectedWeapon.category.label.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = AmberStrike
                            )
                            Text(
                                text = inspectedWeapon.displayName,
                                style = MaterialTheme.typography.headlineLarge,
                                color = Color.White
                            )
                        }
                        Text(
                            text = "$${inspectedWeapon.price}",
                            style = MaterialTheme.typography.headlineMedium,
                            color = CashEmerald
                        )
                    }

                    Spacer(Modifier.height(12.dp))

                    // Stylized Weapon Silhouette Preview Canvas with active Finish colors
                    WeaponFinishBlueprintPreview(
                        weapon = inspectedWeapon,
                        finish = settings.globalWeaponFinish
                    )

                    Spacer(Modifier.height(16.dp))

                    StatProgressRow(
                        label = stringResource(R.string.label_damage),
                        valueText = "${inspectedWeapon.baseDamage}",
                        progress = (inspectedWeapon.baseDamage / 115f).coerceIn(0.1f, 1f),
                        barColor = AmberStrike
                    )
                    Spacer(Modifier.height(8.dp))
                    StatProgressRow(
                        label = stringResource(R.string.label_armor_pen),
                        valueText = "${(inspectedWeapon.armorPenetration * 100).toInt()}%",
                        progress = inspectedWeapon.armorPenetration,
                        barColor = CtSteelCyan
                    )
                    Spacer(Modifier.height(8.dp))
                    val rpm = (60_000L / inspectedWeapon.fireIntervalMs.coerceAtLeast(60L)).toInt()
                    StatProgressRow(
                        label = stringResource(R.string.label_fire_rate),
                        valueText = "$rpm RPM",
                        progress = (rpm / 860f).coerceIn(0.08f, 1f),
                        barColor = CashEmerald
                    )
                    Spacer(Modifier.height(8.dp))
                    val controlScore = (1f - (inspectedWeapon.recoilPitchKick / 5f)).coerceIn(0.15f, 0.95f)
                    StatProgressRow(
                        label = stringResource(R.string.label_mobility),
                        valueText = "${(controlScore * 100).toInt()}%",
                        progress = controlScore,
                        barColor = CtSteelCyan
                    )

                    if (inspectedWeapon == WeaponId.M4A1_S || inspectedWeapon == WeaponId.M4A4) {
                        Spacer(Modifier.height(14.dp))
                        val isEquippedCtRifle = settings.preferredCtRifle == inspectedWeapon
                        OutlinedButton(
                            onClick = {
                                onUpdateSettings { it.copy(preferredCtRifle = inspectedWeapon) }
                            },
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = if (isEquippedCtRifle) {
                                    CtSteelCyan.copy(alpha = 0.2f)
                                } else {
                                    Color.Transparent
                                },
                                contentColor = CtSteelCyan
                            ),
                            border = BorderStroke(1.dp, CtSteelCyan),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("equip_ct_rifle_button")
                        ) {
                            Text(
                                text = if (isEquippedCtRifle) {
                                    stringResource(R.string.btn_equip_loadout)
                                } else {
                                    stringResource(R.string.btn_select_loadout)
                                },
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }
                }
            }
        }

        // Weapon Finish Selector
        item {
            SectionTitle(stringResource(R.string.label_finish_style))
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                WeaponFinish.entries.forEach { finish ->
                    val selected = settings.globalWeaponFinish == finish
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                onUpdateSettings { it.copy(globalWeaponFinish = finish) }
                            }
                            .testTag("finish_card_${finish.name.lowercase()}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (selected) {
                                finish.badgeColor.copy(alpha = 0.18f)
                            } else {
                                SlateSurface
                            }
                        ),
                        border = BorderStroke(
                            width = if (selected) 2.dp else 1.dp,
                            color = if (selected) finish.badgeColor else SlateOutline
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(finish.badgeColor, CircleShape)
                                    .border(1.dp, Color.White.copy(alpha = 0.5f), CircleShape)
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = finish.displayName,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WeaponFinishBlueprintPreview(
    weapon: WeaponId,
    finish: WeaponFinish
) {
    val bodyColor = Color(finish.bodyRgb[0], finish.bodyRgb[1], finish.bodyRgb[2])
    val accentColor = Color(finish.accentRgb[0], finish.accentRgb[1], finish.accentRgb[2])

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(110.dp)
            .background(ObsidianBg, RoundedCornerShape(10.dp))
            .border(1.dp, SlateOutline, RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize().padding(18.dp)) {
            val cy = size.height * 0.48f
            val cx = size.width * 0.5f
            val isLong = weapon.slot.name == "PRIMARY"
            val recW = if (isLong) size.width * 0.42f else size.width * 0.24f
            val recH = size.height * 0.28f

            // Receiver
            drawRect(
                color = bodyColor,
                topLeft = Offset(cx - recW * 0.5f, cy - recH * 0.5f),
                size = androidx.compose.ui.geometry.Size(recW, recH)
            )
            // Top accent stripe
            drawRect(
                color = accentColor,
                topLeft = Offset(cx - recW * 0.48f, cy - recH * 0.5f),
                size = androidx.compose.ui.geometry.Size(recW * 0.96f, recH * 0.28f)
            )
            // Barrel / Suppressor
            val barW = if (weapon.isSuppressed || weapon == WeaponId.AWP) size.width * 0.26f else size.width * 0.16f
            drawRect(
                color = Color(0xFF475569),
                topLeft = Offset(cx + recW * 0.5f, cy - recH * 0.22f),
                size = androidx.compose.ui.geometry.Size(barW, recH * 0.34f)
            )
            // Stock + Grip
            if (isLong) {
                drawRect(
                    color = bodyColor.copy(alpha = 0.85f),
                    topLeft = Offset(cx - recW * 0.5f - size.width * 0.15f, cy - recH * 0.35f),
                    size = androidx.compose.ui.geometry.Size(size.width * 0.15f, recH * 0.65f)
                )
                // Magazine
                drawRect(
                    color = accentColor.copy(alpha = 0.85f),
                    topLeft = Offset(cx + recW * 0.05f, cy + recH * 0.5f),
                    size = androidx.compose.ui.geometry.Size(recW * 0.16f, recH * 0.85f)
                )
            }
            if (weapon.hasScope) {
                drawRect(
                    color = Color(0xFF94A3B8),
                    topLeft = Offset(cx - recW * 0.25f, cy - recH * 0.95f),
                    size = androidx.compose.ui.geometry.Size(recW * 0.55f, recH * 0.32f)
                )
            }
        }
        Text(
            text = "${weapon.magSize} / ${weapon.reserveMax} AMMO",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(8.dp)
        )
    }
}

@Composable
private fun StatProgressRow(
    label: String,
    valueText: String,
    progress: Float,
    barColor: Color
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text = valueText, style = MaterialTheme.typography.labelMedium, color = Color.White)
        }
        Spacer(Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { progress },
            color = barColor,
            trackColor = ObsidianBg,
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
        )
    }
}

@Composable
fun CrosshairAndControlsTab(
    settings: PlayerSettings,
    isGyroAvailable: Boolean,
    onUpdateSettings: ((PlayerSettings) -> PlayerSettings) -> Unit
) {
    var previewSpread by remember { mutableFloatStateOf(0f) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = stringResource(R.string.settings_title),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = stringResource(R.string.settings_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        // Live Crosshair Studio Box
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SlateSurfaceElevated),
                border = BorderStroke(1.dp, SlateOutline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SectionTitle(stringResource(R.string.crosshair_preview_label))
                        FilterChip(
                            selected = previewSpread > 0f,
                            onClick = { previewSpread = if (previewSpread > 0f) 0f else 0.7f },
                            label = { Text("Test Recoil Spread") },
                            modifier = Modifier.height(48.dp)
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(136.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .border(1.dp, SlateOutline, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(R.drawable.img_hero_dust_arena),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        CrosshairReticleCanvas(
                            settings = settings,
                            dynamicSpreadRatio = previewSpread,
                            hitMarkerAlpha = 0f,
                            isHeadshot = false
                        )
                    }

                    Spacer(Modifier.height(12.dp))

                    // Color Presets
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        CrosshairColorPreset.entries.forEach { preset ->
                            val selected = settings.crosshairColor == preset
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(preset.color.copy(alpha = 0.25f))
                                    .border(
                                        width = if (selected) 3.dp else 1.dp,
                                        color = if (selected) preset.color else SlateOutline,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        onUpdateSettings { it.copy(crosshairColor = preset) }
                                    }
                                    .testTag("crosshair_color_${preset.name.lowercase()}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .background(preset.color, CircleShape)
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    SettingSliderRow(
                        label = stringResource(R.string.slider_crosshair_size),
                        value = settings.crosshairLengthDp,
                        valueRange = 2f..16f,
                        displayText = "${"%.1f".format(settings.crosshairLengthDp)} dp",
                        onValueChange = { v -> onUpdateSettings { it.copy(crosshairLengthDp = v) } }
                    )
                    SettingSliderRow(
                        label = stringResource(R.string.slider_crosshair_gap),
                        value = settings.crosshairGapDp,
                        valueRange = 0f..12f,
                        displayText = "${"%.1f".format(settings.crosshairGapDp)} dp",
                        onValueChange = { v -> onUpdateSettings { it.copy(crosshairGapDp = v) } }
                    )
                    SettingSliderRow(
                        label = stringResource(R.string.slider_crosshair_thickness),
                        value = settings.crosshairThicknessDp,
                        valueRange = 1f..5f,
                        displayText = "${"%.1f".format(settings.crosshairThicknessDp)} dp",
                        onValueChange = { v -> onUpdateSettings { it.copy(crosshairThicknessDp = v) } }
                    )

                    SettingToggleRow(
                        label = stringResource(R.string.toggle_center_dot),
                        checked = settings.crosshairCenterDot,
                        tag = "toggle_center_dot",
                        onCheckedChange = { c -> onUpdateSettings { it.copy(crosshairCenterDot = c) } }
                    )
                    SettingToggleRow(
                        label = stringResource(R.string.toggle_dynamic_crosshair),
                        checked = settings.dynamicCrosshair,
                        tag = "toggle_dynamic_crosshair",
                        onCheckedChange = { c -> onUpdateSettings { it.copy(dynamicCrosshair = c) } }
                    )
                }
            }
        }

        // Touch, Gyro & Audio Controls
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SlateSurfaceElevated),
                border = BorderStroke(1.dp, SlateOutline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    SectionTitle(stringResource(R.string.section_controls))
                    Spacer(Modifier.height(8.dp))

                    SettingSliderRow(
                        label = stringResource(R.string.slider_touch_sens),
                        value = settings.touchSensitivity,
                        valueRange = 0.3f..2.5f,
                        displayText = "${"%.2f".format(settings.touchSensitivity)}x",
                        onValueChange = { v -> onUpdateSettings { it.copy(touchSensitivity = v) } }
                    )

                    SettingToggleRow(
                        label = stringResource(R.string.toggle_gyro),
                        checked = settings.gyroEnabled && isGyroAvailable,
                        enabled = isGyroAvailable,
                        tag = "toggle_gyro",
                        onCheckedChange = { c -> onUpdateSettings { it.copy(gyroEnabled = c) } }
                    )
                    if (!isGyroAvailable) {
                        Text(
                            text = stringResource(R.string.gyro_unavailable_note),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else if (settings.gyroEnabled) {
                        SettingSliderRow(
                            label = stringResource(R.string.slider_gyro_sens),
                            value = settings.gyroSensitivity,
                            valueRange = 0.3f..3.0f,
                            displayText = "${"%.2f".format(settings.gyroSensitivity)}x",
                            onValueChange = { v -> onUpdateSettings { it.copy(gyroSensitivity = v) } }
                        )
                    }

                    SettingToggleRow(
                        label = stringResource(R.string.toggle_auto_fire),
                        checked = settings.autoFireOnTarget,
                        tag = "toggle_auto_fire",
                        onCheckedChange = { c -> onUpdateSettings { it.copy(autoFireOnTarget = c) } }
                    )
                    SettingToggleRow(
                        label = stringResource(R.string.toggle_left_hand),
                        checked = settings.leftHandedViewmodel,
                        tag = "toggle_left_hand",
                        onCheckedChange = { c -> onUpdateSettings { it.copy(leftHandedViewmodel = c) } }
                    )
                    SettingToggleRow(
                        label = stringResource(R.string.toggle_sound),
                        checked = settings.soundEnabled,
                        tag = "toggle_sound",
                        onCheckedChange = { c -> onUpdateSettings { it.copy(soundEnabled = c) } }
                    )
                    SettingToggleRow(
                        label = stringResource(R.string.toggle_haptics),
                        checked = settings.hapticsEnabled,
                        tag = "toggle_haptics",
                        onCheckedChange = { c -> onUpdateSettings { it.copy(hapticsEnabled = c) } }
                    )

                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { onUpdateSettings { PlayerSettings() } },
                        border = BorderStroke(1.dp, SlateOutline),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("reset_defaults_button")
                    ) {
                        Text(stringResource(R.string.btn_reset_defaults))
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingSliderRow(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    displayText: String,
    onValueChange: (Float) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.bodyMedium, color = Color.White)
            Text(text = displayText, style = MaterialTheme.typography.labelMedium, color = AmberStrike)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            colors = SliderDefaults.colors(
                thumbColor = AmberStrike,
                activeTrackColor = AmberStrike
            )
        )
    }
}

@Composable
private fun SettingToggleRow(
    label: String,
    checked: Boolean,
    tag: String,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = if (enabled) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = ObsidianBg,
                checkedTrackColor = AmberStrike
            ),
            modifier = Modifier.testTag(tag)
        )
    }
}

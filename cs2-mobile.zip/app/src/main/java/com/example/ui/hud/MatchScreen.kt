package com.example.ui.hud

import android.opengl.GLSurfaceView
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import com.example.engine.RenderFrameSnapshot
import com.example.engine.TacticalGlRenderer
import com.example.model.MatchHudState
import com.example.model.PlayerSettings
import com.example.model.RoundPhase
import com.example.model.TeamSide
import com.example.model.WeaponId
import com.example.model.WeaponSlot
import com.example.ui.theme.AmberStrike
import com.example.ui.theme.CashEmerald
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CtSteelCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SlateOutline
import com.example.ui.theme.SlateSurface
import com.example.ui.theme.TerroristOchre
import kotlin.math.sqrt

@Composable
fun MatchScreen(
    hudState: MatchHudState,
    settings: PlayerSettings,
    isBuyMenuOpen: Boolean,
    isScoreboardOpen: Boolean,
    snapshotProvider: () -> RenderFrameSnapshot,
    onMoveJoystick: (Float, Float) -> Unit,
    onTouchLook: (Float, Float) -> Unit,
    onFireHeld: (Boolean) -> Unit,
    onBombActionHeld: (Boolean) -> Unit,
    onJump: () -> Unit,
    onToggleCrouch: () -> Unit,
    onCycleScope: () -> Unit,
    onReload: () -> Unit,
    onInspectWeapon: () -> Unit,
    onSelectSlot: (WeaponSlot) -> Unit,
    onSetBuyMenuOpen: (Boolean) -> Unit,
    onSetScoreboardOpen: (Boolean) -> Unit,
    onBuyWeapon: (WeaponId) -> Unit,
    onBuyArmor: (Boolean) -> Unit,
    onBuyDefuseKit: () -> Unit,
    onRebuy: () -> Unit,
    onDeployNewMatch: () -> Unit,
    onToggleOrientation: () -> Unit,
    onLeaveMatch: () -> Unit
) {
    BackHandler {
        when {
            isBuyMenuOpen -> onSetBuyMenuOpen(false)
            isScoreboardOpen -> onSetScoreboardOpen(false)
            else -> onSetScoreboardOpen(true)
        }
    }

    val isRobolectric = remember { Build.FINGERPRINT.equals("robolectric", ignoreCase = true) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
            .testTag("match_screen_root")
    ) {
        // 1. 3D OpenGL ES 2.0 Viewport
        if (!isRobolectric) {
            AndroidView(
                factory = { ctx ->
                    GLSurfaceView(ctx).apply {
                        setEGLContextClientVersion(2)
                        setRenderer(TacticalGlRenderer(snapshotProvider))
                        renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // 2. Full-Screen Touch Look Surface (Right 62% of screen)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        if (down.position.x >= size.width * 0.36f) {
                            var pointerId = down.id
                            while (true) {
                                val event = awaitPointerEvent()
                                val change = event.changes.firstOrNull { it.id == pointerId }
                                    ?: break
                                if (!change.pressed) break
                                val delta = change.positionChange()
                                if (delta != Offset.Zero) {
                                    onTouchLook(delta.x, delta.y)
                                    change.consume()
                                }
                            }
                        }
                    }
                }
        )

        // 3. Damage Red Vignette & Flashbang Whiteout Overlays
        if (hudState.damageFlashAlpha > 0.02f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color.Transparent,
                                CrimsonAlert.copy(alpha = hudState.damageFlashAlpha * 0.55f)
                            )
                        )
                    )
            )
        }
        if (hudState.flashbangBlindAlpha > 0.02f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White.copy(alpha = hudState.flashbangBlindAlpha))
            )
        }

        // 4. Center CS2 Dynamic Crosshair / Sniper Scope
        CrosshairReticleCanvas(
            settings = settings,
            dynamicSpreadRatio = hudState.dynamicSpreadRatio,
            hitMarkerAlpha = hudState.hitMarkerAlpha,
            isHeadshot = hudState.hitMarkerHeadshot,
            scopeLevel = hudState.scopeLevel
        )

        // 5. Top HUD Row: Radar Minimap | Premier Scorebar | Killfeed
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            TacticalRadarMinimap(
                hudState = hudState,
                modifier = Modifier.align(Alignment.TopStart)
            )

            Column(
                modifier = Modifier.align(Alignment.TopCenter),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                PremierScoreTopBar(
                    hudState = hudState,
                    onOpenScoreboard = { onSetScoreboardOpen(true) }
                )

                // Freeze Time, Volumetric Smoke Carved, or Round End Banner
                val banner = when {
                    hudState.roundBannerText != null -> hudState.roundBannerText
                    hudState.phase == RoundPhase.FREEZE_TIME -> stringResource(R.string.hud_freeze_time)
                    hudState.smokeCarvedNotice -> "SMOKE DISPERSED BY BALLISTICS / HE"
                    else -> null
                }
                if (banner != null) {
                    Spacer(Modifier.height(6.dp))
                    val bannerColor = when (hudState.roundBannerTeam) {
                        TeamSide.CT -> CtSteelCyan
                        TeamSide.T -> TerroristOchre
                        null -> AmberStrike
                    }
                    Surface(
                        color = ObsidianBg.copy(alpha = 0.86f),
                        border = BorderStroke(1.dp, bannerColor),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = banner,
                            style = MaterialTheme.typography.labelMedium,
                            color = bannerColor,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            KillFeedColumn(
                entries = hudState.killFeed,
                modifier = Modifier.align(Alignment.TopEnd)
            )
        }

        // 6. Contextual Hold-to-Plant C4 / Hold-to-Defuse C4 Center-Bottom Action
        if (hudState.canPlantC4Now || hudState.canDefuseC4Now) {
            val isPlant = hudState.canPlantC4Now
            val actionColor = if (isPlant) TerroristOchre else CtSteelCyan
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(top = 135.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(ObsidianBg.copy(alpha = 0.88f))
                        .border(1.5.dp, actionColor, RoundedCornerShape(10.dp))
                        .pointerInput(isPlant) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                onBombActionHeld(true)
                                do {
                                    val event = awaitPointerEvent()
                                } while (event.changes.any { it.pressed })
                                onBombActionHeld(false)
                            }
                        }
                        .padding(horizontal = 18.dp, vertical = 12.dp)
                        .testTag("c4_objective_action_button")
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (isPlant) {
                                stringResource(R.string.hud_plant_c4)
                            } else {
                                stringResource(R.string.hud_defuse_c4)
                            },
                            style = MaterialTheme.typography.labelLarge,
                            color = actionColor
                        )
                        if (hudState.bombActionProgress > 0.01f) {
                            Spacer(Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { hudState.bombActionProgress },
                                color = actionColor,
                                trackColor = SlateSurface,
                                modifier = Modifier
                                    .width(150.dp)
                                    .height(6.dp)
                            )
                        }
                    }
                }
            }
        }

        // 7. Bottom Ergonomic Combat Controls & Weapon Hotbar
        BottomCombatControlsOverlay(
            hudState = hudState,
            onMoveJoystick = onMoveJoystick,
            onTouchLook = onTouchLook,
            onFireHeld = onFireHeld,
            onJump = onJump,
            onToggleCrouch = onToggleCrouch,
            onCycleScope = onCycleScope,
            onReload = onReload,
            onInspectWeapon = onInspectWeapon,
            onSelectSlot = onSelectSlot,
            onOpenBuyMenu = { onSetBuyMenuOpen(true) },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp)
        )

        // 8. Modal Overlays (Buy Menu / Scoreboard / Match Over)
        if (isBuyMenuOpen) {
            Cs2BuyMenuOverlay(
                hudState = hudState,
                preferredCtRifle = settings.preferredCtRifle,
                onBuyWeapon = onBuyWeapon,
                onBuyArmor = onBuyArmor,
                onBuyDefuseKit = onBuyDefuseKit,
                onRebuy = onRebuy,
                onClose = { onSetBuyMenuOpen(false) }
            )
        } else if (isScoreboardOpen || hudState.phase == RoundPhase.MATCH_OVER) {
            ScoreboardPauseOverlay(
                hudState = hudState,
                onResume = { onSetScoreboardOpen(false) },
                onPlayAgain = onDeployNewMatch,
                onToggleOrientation = onToggleOrientation,
                onLeaveMatch = onLeaveMatch
            )
        }
    }
}

@Composable
private fun BottomCombatControlsOverlay(
    hudState: MatchHudState,
    onMoveJoystick: (Float, Float) -> Unit,
    onTouchLook: (Float, Float) -> Unit,
    onFireHeld: (Boolean) -> Unit,
    onJump: () -> Unit,
    onToggleCrouch: () -> Unit,
    onCycleScope: () -> Unit,
    onReload: () -> Unit,
    onInspectWeapon: () -> Unit,
    onSelectSlot: (WeaponSlot) -> Unit,
    onOpenBuyMenu: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeInst = hudState.equippedWeapons[hudState.activeSlot]

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Upper Controls Row: Left Virtual Thumbstick + Stance | Right Combat Buttons (Fire / Scope / Reload / Jump)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            // Left Thumbstick + Crouch + Buy
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                VirtualMoveJoystick(onMove = onMoveJoystick)

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (hudState.canBuyNow) {
                        TacticalCircleButton(
                            label = "$${hudState.cash}\nBUY",
                            active = true,
                            accent = CashEmerald,
                            sizeDp = 54,
                            contentDesc = stringResource(R.string.cd_buy_menu),
                            tag = "buy_menu_button",
                            onClick = onOpenBuyMenu
                        )
                    }
                    TacticalCircleButton(
                        label = stringResource(R.string.hud_crouch),
                        active = hudState.isCrouching,
                        accent = CtSteelCyan,
                        sizeDp = 50,
                        contentDesc = stringResource(R.string.cd_crouch_action),
                        tag = "crouch_button",
                        onClick = onToggleCrouch
                    )
                }
            }

            // Right Combat Cluster: Scope, Reload, Jump, Inspect & Drag-Capable Fire Trigger
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TacticalCircleButton(
                        label = stringResource(R.string.hud_inspect),
                        active = false,
                        accent = AmberStrike,
                        sizeDp = 48,
                        contentDesc = "Inspect weapon",
                        tag = "inspect_weapon_button",
                        onClick = onInspectWeapon
                    )
                    if (activeInst?.weaponId?.hasScope == true) {
                        TacticalCircleButton(
                            label = if (hudState.scopeLevel > 0) "${hudState.scopeLevel}X" else stringResource(R.string.hud_scope),
                            active = hudState.scopeLevel > 0,
                            accent = CtSteelCyan,
                            sizeDp = 50,
                            contentDesc = stringResource(R.string.cd_scope_weapon),
                            tag = "scope_weapon_button",
                            onClick = onCycleScope
                        )
                    }
                    TacticalCircleButton(
                        label = stringResource(R.string.hud_jump),
                        active = false,
                        accent = AmberStrike,
                        sizeDp = 50,
                        contentDesc = stringResource(R.string.cd_jump_action),
                        tag = "jump_button",
                        onClick = onJump
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    TacticalCircleButton(
                        label = if (hudState.isReloading) "..." else stringResource(R.string.hud_reload),
                        active = hudState.isReloading,
                        accent = AmberStrike,
                        sizeDp = 50,
                        contentDesc = stringResource(R.string.cd_reload_weapon),
                        tag = "reload_weapon_button",
                        onClick = onReload
                    )

                    // Primary Fire Trigger (Hold to spray + drag to control recoil!)
                    FireTriggerPad(
                        onFireHeld = onFireHeld,
                        onRecoilDrag = onTouchLook
                    )
                }
            }
        }

        // Bottom CS2 Vitals (HP / Armor / Cash) & Weapon Slot Hotbar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // HP & Armor Pill
            Surface(
                color = ObsidianBg.copy(alpha = 0.82f),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, SlateOutline)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "+${hudState.playerHp}",
                        style = MaterialTheme.typography.titleLarge,
                        color = if (hudState.playerHp <= 25) CrimsonAlert else Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    val armorTag = if (hudState.hasHelmet) "H+K" else "KEV"
                    Text(
                        text = "$armorTag ${hudState.playerArmor}",
                        style = MaterialTheme.typography.labelMedium,
                        color = CtSteelCyan
                    )
                    if (!hudState.canBuyNow) {
                        Text(
                            text = "$${hudState.cash}",
                            style = MaterialTheme.typography.labelMedium,
                            color = CashEmerald
                        )
                    }
                }
            }

            // Quick Weapon & Grenade Switcher Slots
            Row(
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                WeaponSlot.entries.forEach { slot ->
                    val inst = hudState.equippedWeapons[slot]
                    if (inst != null) {
                        val isSelected = hudState.activeSlot == slot
                        Surface(
                            modifier = Modifier
                                .height(48.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onSelectSlot(slot) }
                                .testTag("weapon_slot_${slot.name.lowercase()}"),
                            color = if (isSelected) {
                                AmberStrike.copy(alpha = 0.24f)
                            } else {
                                ObsidianBg.copy(alpha = 0.78f)
                            },
                            border = BorderStroke(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) AmberStrike else SlateOutline
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = inst.weaponId.shortCode,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (isSelected) AmberStrike else Color.White
                                )
                                if (inst.weaponId.isFirearm()) {
                                    Text(
                                        text = "${inst.ammoInMag}/${inst.reserveAmmo}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (inst.ammoInMag == 0) CrimsonAlert else Color.LightGray
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VirtualMoveJoystick(
    onMove: (forward: Float, strafe: Float) -> Unit
) {
    var knobOffset by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier = Modifier
            .size(116.dp)
            .pointerInput(Unit) {
                val center = Offset(size.width * 0.5f, size.height * 0.5f)
                val maxRadius = kotlin.math.min(size.width, size.height) * 0.42f
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    var pointerId = down.id
                    fun updateFromPos(pos: Offset) {
                        val raw = pos - center
                        val dist = sqrt(raw.x * raw.x + raw.y * raw.y)
                        val clamped = if (dist > maxRadius && dist > 0.001f) {
                            raw * (maxRadius / dist)
                        } else {
                            raw
                        }
                        knobOffset = clamped
                        val strafe = (clamped.x / maxRadius).coerceIn(-1f, 1f)
                        val forward = (-clamped.y / maxRadius).coerceIn(-1f, 1f)
                        onMove(forward, strafe)
                    }
                    updateFromPos(down.position)
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == pointerId } ?: break
                        if (!change.pressed) break
                        updateFromPos(change.position)
                        change.consume()
                    }
                    knobOffset = Offset.Zero
                    onMove(0f, 0f)
                }
            }
            .testTag("virtual_move_joystick"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width * 0.5f, size.height * 0.5f)
            val outerR = size.minDimension * 0.45f
            drawCircle(
                color = ObsidianBg.copy(alpha = 0.55f),
                radius = outerR,
                center = center
            )
            drawCircle(
                color = SlateOutline,
                radius = outerR,
                center = center,
                style = Stroke(width = 2.dp.toPx())
            )
            drawCircle(
                color = AmberStrike.copy(alpha = 0.88f),
                radius = 20.dp.toPx(),
                center = center + knobOffset
            )
        }
    }
}

@Composable
private fun FireTriggerPad(
    onFireHeld: (Boolean) -> Unit,
    onRecoilDrag: (Float, Float) -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val fireDesc = stringResource(R.string.cd_fire_weapon)

    Box(
        modifier = Modifier
            .size(76.dp)
            .clip(CircleShape)
            .background(
                if (pressed) AmberStrike else AmberStrike.copy(alpha = 0.28f)
            )
            .border(2.5.dp, AmberStrike, CircleShape)
            .semantics { contentDescription = fireDesc }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val pointerId = down.id
                    pressed = true
                    onFireHeld(true)
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == pointerId } ?: break
                        if (!change.pressed) break
                        val delta = change.positionChange()
                        if (delta != Offset.Zero) {
                            onRecoilDrag(delta.x, delta.y)
                            change.consume()
                        }
                    }
                    pressed = false
                    onFireHeld(false)
                }
            }
            .testTag("fire_weapon_button"),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = stringResource(R.string.hud_fire),
            style = MaterialTheme.typography.labelLarge,
            color = if (pressed) ObsidianBg else Color.White,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun TacticalCircleButton(
    label: String,
    active: Boolean,
    accent: Color,
    sizeDp: Int,
    contentDesc: String,
    tag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(sizeDp.dp)
            .clip(CircleShape)
            .background(
                if (active) accent.copy(alpha = 0.32f) else ObsidianBg.copy(alpha = 0.72f)
            )
            .border(1.5.dp, if (active) accent else SlateOutline, CircleShape)
            .semantics { contentDescription = contentDesc }
            .clickable(onClick = onClick)
            .testTag(tag),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (active) accent else Color.White,
            fontWeight = FontWeight.Bold
        )
    }
}

package com.example.ui.lobby

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.ArenaMapId
import com.example.model.BotDifficulty
import com.example.model.GameMode
import com.example.model.PlayerSettings
import com.example.model.TeamSide
import com.example.model.WeaponId
import com.example.ui.theme.AmberStrike
import com.example.ui.theme.CashEmerald
import com.example.ui.theme.CtSteelCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SlateOutline
import com.example.ui.theme.SlateSurface
import com.example.ui.theme.SlateSurfaceElevated
import com.example.ui.theme.TerroristOchre
import com.example.viewmodel.LobbyTab
import com.example.viewmodel.LobbyUiState

@Composable
fun LobbyScreen(
    lobbyState: LobbyUiState,
    settings: PlayerSettings,
    isGyroAvailable: Boolean,
    onSelectTab: (LobbyTab) -> Unit,
    onSelectMap: (ArenaMapId) -> Unit,
    onSelectMode: (GameMode) -> Unit,
    onSelectTeam: (TeamSide) -> Unit,
    onSelectDifficulty: (BotDifficulty) -> Unit,
    onSelectInspectedWeapon: (WeaponId) -> Unit,
    onUpdateSettings: ((PlayerSettings) -> PlayerSettings) -> Unit,
    onDeployMatch: () -> Unit,
    onToggleOrientation: () -> Unit
) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBg)
    ) {
        val isWideLayout = maxWidth >= 680.dp

        if (isWideLayout) {
            Row(modifier = Modifier.fillMaxSize()) {
                NavigationRail(
                    containerColor = SlateSurface,
                    modifier = Modifier
                        .fillMaxHeight()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    Spacer(Modifier.height(12.dp))
                    LobbyRailItems(lobbyState.activeTab, onSelectTab)
                }

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                ) {
                    LobbyTopBar(onToggleOrientation = onToggleOrientation)
                    LobbyActiveTabContent(
                        lobbyState = lobbyState,
                        settings = settings,
                        isGyroAvailable = isGyroAvailable,
                        isWideLayout = true,
                        onSelectMap = onSelectMap,
                        onSelectMode = onSelectMode,
                        onSelectTeam = onSelectTeam,
                        onSelectDifficulty = onSelectDifficulty,
                        onSelectInspectedWeapon = onSelectInspectedWeapon,
                        onUpdateSettings = onUpdateSettings,
                        onDeployMatch = onDeployMatch
                    )
                }
            }
        } else {
            Scaffold(
                containerColor = ObsidianBg,
                contentWindowInsets = WindowInsets.safeDrawing,
                topBar = {
                    LobbyTopBar(
                        modifier = Modifier.statusBarsPadding(),
                        onToggleOrientation = onToggleOrientation
                    )
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = SlateSurface,
                        tonalElevation = 8.dp
                    ) {
                        NavigationBarItem(
                            selected = lobbyState.activeTab == LobbyTab.PLAY,
                            onClick = { onSelectTab(LobbyTab.PLAY) },
                            icon = {
                                Icon(
                                    imageVector = if (lobbyState.activeTab == LobbyTab.PLAY) {
                                        Icons.Filled.PlayArrow
                                    } else {
                                        Icons.Outlined.PlayArrow
                                    },
                                    contentDescription = stringResource(R.string.nav_play)
                                )
                            },
                            label = { Text(stringResource(R.string.nav_play)) },
                            colors = navBarColors(),
                            modifier = Modifier.testTag("nav_tab_play")
                        )
                        NavigationBarItem(
                            selected = lobbyState.activeTab == LobbyTab.ARMORY,
                            onClick = { onSelectTab(LobbyTab.ARMORY) },
                            icon = {
                                Icon(
                                    imageVector = if (lobbyState.activeTab == LobbyTab.ARMORY) {
                                        Icons.Filled.Build
                                    } else {
                                        Icons.Outlined.Build
                                    },
                                    contentDescription = stringResource(R.string.nav_armory)
                                )
                            },
                            label = { Text(stringResource(R.string.nav_armory)) },
                            colors = navBarColors(),
                            modifier = Modifier.testTag("nav_tab_armory")
                        )
                        NavigationBarItem(
                            selected = lobbyState.activeTab == LobbyTab.SETTINGS,
                            onClick = { onSelectTab(LobbyTab.SETTINGS) },
                            icon = {
                                Icon(
                                    imageVector = if (lobbyState.activeTab == LobbyTab.SETTINGS) {
                                        Icons.Filled.Tune
                                    } else {
                                        Icons.Outlined.Tune
                                    },
                                    contentDescription = stringResource(R.string.nav_settings)
                                )
                            },
                            label = { Text(stringResource(R.string.nav_settings)) },
                            colors = navBarColors(),
                            modifier = Modifier.testTag("nav_tab_settings")
                        )
                    }
                }
            ) { innerPadding ->
                Box(modifier = Modifier.padding(innerPadding)) {
                    LobbyActiveTabContent(
                        lobbyState = lobbyState,
                        settings = settings,
                        isGyroAvailable = isGyroAvailable,
                        isWideLayout = false,
                        onSelectMap = onSelectMap,
                        onSelectMode = onSelectMode,
                        onSelectTeam = onSelectTeam,
                        onSelectDifficulty = onSelectDifficulty,
                        onSelectInspectedWeapon = onSelectInspectedWeapon,
                        onUpdateSettings = onUpdateSettings,
                        onDeployMatch = onDeployMatch
                    )
                }
            }
        }
    }
}

@Composable
private fun LobbyRailItems(
    activeTab: LobbyTab,
    onSelectTab: (LobbyTab) -> Unit
) {
    NavigationRailItem(
        selected = activeTab == LobbyTab.PLAY,
        onClick = { onSelectTab(LobbyTab.PLAY) },
        icon = { Icon(Icons.Filled.PlayArrow, contentDescription = stringResource(R.string.nav_play)) },
        label = { Text(stringResource(R.string.nav_play)) },
        modifier = Modifier.testTag("nav_tab_play")
    )
    Spacer(Modifier.height(8.dp))
    NavigationRailItem(
        selected = activeTab == LobbyTab.ARMORY,
        onClick = { onSelectTab(LobbyTab.ARMORY) },
        icon = { Icon(Icons.Filled.Build, contentDescription = stringResource(R.string.nav_armory)) },
        label = { Text(stringResource(R.string.nav_armory)) },
        modifier = Modifier.testTag("nav_tab_armory")
    )
    Spacer(Modifier.height(8.dp))
    NavigationRailItem(
        selected = activeTab == LobbyTab.SETTINGS,
        onClick = { onSelectTab(LobbyTab.SETTINGS) },
        icon = { Icon(Icons.Filled.Tune, contentDescription = stringResource(R.string.nav_settings)) },
        label = { Text(stringResource(R.string.nav_settings)) },
        modifier = Modifier.testTag("nav_tab_settings")
    )
}

@Composable
private fun navBarColors() = NavigationBarItemDefaults.colors(
    selectedIconColor = ObsidianBg,
    selectedTextColor = AmberStrike,
    indicatorColor = AmberStrike,
    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
)

@Composable
private fun LobbyTopBar(
    modifier: Modifier = Modifier,
    onToggleOrientation: () -> Unit
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.horizontalGradient(
                    listOf(SlateSurface, ObsidianBg)
                )
            )
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(width = 6.dp, height = 32.dp)
                    .background(AmberStrike, RoundedCornerShape(2.dp))
            )
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    text = stringResource(R.string.app_name).uppercase(),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = stringResource(R.string.lobby_subtitle),
                    style = MaterialTheme.typography.labelSmall,
                    color = AmberStrike
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                color = CtSteelCyan.copy(alpha = 0.14f),
                border = BorderStroke(1.dp, CtSteelCyan.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text(
                    text = "CS RATING 14,850",
                    style = MaterialTheme.typography.labelMedium,
                    color = CtSteelCyan,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
            Spacer(Modifier.width(8.dp))
            IconButton(
                onClick = onToggleOrientation,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("toggle_orientation_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.ScreenRotation,
                    contentDescription = stringResource(R.string.btn_toggle_orientation),
                    tint = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
private fun LobbyActiveTabContent(
    lobbyState: LobbyUiState,
    settings: PlayerSettings,
    isGyroAvailable: Boolean,
    isWideLayout: Boolean,
    onSelectMap: (ArenaMapId) -> Unit,
    onSelectMode: (GameMode) -> Unit,
    onSelectTeam: (TeamSide) -> Unit,
    onSelectDifficulty: (BotDifficulty) -> Unit,
    onSelectInspectedWeapon: (WeaponId) -> Unit,
    onUpdateSettings: ((PlayerSettings) -> PlayerSettings) -> Unit,
    onDeployMatch: () -> Unit
) {
    when (lobbyState.activeTab) {
        LobbyTab.PLAY -> PlayMatchTab(
            lobbyState = lobbyState,
            isWideLayout = isWideLayout,
            onSelectMap = onSelectMap,
            onSelectMode = onSelectMode,
            onSelectTeam = onSelectTeam,
            onSelectDifficulty = onSelectDifficulty,
            onDeployMatch = onDeployMatch
        )
        LobbyTab.ARMORY -> ArmoryLoadoutTab(
            inspectedWeapon = lobbyState.inspectedWeapon,
            settings = settings,
            onSelectWeapon = onSelectInspectedWeapon,
            onUpdateSettings = onUpdateSettings
        )
        LobbyTab.SETTINGS -> CrosshairAndControlsTab(
            settings = settings,
            isGyroAvailable = isGyroAvailable,
            onUpdateSettings = onUpdateSettings
        )
    }
}

@Composable
private fun PlayMatchTab(
    lobbyState: LobbyUiState,
    isWideLayout: Boolean,
    onSelectMap: (ArenaMapId) -> Unit,
    onSelectMode: (GameMode) -> Unit,
    onSelectTeam: (TeamSide) -> Unit,
    onSelectDifficulty: (BotDifficulty) -> Unit,
    onDeployMatch: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Map Preview Banner with Deploy CTA
        item {
            HeroArenaBannerCard(
                map = lobbyState.selectedMap,
                mode = lobbyState.selectedMode,
                team = lobbyState.selectedTeam,
                onDeployMatch = onDeployMatch
            )
        }

        // Game Mode Selector
        item {
            SectionTitle(stringResource(R.string.section_game_mode))
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GameMode.entries.forEach { mode ->
                    val selected = lobbyState.selectedMode == mode
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onSelectMode(mode) }
                            .testTag("mode_card_${mode.name.lowercase()}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (selected) {
                                AmberStrike.copy(alpha = 0.16f)
                            } else {
                                SlateSurfaceElevated
                            }
                        ),
                        border = BorderStroke(
                            width = if (selected) 1.5.dp else 1.dp,
                            color = if (selected) AmberStrike else SlateOutline
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = stringResource(mode.titleRes),
                                style = MaterialTheme.typography.titleLarge,
                                color = if (selected) AmberStrike else MaterialTheme.colorScheme.onSurface,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = stringResource(mode.descRes),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // Arena Map Carousel
        item {
            SectionTitle(stringResource(R.string.section_map_select))
            Spacer(Modifier.height(8.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(ArenaMapId.entries) { map ->
                    val selected = lobbyState.selectedMap == map
                    Card(
                        modifier = Modifier
                            .width(if (isWideLayout) 250.dp else 220.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelectMap(map) }
                            .testTag("map_card_${map.name.lowercase()}"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            width = if (selected) 2.dp else 1.dp,
                            color = if (selected) AmberStrike else SlateOutline
                        ),
                        colors = CardDefaults.cardColors(containerColor = SlateSurface)
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(112.dp)
                            ) {
                                Image(
                                    painter = painterResource(map.bannerRes),
                                    contentDescription = stringResource(map.nameRes),
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(Color.Transparent, ObsidianBg.copy(alpha = 0.85f))
                                            )
                                        )
                                )
                                Text(
                                    text = stringResource(map.codeRes),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AmberStrike,
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .padding(8.dp)
                                )
                            }
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = stringResource(map.nameRes),
                                    style = MaterialTheme.typography.titleLarge,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    text = stringResource(map.descRes),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }
            }
        }

        // Faction Selection (CT vs T)
        item {
            SectionTitle(stringResource(R.string.section_team_select))
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                FactionCard(
                    modifier = Modifier.weight(1f),
                    team = TeamSide.CT,
                    selected = lobbyState.selectedTeam == TeamSide.CT,
                    accent = CtSteelCyan,
                    roleText = stringResource(R.string.team_ct_role),
                    onClick = { onSelectTeam(TeamSide.CT) }
                )
                FactionCard(
                    modifier = Modifier.weight(1f),
                    team = TeamSide.T,
                    selected = lobbyState.selectedTeam == TeamSide.T,
                    accent = TerroristOchre,
                    roleText = stringResource(R.string.team_t_role),
                    onClick = { onSelectTeam(TeamSide.T) }
                )
            }
        }

        // Bot Difficulty + Secondary Deploy Button
        item {
            SectionTitle(stringResource(R.string.section_bot_difficulty))
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                BotDifficulty.entries.forEach { diff ->
                    val selected = lobbyState.selectedDifficulty == diff
                    FilterChip(
                        selected = selected,
                        onClick = { onSelectDifficulty(diff) },
                        label = {
                            Text(
                                text = stringResource(diff.labelRes),
                                style = MaterialTheme.typography.labelLarge
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = AmberStrike,
                            selectedLabelColor = ObsidianBg
                        ),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("difficulty_chip_${diff.name.lowercase()}")
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun HeroArenaBannerCard(
    map: ArenaMapId,
    mode: GameMode,
    team: TeamSide,
    onDeployMatch: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, AmberStrike.copy(alpha = 0.55f)),
        colors = CardDefaults.cardColors(containerColor = SlateSurface)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(216.dp)
        ) {
            Image(
                painter = painterResource(map.bannerRes),
                contentDescription = stringResource(R.string.cd_hero_map_banner),
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                ObsidianBg.copy(alpha = 0.25f),
                                ObsidianBg.copy(alpha = 0.72f),
                                ObsidianBg.copy(alpha = 0.96f)
                            )
                        )
                    )
            )

            // Top badges
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    color = CashEmerald.copy(alpha = 0.22f),
                    border = BorderStroke(1.dp, CashEmerald),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = stringResource(R.string.lobby_ready_badge),
                        style = MaterialTheme.typography.labelSmall,
                        color = CashEmerald,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Surface(
                    color = ObsidianBg.copy(alpha = 0.75f),
                    border = BorderStroke(1.dp, SlateOutline),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "VOLUMETRIC SMOKES • 60HZ",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Bottom info & Deploy button
            Row(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = stringResource(map.codeRes),
                        style = MaterialTheme.typography.labelMedium,
                        color = AmberStrike
                    )
                    Text(
                        text = stringResource(map.nameRes),
                        style = MaterialTheme.typography.headlineLarge,
                        color = Color.White
                    )
                    Text(
                        text = "${stringResource(mode.titleRes)} • ${team.fullName}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(12.dp))
                Button(
                    onClick = onDeployMatch,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AmberStrike,
                        contentColor = ObsidianBg
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
                    modifier = Modifier
                        .height(52.dp)
                        .testTag("deploy_match_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = null
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.btn_deploy_match),
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun FactionCard(
    modifier: Modifier = Modifier,
    team: TeamSide,
    selected: Boolean,
    accent: Color,
    roleText: String,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag("team_card_${team.name.lowercase()}"),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) accent.copy(alpha = 0.16f) else SlateSurfaceElevated
        ),
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) accent else SlateOutline
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(accent.copy(alpha = 0.22f), RoundedCornerShape(8.dp))
                    .border(1.dp, accent, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Security,
                    contentDescription = null,
                    tint = accent
                )
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(
                    text = team.fullName,
                    style = MaterialTheme.typography.titleLarge,
                    color = if (selected) accent else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = roleText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
internal fun SectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        color = AmberStrike
    )
}

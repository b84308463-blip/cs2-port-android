package com.example.ui.hud

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.KillFeedEntry
import com.example.model.MatchHudState
import com.example.model.PlayerSettings
import com.example.model.RoundPhase
import com.example.model.TeamSide
import com.example.ui.theme.AmberStrike
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CtSteelCyan
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.SlateOutline
import com.example.ui.theme.TerroristOchre
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CrosshairReticleCanvas(
    settings: PlayerSettings,
    dynamicSpreadRatio: Float,
    hitMarkerAlpha: Float,
    isHeadshot: Boolean,
    scopeLevel: Int = 0
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val cx = size.width * 0.5f
        val cy = size.height * 0.5f

        if (scopeLevel > 0) {
            // CS2 Sniper Dual-Zoom Optic Overlay
            val radius = size.minDimension * (if (scopeLevel == 2) 0.44f else 0.40f)
            drawRect(color = Color.Black.copy(alpha = 0.52f))
            drawCircle(
                color = Color(0xFF0F172A).copy(alpha = 0.12f),
                radius = radius,
                center = Offset(cx, cy)
            )
            drawCircle(
                color = Color.Black,
                radius = radius,
                center = Offset(cx, cy),
                style = Stroke(width = 4.dp.toPx())
            )
            drawLine(Color.Black, Offset(0f, cy), Offset(size.width, cy), strokeWidth = 1.5.dp.toPx())
            drawLine(Color.Black, Offset(cx, 0f), Offset(cx, size.height), strokeWidth = 1.5.dp.toPx())
            drawCircle(color = CrimsonAlert, radius = 2.5.dp.toPx(), center = Offset(cx, cy))
        } else {
            val extraGapPx = if (settings.dynamicCrosshair) {
                dynamicSpreadRatio * 14.dp.toPx()
            } else {
                0f
            }
            val gap = settings.crosshairGapDp.dp.toPx() + extraGapPx
            val len = settings.crosshairLengthDp.dp.toPx()
            val thick = settings.crosshairThicknessDp.dp.toPx()
            val outlineThick = thick + 2.dp.toPx()
            val col = settings.crosshairColor.color

            // Black crisp outline
            drawLine(Color.Black.copy(alpha = 0.78f), Offset(cx - gap - len - 1f, cy), Offset(cx - gap + 1f, cy), outlineThick)
            drawLine(Color.Black.copy(alpha = 0.78f), Offset(cx + gap - 1f, cy), Offset(cx + gap + len + 1f, cy), outlineThick)
            drawLine(Color.Black.copy(alpha = 0.78f), Offset(cx, cy - gap - len - 1f), Offset(cx, cy - gap + 1f), outlineThick)
            drawLine(Color.Black.copy(alpha = 0.78f), Offset(cx, cy + gap - 1f), Offset(cx, cy + gap + len + 1f), outlineThick)

            // Main colored arms
            drawLine(col, Offset(cx - gap - len, cy), Offset(cx - gap, cy), thick)
            drawLine(col, Offset(cx + gap, cy), Offset(cx + gap + len, cy), thick)
            drawLine(col, Offset(cx, cy - gap - len), Offset(cx, cy - gap), thick)
            drawLine(col, Offset(cx, cy + gap), Offset(cx, cy + gap + len), thick)

            if (settings.crosshairCenterDot) {
                drawCircle(Color.Black.copy(alpha = 0.8f), radius = thick * 0.75f + 1f, center = Offset(cx, cy))
                drawCircle(col, radius = thick * 0.75f, center = Offset(cx, cy))
            }
        }

        // Hitmarker X feedback
        if (hitMarkerAlpha > 0.04f) {
            val hmCol = (if (isHeadshot) CrimsonAlert else Color.White).copy(alpha = hitMarkerAlpha)
            val rIn = 6.dp.toPx()
            val rOut = (if (isHeadshot) 14.dp else 11.dp).toPx()
            val sw = (if (isHeadshot) 2.5.dp else 1.8.dp).toPx()
            drawLine(hmCol, Offset(cx - rOut, cy - rOut), Offset(cx - rIn, cy - rIn), sw, StrokeCap.Round)
            drawLine(hmCol, Offset(cx + rOut, cy - rOut), Offset(cx + rIn, cy - rIn), sw, StrokeCap.Round)
            drawLine(hmCol, Offset(cx - rOut, cy + rOut), Offset(cx - rIn, cy + rIn), sw, StrokeCap.Round)
            drawLine(hmCol, Offset(cx + rOut, cy + rOut), Offset(cx + rIn, cy + rIn), sw, StrokeCap.Round)
        }
    }
}

@Composable
fun TacticalRadarMinimap(
    hudState: MatchHudState,
    modifier: Modifier = Modifier
) {
    val radarDesc = stringResource(R.string.cd_radar_minimap)
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.Start
    ) {
        Box(
            modifier = Modifier
                .size(106.dp)
                .clip(CircleShape)
                .background(ObsidianBg.copy(alpha = 0.80f))
                .border(1.5.dp, SlateOutline, CircleShape)
                .semantics { contentDescription = radarDesc }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width * 0.5f, size.height * 0.5f)
                val maxR = size.minDimension * 0.46f
                val localBlip = hudState.radarBlips.find { it.isLocal }
                val refX = localBlip?.x ?: 0f
                val refZ = localBlip?.z ?: 0f
                val yawRad = (localBlip?.yawDeg ?: 0f) * (PI.toFloat() / 180f)
                val cosY = cos(-yawRad)
                val sinY = sin(-yawRad)
                val scale = maxR / 28f

                fun toRadar(wx: Float, wz: Float): Offset {
                    val dx = (wx - refX) * scale
                    val dz = (wz - refZ) * scale
                    val rx = dx * cosY - dz * sinY
                    val rz = dx * sinY + dz * cosY
                    val dist = kotlin.math.sqrt(rx * rx + rz * rz)
                    val clamp = if (dist > maxR) maxR / dist else 1f
                    return Offset(center.x + rx * clamp, center.y + rz * clamp)
                }

                // Radar FOV cone
                drawLine(
                    color = Color.White.copy(alpha = 0.20f),
                    start = center,
                    end = Offset(center.x - maxR * 0.58f, center.y - maxR * 0.80f),
                    strokeWidth = 1.dp.toPx()
                )
                drawLine(
                    color = Color.White.copy(alpha = 0.20f),
                    start = center,
                    end = Offset(center.x + maxR * 0.58f, center.y - maxR * 0.80f),
                    strokeWidth = 1.dp.toPx()
                )

                // Bombsite A (-16, -15) & B (+16, -15) markers
                val siteAPos = toRadar(-16f, -15f)
                val siteBPos = toRadar(16f, -15f)
                drawCircle(AmberStrike.copy(alpha = 0.45f), radius = 6.dp.toPx(), center = siteAPos)
                drawCircle(AmberStrike.copy(alpha = 0.45f), radius = 6.dp.toPx(), center = siteBPos)

                // Active Volumetric Smokes on radar
                hudState.radarSmokes.forEach { sm ->
                    val p = toRadar(sm.x, sm.z)
                    drawCircle(
                        color = if (sm.isDispersedByHe) {
                            Color.LightGray.copy(alpha = 0.25f)
                        } else {
                            Color(0xFFCBD5E1).copy(alpha = 0.62f)
                        },
                        radius = (sm.radius * scale).coerceAtLeast(4.dp.toPx()),
                        center = p
                    )
                }

                // C4 position
                hudState.c4WorldPos?.let { (bx, bz) ->
                    drawCircle(CrimsonAlert, radius = 4.dp.toPx(), center = toRadar(bx, bz))
                }

                // Combatant blips
                hudState.radarBlips.forEach { blip ->
                    if (!blip.isLocal) {
                        val p = toRadar(blip.x, blip.z)
                        val col = if (blip.team == hudState.playerTeam) CtSteelCyan else CrimsonAlert
                        drawCircle(col, radius = 3.3.dp.toPx(), center = p)
                    }
                }

                // Local player center dot
                drawCircle(Color.White, radius = 3.8.dp.toPx(), center = center)
            }
        }

        Spacer(Modifier.height(4.dp))
        Surface(
            color = ObsidianBg.copy(alpha = 0.78f),
            shape = RoundedCornerShape(6.dp),
            border = BorderStroke(1.dp, SlateOutline)
        ) {
            Text(
                text = "${hudState.currentCallout.uppercase()} • ${hudState.fpsEstimate} FPS",
                style = MaterialTheme.typography.labelSmall,
                color = AmberStrike,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }
    }
}

@Composable
fun PremierScoreTopBar(
    hudState: MatchHudState,
    onOpenScoreboard: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scoreDesc = stringResource(R.string.cd_pause_menu)
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onOpenScoreboard)
            .semantics { contentDescription = scoreDesc }
            .testTag("pause_scoreboard_button"),
        color = ObsidianBg.copy(alpha = 0.84f),
        border = BorderStroke(
            width = 1.dp,
            color = if (hudState.phase == RoundPhase.BOMB_PLANTED) CrimsonAlert else SlateOutline
        ),
        shape = RoundedCornerShape(10.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // CT Alive Pips
            AlivePipsRow(count = hudState.ctAliveCount, color = CtSteelCyan)

            Text(
                text = "${hudState.ctScore}",
                style = MaterialTheme.typography.titleLarge,
                color = CtSteelCyan,
                fontWeight = FontWeight.Bold
            )

            // Center Timer or C4 Bomb Alert
            Box(
                modifier = Modifier
                    .background(
                        if (hudState.phase == RoundPhase.BOMB_PLANTED) {
                            CrimsonAlert.copy(alpha = 0.26f)
                        } else {
                            Color.White.copy(alpha = 0.07f)
                        },
                        RoundedCornerShape(6.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                if (hudState.phase == RoundPhase.BOMB_PLANTED) {
                    Text(
                        text = "C4 [${hudState.plantedSiteLabel ?: "A"}] ${hudState.timerSeconds}s",
                        style = MaterialTheme.typography.labelMedium,
                        color = CrimsonAlert
                    )
                } else {
                    val mins = hudState.timerSeconds / 60
                    val secs = hudState.timerSeconds % 60
                    Text(
                        text = "%d:%02d".format(mins, secs),
                        style = MaterialTheme.typography.labelLarge,
                        color = if (hudState.phase == RoundPhase.FREEZE_TIME) AmberStrike else Color.White
                    )
                }
            }

            Text(
                text = "${hudState.tScore}",
                style = MaterialTheme.typography.titleLarge,
                color = TerroristOchre,
                fontWeight = FontWeight.Bold
            )

            // T Alive Pips
            AlivePipsRow(count = hudState.tAliveCount, color = TerroristOchre)
        }
    }
}

@Composable
private fun AlivePipsRow(count: Int, color: Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        repeat(count.coerceIn(0, 5)) {
            Box(
                modifier = Modifier
                    .size(width = 5.dp, height = 14.dp)
                    .background(color, RoundedCornerShape(2.dp))
            )
        }
    }
}

@Composable
fun KillFeedColumn(
    entries: List<KillFeedEntry>,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        entries.take(4).forEach { item ->
            Surface(
                color = ObsidianBg.copy(alpha = 0.78f),
                shape = RoundedCornerShape(6.dp),
                border = BorderStroke(
                    width = 1.dp,
                    color = if (item.killerName == "YOU") AmberStrike else SlateOutline.copy(alpha = 0.6f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = item.killerName,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (item.killerTeam == TeamSide.CT) CtSteelCyan else TerroristOchre
                    )
                    Text(
                        text = buildString {
                            append("[")
                            append(item.weaponName)
                            if (item.isHeadshot) append(" • HS")
                            if (item.throughSmoke) append(" • SMK")
                            append("]")
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = if (item.isHeadshot) AmberStrike else Color.LightGray
                    )
                    Text(
                        text = item.victimName,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (item.victimTeam == TeamSide.CT) CtSteelCyan else TerroristOchre
                    )
                }
            }
        }
    }
}

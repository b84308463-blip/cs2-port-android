package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// CS2 Panorama Tactical Dark Palette
val ObsidianBg = Color(0xFF0A0F16)
val SlateSurface = Color(0xFF121A24)
val SlateSurfaceElevated = Color(0xFF1A2533)
val SlateSurfaceHigh = Color(0xFF233142)
val SlateOutline = Color(0xFF2E4057)

// Faction & Tactical Accent Tokens
val AmberStrike = Color(0xFFF59E0B)       // Signature CS2 Gold/Amber
val AmberStrikeBright = Color(0xFFFBBF24)
val AmberStrikeContainer = Color(0xFF3B2806)

val CtSteelCyan = Color(0xFF38BDF8)       // Counter-Terrorist Tactical Blue
val CtCyanContainer = Color(0xFF0C2D48)

val TerroristOchre = Color(0xFFFB923C)    // Terrorist Warm Ochre
val TerroristContainer = Color(0xFF3E1F09)

val CashEmerald = Color(0xFF10B981)       // Economy Cash Green
val CrimsonAlert = Color(0xFFEF4444)      // C4 Alert / Low HP / Elimination
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

package com.example

import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalConfiguration
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.hud.MatchScreen
import com.example.ui.lobby.LobbyScreen
import com.example.ui.theme.StrikeTacticalTheme
import com.example.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            StrikeTacticalTheme {
                val gameViewModel: GameViewModel = viewModel()
                val config = LocalConfiguration.current
                val toggleOrientation = {
                    requestedOrientation =
                        if (config.orientation == Configuration.ORIENTATION_LANDSCAPE) {
                            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                        } else {
                            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                        }
                }

                StrikeTacticalApp(
                    viewModel = gameViewModel,
                    onToggleOrientation = toggleOrientation
                )
            }
        }
    }
}

@Composable
fun StrikeTacticalApp(
    viewModel: GameViewModel,
    onToggleOrientation: () -> Unit
) {
    val lobbyState by viewModel.lobbyState.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val hudState by viewModel.hudState.collectAsStateWithLifecycle()
    val isBuyMenuOpen by viewModel.isBuyMenuOpen.collectAsStateWithLifecycle()
    val isScoreboardOpen by viewModel.isScoreboardOpen.collectAsStateWithLifecycle()

    if (hudState.isInMatch) {
        MatchScreen(
            hudState = hudState,
            settings = settings,
            isBuyMenuOpen = isBuyMenuOpen,
            isScoreboardOpen = isScoreboardOpen,
            snapshotProvider = viewModel::currentRenderSnapshot,
            onMoveJoystick = viewModel::onMoveJoystick,
            onTouchLook = viewModel::onTouchLook,
            onFireHeld = viewModel::onFireHeld,
            onBombActionHeld = viewModel::onBombActionHeld,
            onJump = viewModel::onJump,
            onToggleCrouch = viewModel::onToggleCrouch,
            onCycleScope = viewModel::onCycleScope,
            onReload = viewModel::onReload,
            onInspectWeapon = viewModel::onInspectWeapon,
            onSelectSlot = viewModel::onSelectSlot,
            onSetBuyMenuOpen = viewModel::setBuyMenuOpen,
            onSetScoreboardOpen = viewModel::setScoreboardOpen,
            onBuyWeapon = { viewModel.onBuyWeapon(it) },
            onBuyArmor = { viewModel.onBuyArmor(it) },
            onBuyDefuseKit = { viewModel.onBuyDefuseKit() },
            onRebuy = viewModel::onRebuyPrevious,
            onDeployNewMatch = viewModel::deployMatch,
            onToggleOrientation = onToggleOrientation,
            onLeaveMatch = viewModel::leaveMatch
        )
    } else {
        LobbyScreen(
            lobbyState = lobbyState,
            settings = settings,
            isGyroAvailable = viewModel.isGyroHardwareAvailable,
            onSelectTab = viewModel::selectTab,
            onSelectMap = viewModel::selectMap,
            onSelectMode = viewModel::selectMode,
            onSelectTeam = viewModel::selectTeam,
            onSelectDifficulty = viewModel::selectDifficulty,
            onSelectInspectedWeapon = viewModel::selectInspectedWeapon,
            onUpdateSettings = viewModel::updateSettings,
            onDeployMatch = viewModel::deployMatch,
            onToggleOrientation = onToggleOrientation
        )
    }
}

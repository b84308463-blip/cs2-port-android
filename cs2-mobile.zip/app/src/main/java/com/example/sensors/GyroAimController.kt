package com.example.sensors

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.Surface
import android.view.WindowManager

class GyroAimController(
    context: Context,
    private val onGyroDelta: (deltaYawDeg: Float, deltaPitchDeg: Float) -> Unit
) : SensorEventListener {

    private val sensorManager =
        context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val windowManager =
        context.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
    private val gyroSensor: Sensor? =
        sensorManager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE)

    val isAvailable: Boolean = gyroSensor != null

    private var lastTimestampNs: Long = 0L
    private var sensitivity: Float = 1.2f
    private var registered = false

    fun start(currentSensitivity: Float) {
        sensitivity = currentSensitivity
        if (!isAvailable || registered) return
        lastTimestampNs = 0L
        gyroSensor?.let { sensor ->
            sensorManager?.registerListener(
                this,
                sensor,
                SensorManager.SENSOR_DELAY_GAME
            )
            registered = true
        }
    }

    fun updateSensitivity(newSensitivity: Float) {
        sensitivity = newSensitivity
    }

    fun stop() {
        if (registered) {
            sensorManager?.unregisterListener(this)
            registered = false
            lastTimestampNs = 0L
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event?.sensor?.type != Sensor.TYPE_GYROSCOPE) return
        if (lastTimestampNs != 0L) {
            val dtSec = (event.timestamp - lastTimestampNs) * 1e-9f
            if (dtSec in 0.0005f..0.1f) {
                val rx = event.values[0] // rad/s around X
                val ry = event.values[1] // rad/s around Y
                @Suppress("DEPRECATION")
                val rotation = windowManager?.defaultDisplay?.rotation ?: Surface.ROTATION_0
                val (yawRate, pitchRate) = when (rotation) {
                    Surface.ROTATION_90 -> Pair(-rx, -ry)
                    Surface.ROTATION_270 -> Pair(rx, ry)
                    Surface.ROTATION_180 -> Pair(ry, -rx)
                    else -> Pair(-ry, rx)
                }
                val radToDeg = 57.29578f
                val dYaw = yawRate * dtSec * radToDeg * sensitivity * 1.4f
                val dPitch = pitchRate * dtSec * radToDeg * sensitivity * 1.15f
                if (kotlin.math.abs(dYaw) > 0.002f || kotlin.math.abs(dPitch) > 0.002f) {
                    onGyroDelta(dYaw, dPitch)
                }
            }
        }
        lastTimestampNs = event.timestamp
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}

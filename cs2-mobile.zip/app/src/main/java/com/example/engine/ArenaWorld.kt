package com.example.engine

import com.example.model.ArenaMapId
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

enum class SurfaceMaterial {
    GROUND,
    WALL_PRIMARY,
    WALL_ACCENT_CRATE,
    SITE_MARKER_A,
    SITE_MARKER_B,
    METAL_TRIM,
    HAZARD_STRIPE
}

data class Box3D(
    val minX: Float,
    val minY: Float,
    val minZ: Float,
    val maxX: Float,
    val maxY: Float,
    val maxZ: Float,
    val material: SurfaceMaterial = SurfaceMaterial.WALL_PRIMARY,
    val solid: Boolean = true
)

data class BombSiteZone(
    val label: String,
    val x: Float,
    val z: Float,
    val radius: Float
)

data class CalloutRegion(
    val name: String,
    val minX: Float,
    val minZ: Float,
    val maxX: Float,
    val maxZ: Float
)

data class Waypoint(
    val id: Int,
    val x: Float,
    val z: Float,
    val neighbors: List<Int>
)

data class ArenaWorld(
    val mapId: ArenaMapId,
    val halfExtent: Float,
    val boxes: List<Box3D>,
    val ctSpawns: List<Pair<Float, Float>>,
    val tSpawns: List<Pair<Float, Float>>,
    val bombSites: List<BombSiteZone>,
    val waypoints: List<Waypoint>,
    val callouts: List<CalloutRegion>
) {
    fun calloutAt(x: Float, z: Float): String {
        for (region in callouts) {
            if (x in region.minX..region.maxX && z in region.minZ..region.maxZ) {
                return region.name
            }
        }
        return "Mid Sector"
    }

    fun bombSiteAt(x: Float, z: Float): BombSiteZone? {
        for (site in bombSites) {
            val dx = x - site.x
            val dz = z - site.z
            if (dx * dx + dz * dz <= site.radius * site.radius) {
                return site
            }
        }
        return null
    }

    /**
     * Resolves horizontal player/bot cylinder collision and returns the floor height under (x, z)
     */
    fun resolveMovement(
        oldX: Float,
        oldZ: Float,
        footY: Float,
        targetX: Float,
        targetZ: Float,
        radius: Float = 0.48f,
        bodyHeight: Float = 1.75f
    ): Triple<Float, Float, Float> {
        var rx = targetX.coerceIn(-halfExtent + 1.2f, halfExtent - 1.2f)
        var rz = targetZ.coerceIn(-halfExtent + 1.2f, halfExtent - 1.2f)
        var supportY = 0f

        for (box in boxes) {
            if (!box.solid) continue
            // Check if player feet are above or can step onto low platform/step (<= 0.55m above footY)
            val overlapsXZ = (rx + radius > box.minX && rx - radius < box.maxX &&
                rz + radius > box.minZ && rz - radius < box.maxZ)

            if (overlapsXZ && footY >= box.maxY - 0.52f) {
                if (box.maxY > supportY) {
                    supportY = box.maxY
                }
                continue
            }

            // Vertical body overlap check
            if (footY + bodyHeight <= box.minY || footY >= box.maxY) continue

            // Push cylinder out of AABB on XZ plane
            val closestX = rx.coerceIn(box.minX, box.maxX)
            val closestZ = rz.coerceIn(box.minZ, box.maxZ)
            val dx = rx - closestX
            val dz = rz - closestZ
            val distSq = dx * dx + dz * dz

            if (distSq < radius * radius) {
                if (distSq > 0.00001f) {
                    val dist = sqrt(distSq)
                    val push = radius - dist
                    rx += (dx / dist) * push
                    rz += (dz / dist) * push
                } else {
                    // Inside box center fallback: push along minimum penetration axis
                    val penLeft = abs(rx - box.minX)
                    val penRight = abs(box.maxX - rx)
                    val penFront = abs(rz - box.minZ)
                    val penBack = abs(box.maxZ - rz)
                    val minPen = min(min(penLeft, penRight), min(penFront, penBack))
                    when (minPen) {
                        penLeft -> rx = box.minX - radius
                        penRight -> rx = box.maxX + radius
                        penFront -> rz = box.minZ - radius
                        else -> rz = box.maxZ + radius
                    }
                }
            }
        }
        return Triple(rx, rz, supportY)
    }

    /**
     * Raycasts against all solid world boxes; returns distance to nearest hit or maxDist if clear.
     */
    fun raycastWorld(
        ox: Float,
        oy: Float,
        oz: Float,
        dx: Float,
        dy: Float,
        dz: Float,
        maxDist: Float
    ): Float {
        var closest = maxDist
        for (box in boxes) {
            if (!box.solid) continue
            val t = intersectRayAabb(ox, oy, oz, dx, dy, dz, box, closest)
            if (t >= 0f && t < closest) {
                closest = t
            }
        }
        return closest
    }

    companion object {
        fun intersectRayAabb(
            ox: Float,
            oy: Float,
            oz: Float,
            dx: Float,
            dy: Float,
            dz: Float,
            box: Box3D,
            maxDist: Float
        ): Float {
            var tMin = 0f
            var tMax = maxDist

            if (abs(dx) < 1e-6f) {
                if (ox < box.minX || ox > box.maxX) return -1f
            } else {
                val invD = 1f / dx
                var t1 = (box.minX - ox) * invD
                var t2 = (box.maxX - ox) * invD
                if (t1 > t2) { val tmp = t1; t1 = t2; t2 = tmp }
                tMin = max(tMin, t1)
                tMax = min(tMax, t2)
                if (tMin > tMax) return -1f
            }

            if (abs(dy) < 1e-6f) {
                if (oy < box.minY || oy > box.maxY) return -1f
            } else {
                val invD = 1f / dy
                var t1 = (box.minY - oy) * invD
                var t2 = (box.maxY - oy) * invD
                if (t1 > t2) { val tmp = t1; t1 = t2; t2 = tmp }
                tMin = max(tMin, t1)
                tMax = min(tMax, t2)
                if (tMin > tMax) return -1f
            }

            if (abs(dz) < 1e-6f) {
                if (oz < box.minZ || oz > box.maxZ) return -1f
            } else {
                val invD = 1f / dz
                var t1 = (box.minZ - oz) * invD
                var t2 = (box.maxZ - oz) * invD
                if (t1 > t2) { val tmp = t1; t1 = t2; t2 = tmp }
                tMin = max(tMin, t1)
                tMax = min(tMax, t2)
                if (tMin > tMax) return -1f
            }

            return if (tMin <= maxDist) tMin else -1f
        }

        fun build(mapId: ArenaMapId): ArenaWorld {
            val h = 28f
            val perimeter = listOf(
                // Ground slab
                Box3D(-h, -0.5f, -h, h, 0f, h, SurfaceMaterial.GROUND, solid = false),
                // Outer 4 boundary walls
                Box3D(-h, 0f, -h, h, 5.2f, -h + 0.9f, SurfaceMaterial.WALL_PRIMARY),
                Box3D(-h, 0f, h - 0.9f, h, 5.2f, h, SurfaceMaterial.WALL_PRIMARY),
                Box3D(-h, 0f, -h, -h + 0.9f, 5.2f, h, SurfaceMaterial.WALL_PRIMARY),
                Box3D(h - 0.9f, 0f, -h, h, 5.2f, h, SurfaceMaterial.WALL_PRIMARY)
            )

            return when (mapId) {
                ArenaMapId.DUST_ARENA -> buildDustArena(h, perimeter)
                ArenaMapId.PALACE_MIRAGE -> buildPalaceMirage(h, perimeter)
                ArenaMapId.REACTOR_FACILITY -> buildReactorFacility(h, perimeter)
            }
        }

        private fun buildDustArena(h: Float, perimeter: List<Box3D>): ArenaWorld {
            val interior = listOf(
                // Bombsite A & B visual ground decals
                Box3D(-19.5f, 0.01f, -18.5f, -12.5f, 0.04f, -11.5f, SurfaceMaterial.SITE_MARKER_A, solid = false),
                Box3D(12.5f, 0.01f, -18.5f, 19.5f, 0.04f, -11.5f, SurfaceMaterial.SITE_MARKER_B, solid = false),

                // Mid Double Doors (iconic angled gap at x = -1.3..1.3, z = -3f)
                Box3D(-9.5f, 0f, -3.5f, -1.4f, 4.2f, -2.3f, SurfaceMaterial.WALL_PRIMARY),
                Box3D(1.4f, 0f, -3.5f, 9.5f, 4.2f, -2.3f, SurfaceMaterial.WALL_PRIMARY),
                Box3D(-3.2f, 3.1f, -3.6f, 3.2f, 4.3f, -2.2f, SurfaceMaterial.METAL_TRIM), // Door lintel arch
                Box3D(-1.45f, 0f, -3.55f, -0.45f, 3.1f, -2.25f, SurfaceMaterial.METAL_TRIM), // Left angled steel door
                Box3D(0.45f, 0f, -3.55f, 1.45f, 3.1f, -2.25f, SurfaceMaterial.METAL_TRIM),  // Right angled steel door

                // Xbox crate in Mid (crouch/jump peek!)
                Box3D(-2.8f, 0f, 1.5f, -0.8f, 1.35f, 3.5f, SurfaceMaterial.WALL_ACCENT_CRATE),

                // Long A divider wall (separating Long A from Mid)
                Box3D(-11.5f, 0f, 3.5f, -9.8f, 4.4f, 16.5f, SurfaceMaterial.WALL_PRIMARY),
                Box3D(-20.5f, 0f, 7.5f, -16.2f, 4.2f, 9.2f, SurfaceMaterial.WALL_PRIMARY), // Long Doors flank

                // Bombsite A stacked military crates + headshot box
                Box3D(-17.4f, 0f, -16.4f, -14.8f, 1.9f, -13.8f, SurfaceMaterial.WALL_ACCENT_CRATE),
                Box3D(-16.8f, 1.9f, -15.8f, -15.2f, 3.2f, -14.2f, SurfaceMaterial.WALL_ACCENT_CRATE),
                Box3D(-22.5f, 0f, -12.0f, -19.8f, 1.25f, -10.2f, SurfaceMaterial.WALL_ACCENT_CRATE), // Goose cover
                // Catwalk Short A wall
                Box3D(-8.5f, 0f, -11.5f, -5.2f, 3.8f, -9.8f, SurfaceMaterial.WALL_PRIMARY),

                // B Tunnels & B Site divider walls
                Box3D(9.8f, 0f, 3.5f, 11.5f, 4.4f, 16.5f, SurfaceMaterial.WALL_PRIMARY),
                Box3D(16.2f, 0f, 6.2f, 22.0f, 4.2f, 8.0f, SurfaceMaterial.WALL_PRIMARY),
                // Bombsite B Double stack & Window wall
                Box3D(14.8f, 0f, -16.4f, 17.5f, 2.0f, -13.8f, SurfaceMaterial.WALL_ACCENT_CRATE),
                Box3D(19.5f, 0f, -14.0f, 21.8f, 1.3f, -11.5f, SurfaceMaterial.WALL_ACCENT_CRATE),
                Box3D(6.2f, 0f, -12.2f, 9.4f, 3.8f, -10.5f, SurfaceMaterial.WALL_PRIMARY),

                // T Spawn cover wall
                Box3D(-4.5f, 0f, 16.5f, 4.5f, 2.8f, 18.0f, SurfaceMaterial.WALL_PRIMARY),
                // CT Spawn cover crate
                Box3D(-2.2f, 0f, -21.0f, 2.2f, 1.6f, -19.2f, SurfaceMaterial.WALL_ACCENT_CRATE)
            )
            return createWorldWithCommonRouting(ArenaMapId.DUST_ARENA, h, perimeter + interior)
        }

        private fun buildPalaceMirage(h: Float, perimeter: List<Box3D>): ArenaWorld {
            val interior = listOf(
                Box3D(-19.5f, 0.01f, -18.5f, -12.5f, 0.04f, -11.5f, SurfaceMaterial.SITE_MARKER_A, solid = false),
                Box3D(12.5f, 0.01f, -18.5f, 19.5f, 0.04f, -11.5f, SurfaceMaterial.SITE_MARKER_B, solid = false),

                // Mirage Mid Top Boxes & Connector
                Box3D(-1.8f, 0f, 4.2f, 1.8f, 1.8f, 6.8f, SurfaceMaterial.WALL_ACCENT_CRATE),
                Box3D(-9.8f, 0f, -4.5f, -3.2f, 4.2f, -2.5f, SurfaceMaterial.WALL_PRIMARY),
                Box3D(3.2f, 0f, -4.5f, 9.8f, 4.2f, -2.5f, SurfaceMaterial.WALL_PRIMARY),

                // A Site Triple Box, Default & Palace Pillars
                Box3D(-17.8f, 0f, -16.8f, -15.0f, 2.1f, -14.2f, SurfaceMaterial.WALL_ACCENT_CRATE),
                Box3D(-14.2f, 0f, -11.5f, -11.8f, 1.9f, -9.2f, SurfaceMaterial.WALL_ACCENT_CRATE), // Firebox/Triple
                Box3D(-21.5f, 0f, -6.0f, -19.2f, 4.4f, -3.8f, SurfaceMaterial.WALL_PRIMARY), // Palace pillar 1
                Box3D(-21.5f, 0f, 2.0f, -19.2f, 4.4f, 4.2f, SurfaceMaterial.WALL_PRIMARY),   // Palace pillar 2
                Box3D(-12.0f, 0f, 4.5f, -9.8f, 4.2f, 15.5f, SurfaceMaterial.WALL_PRIMARY),

                // B Site Apartments & Bench crates
                Box3D(10.0f, 0f, 4.5f, 12.0f, 4.2f, 15.5f, SurfaceMaterial.WALL_PRIMARY),
                Box3D(14.6f, 0f, -16.2f, 17.6f, 2.0f, -13.6f, SurfaceMaterial.WALL_ACCENT_CRATE),
                Box3D(19.8f, 0f, -9.5f, 22.5f, 1.4f, -6.8f, SurfaceMaterial.WALL_ACCENT_CRATE),

                // Spawn dividers
                Box3D(-4.0f, 0f, 16.8f, 4.0f, 1.5f, 18.4f, SurfaceMaterial.WALL_ACCENT_CRATE),
                Box3D(-3.2f, 0f, -21.2f, 3.2f, 2.6f, -19.6f, SurfaceMaterial.WALL_PRIMARY)
            )
            return createWorldWithCommonRouting(ArenaMapId.PALACE_MIRAGE, h, perimeter + interior)
        }

        private fun buildReactorFacility(h: Float, perimeter: List<Box3D>): ArenaWorld {
            val interior = listOf(
                Box3D(-19.5f, 0.01f, -18.5f, -12.5f, 0.04f, -11.5f, SurfaceMaterial.SITE_MARKER_A, solid = false),
                Box3D(12.5f, 0.01f, -18.5f, 19.5f, 0.04f, -11.5f, SurfaceMaterial.SITE_MARKER_B, solid = false),

                // Central Reactor Containment Silos (Yellow Hazard Accent)
                Box3D(-2.6f, 0f, -2.6f, 2.6f, 4.8f, 2.6f, SurfaceMaterial.HAZARD_STRIPE),
                Box3D(-17.8f, 0f, -16.8f, -14.4f, 4.2f, -13.4f, SurfaceMaterial.HAZARD_STRIPE), // Silo A
                Box3D(14.4f, 0f, -16.8f, 17.8f, 4.2f, -13.4f, SurfaceMaterial.HAZARD_STRIPE),  // Silo B

                // Steel Bunker Partitions
                Box3D(-11.2f, 0f, -4.5f, -6.2f, 3.8f, -2.8f, SurfaceMaterial.METAL_TRIM),
                Box3D(6.2f, 0f, -4.5f, 11.2f, 3.8f, -2.8f, SurfaceMaterial.METAL_TRIM),
                Box3D(-11.5f, 0f, 5.0f, -9.6f, 4.2f, 15.5f, SurfaceMaterial.WALL_PRIMARY),
                Box3D(9.6f, 0f, 5.0f, 11.5f, 4.2f, 15.5f, SurfaceMaterial.WALL_PRIMARY),

                // Low yellow hazard cover barriers
                Box3D(-21.5f, 0f, -11.0f, -18.5f, 1.3f, -9.2f, SurfaceMaterial.WALL_ACCENT_CRATE),
                Box3D(18.5f, 0f, -11.0f, 21.5f, 1.3f, -9.2f, SurfaceMaterial.WALL_ACCENT_CRATE),
                Box3D(-4.2f, 0f, 15.5f, 4.2f, 1.4f, 17.2f, SurfaceMaterial.METAL_TRIM),
                Box3D(-3.5f, 0f, -21.0f, 3.5f, 1.6f, -19.2f, SurfaceMaterial.METAL_TRIM)
            )
            return createWorldWithCommonRouting(ArenaMapId.REACTOR_FACILITY, h, perimeter + interior)
        }

        private fun createWorldWithCommonRouting(
            mapId: ArenaMapId,
            h: Float,
            boxes: List<Box3D>
        ): ArenaWorld {
            val ctSpawns = listOf(
                Pair(0f, -24.2f),
                Pair(-3.6f, -24.0f),
                Pair(3.6f, -24.0f),
                Pair(-6.8f, -23.2f),
                Pair(6.8f, -23.2f)
            )
            val tSpawns = listOf(
                Pair(0f, 24.2f),
                Pair(-3.6f, 24.0f),
                Pair(3.6f, 24.0f),
                Pair(-6.8f, 23.2f),
                Pair(6.8f, 23.2f)
            )
            val bombSites = listOf(
                BombSiteZone("A", -16.0f, -15.0f, 4.4f),
                BombSiteZone("B", 16.0f, -15.0f, 4.4f)
            )
            val waypoints = listOf(
                Waypoint(0, 0f, -23.0f, listOf(1, 2, 3)),          // CT Spawn
                Waypoint(1, -13.5f, -20.5f, listOf(0, 4)),         // CT -> A
                Waypoint(2, 0f, -9.0f, listOf(0, 5, 4, 6)),        // CT Mid
                Waypoint(3, 13.5f, -20.5f, listOf(0, 6)),          // CT -> B
                Waypoint(4, -13.2f, -13.5f, listOf(1, 2, 7)),      // Bombsite A approach
                Waypoint(5, 0f, 0.2f, listOf(2, 8, 7, 9)),         // Center Mid
                Waypoint(6, 13.2f, -13.5f, listOf(3, 2, 9)),       // Bombsite B approach
                Waypoint(7, -15.5f, 3.5f, listOf(4, 5, 10)),       // Long A / Palace
                Waypoint(8, 0f, 11.5f, listOf(5, 12, 10, 11)),     // Top Mid
                Waypoint(9, 15.5f, 3.5f, listOf(6, 5, 11)),        // B Tunnels / Apts
                Waypoint(10, -15.5f, 18.5f, listOf(7, 8, 12)),     // T Flank A
                Waypoint(11, 15.5f, 18.5f, listOf(9, 8, 12)),      // T Flank B
                Waypoint(12, 0f, 23.0f, listOf(10, 8, 11))         // T Spawn
            )
            val callouts = listOf(
                CalloutRegion("CT Spawn", -10f, -28f, 10f, -19f),
                CalloutRegion("T Spawn", -10f, 19f, 10f, 28f),
                CalloutRegion("Bombsite A", -28f, -28f, -10f, -8f),
                CalloutRegion("Bombsite B", 10f, -28f, 28f, -8f),
                CalloutRegion("Long A", -28f, -8f, -10f, 28f),
                CalloutRegion("B Tunnels", 10f, -8f, 28f, 28f),
                CalloutRegion("Mid Doors", -10f, -8f, 10f, 6f),
                CalloutRegion("Top Mid", -10f, 6f, 10f, 19f)
            )
            return ArenaWorld(
                mapId = mapId,
                halfExtent = h,
                boxes = boxes,
                ctSpawns = ctSpawns,
                tSpawns = tSpawns,
                bombSites = bombSites,
                waypoints = waypoints,
                callouts = callouts
            )
        }
    }
}

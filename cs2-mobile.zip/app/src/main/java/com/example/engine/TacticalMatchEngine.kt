package com.example.engine

import com.example.audio.TacticalAudioEngine
import com.example.model.ArenaMapId
import com.example.model.BotDifficulty
import com.example.model.GameMode
import com.example.model.KillFeedEntry
import com.example.model.MatchHudState
import com.example.model.PlayerSettings
import com.example.model.RadarBlip
import com.example.model.RadarSmokeZone
import com.example.model.RoundPhase
import com.example.model.ScoreboardEntry
import com.example.model.TeamSide
import com.example.model.WeaponId
import com.example.model.WeaponInstance
import com.example.model.WeaponSlot
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

class TacticalMatchEngine(
    private val audioEngine: TacticalAudioEngine
) {
    private val _hudState = MutableStateFlow(MatchHudState())
    val hudState: StateFlow<MatchHudState> = _hudState.asStateFlow()

    @Volatile
    var latestRenderSnapshot: RenderFrameSnapshot = RenderFrameSnapshot(
        mapId = ArenaMapId.DUST_ARENA,
        camX = 0f,
        camY = 1.62f,
        camZ = -24f,
        camYawDeg = 0f,
        camPitchDeg = 0f,
        fovYDeg = 74f,
        activeWeapon = WeaponId.USP_S,
        weaponFinish = PlayerSettings().globalWeaponFinish,
        leftHanded = false,
        recoilKickOffset = 0f,
        walkBobPhase = 0f,
        reloadProgress = 0f,
        inspectProgress = 0f,
        muzzleFlashIntensity = 0f,
        isScoped = false,
        combatants = emptyList(),
        smokePuffs = emptyList(),
        grenades = emptyList(),
        tracers = emptyList(),
        plantedC4Pos = null,
        c4BlinkOn = false
    )
        private set

    private val lock = Any()
    private var world: ArenaWorld = ArenaWorld.build(ArenaMapId.DUST_ARENA)
    private var gameMode: GameMode = GameMode.PREMIER_5V5
    private var difficulty: BotDifficulty = BotDifficulty.MASTER_GUARDIAN
    private var settings: PlayerSettings = PlayerSettings()

    private val combatants = mutableListOf<CombatantEntity>()
    private val smokes = mutableListOf<VolumetricSmokeCloud>()
    private val grenades = mutableListOf<FlyingGrenadeEntity>()
    private val tracers = mutableListOf<Pair<TracerRenderItem, Long>>()
    private val killFeed = mutableListOf<KillFeedEntry>()
    private val lastBoughtWeapons = mutableListOf<WeaponId>()

    private var roundNumber = 1
    private var ctScore = 0
    private var tScore = 0
    private var ctLossStreak = 0
    private var tLossStreak = 0
    private var phase = RoundPhase.FREEZE_TIME
    private var phaseStartMs = 0L
    private var roundDurationMs = 105_000L
    private var plantedC4Pos: Triple<Float, Float, Float>? = null
    private var plantedSiteLabel: String? = null
    private var bombPlantedAtMs = 0L
    private var lastBombBeepMs = 0L
    private var roundBannerText: String? = null
    private var roundBannerTeam: TeamSide? = null

    // Player real-time controls & visual transients
    private var moveForwardInput = 0f
    private var moveStrafeInput = 0f
    private var fireHeld = false
    private var bombActionHeld = false
    private var playerBombProgressSec = 0f
    private var scopeLevel = 0
    private var recoilAccum = 0f
    private var walkBobPhase = 0f
    private var muzzleFlashAlpha = 0f
    private var hitMarkerAlpha = 0f
    private var hitMarkerHeadshot = false
    private var damageFlashAlpha = 0f
    private var flashBlindAlpha = 0f
    private var inspectStartMs = 0L
    private var smokeCarvedUntilMs = 0L
    private var idCounter = 100L
    private var dmRespawnAtMs = 0L

    fun updatePlayerSettings(newSettings: PlayerSettings) {
        synchronized(lock) {
            settings = newSettings
            audioEngine.soundEnabled = newSettings.soundEnabled
            audioEngine.hapticsEnabled = newSettings.hapticsEnabled
        }
    }

    fun startNewMatch(
        mapId: ArenaMapId,
        mode: GameMode,
        playerTeam: TeamSide,
        botDifficulty: BotDifficulty
    ) {
        synchronized(lock) {
            world = ArenaWorld.build(mapId)
            gameMode = mode
            difficulty = botDifficulty
            roundNumber = 1
            ctScore = 0
            tScore = 0
            ctLossStreak = 0
            tLossStreak = 0
            combatants.clear()
            killFeed.clear()
            lastBoughtWeapons.clear()

            val ctNames = listOf("Phoenix", "Valkyrie", "Cipher", "Kestrel", "Vanguard")
            val tNames = listOf("Sabre", "Korsak", "Mirage", "Draco", "Raptor")

            val teamCount = mode.teamSize
            for (i in 0 until teamCount) {
                val isLocalCt = (playerTeam == TeamSide.CT && i == 0)
                combatants.add(
                    CombatantEntity(
                        id = if (isLocalCt) "local_player" else "ct_bot_$i",
                        name = if (isLocalCt) "YOU" else ctNames[i % ctNames.size],
                        team = TeamSide.CT,
                        isLocalPlayer = isLocalCt,
                        cash = mode.startCash
                    )
                )
            }
            for (i in 0 until teamCount) {
                val isLocalT = (playerTeam == TeamSide.T && i == 0)
                combatants.add(
                    CombatantEntity(
                        id = if (isLocalT) "local_player" else "t_bot_$i",
                        name = if (isLocalT) "YOU" else tNames[i % tNames.size],
                        team = TeamSide.T,
                        isLocalPlayer = isLocalT,
                        cash = mode.startCash
                    )
                )
            }

            beginRoundLocked(System.currentTimeMillis(), resetInventory = true)
            publishStatesLocked(System.currentTimeMillis(), 60)
        }
    }

    fun leaveMatch() {
        synchronized(lock) {
            moveForwardInput = 0f
            moveStrafeInput = 0f
            fireHeld = false
            bombActionHeld = false
            _hudState.value = MatchHudState(isInMatch = false)
        }
    }

    private fun beginRoundLocked(nowMs: Long, resetInventory: Boolean) {
        smokes.clear()
        grenades.clear()
        tracers.clear()
        plantedC4Pos = null
        plantedSiteLabel = null
        roundBannerText = null
        roundBannerTeam = null
        scopeLevel = 0
        recoilAccum = 0f
        playerBombProgressSec = 0f
        flashBlindAlpha = 0f

        phase = if (gameMode == GameMode.DEATHMATCH) RoundPhase.LIVE else RoundPhase.FREEZE_TIME
        phaseStartMs = nowMs
        roundDurationMs = gameMode.roundSeconds * 1000L

        var ctIdx = 0
        var tIdx = 0
        val tCombatants = combatants.filter { it.team == TeamSide.T }
        // Strip old C4 and assign to local T player (if T) or first T bot
        combatants.forEach { it.inventory.remove(WeaponSlot.C4) }
        if (gameMode.hasBombObjective && tCombatants.isNotEmpty()) {
            val carrier = tCombatants.find { it.isLocalPlayer } ?: tCombatants.first()
            carrier.inventory[WeaponSlot.C4] = WeaponInstance(WeaponId.C4_EXPLOSIVE)
        }

        for (entity in combatants) {
            entity.isAlive = true
            entity.hp = 100
            entity.velY = 0f
            entity.isCrouching = false
            entity.isReloading = false
            entity.blindedUntilMs = 0L
            entity.botPlantingProgressSec = 0f
            entity.botDefusingProgressSec = 0f

            if (resetInventory) {
                val hasC4 = entity.inventory.containsKey(WeaponSlot.C4)
                entity.inventory.clear()
                entity.armor = if (gameMode == GameMode.DEATHMATCH) 100 else 0
                entity.hasHelmet = gameMode == GameMode.DEATHMATCH
                entity.hasDefuseKit = false
                if (hasC4) entity.inventory[WeaponSlot.C4] = WeaponInstance(WeaponId.C4_EXPLOSIVE)
            }

            // Ensure knife + starter pistol + refill ammo
            entity.inventory[WeaponSlot.MELEE] = WeaponInstance(WeaponId.KNIFE)
            val starterPistol = if (entity.team == TeamSide.CT) WeaponId.USP_S else WeaponId.GLOCK_18
            val currentSec = entity.inventory[WeaponSlot.SECONDARY]?.weaponId ?: starterPistol
            entity.inventory[WeaponSlot.SECONDARY] = WeaponInstance(currentSec)
            entity.inventory[WeaponSlot.PRIMARY]?.let { pri ->
                entity.inventory[WeaponSlot.PRIMARY] = WeaponInstance(pri.weaponId)
            }

            if (entity.team == TeamSide.CT) {
                val sp = world.ctSpawns[ctIdx % world.ctSpawns.size]
                ctIdx++
                entity.x = sp.first
                entity.z = sp.second
                entity.footY = 0f
                entity.yawDeg = 0f // Face +0 / toward mid (-Z is CT side, wait: CT is at z=-24 facing +Z -> yaw=180!)
                entity.yawDeg = 180f
                entity.pitchDeg = 0f
                entity.targetWaypointId = listOf(1, 2, 3)[ctIdx % 3]
            } else {
                val sp = world.tSpawns[tIdx % world.tSpawns.size]
                tIdx++
                entity.x = sp.first
                entity.z = sp.second
                entity.footY = 0f
                entity.yawDeg = 0f // T is at z=+24 facing -Z -> yaw=0!
                entity.pitchDeg = 0f
                entity.targetWaypointId = listOf(10, 8, 11)[tIdx % 3]
            }

            if (!entity.isLocalPlayer) {
                BotCombatSystem.equipBotForRound(entity, gameMode, settings.preferredCtRifle)
            } else {
                entity.activeSlot = when {
                    entity.inventory.containsKey(WeaponSlot.PRIMARY) -> WeaponSlot.PRIMARY
                    else -> WeaponSlot.SECONDARY
                }
            }
        }
    }

    fun setMoveInput(forward: Float, strafe: Float) {
        synchronized(lock) {
            moveForwardInput = forward.coerceIn(-1f, 1f)
            moveStrafeInput = strafe.coerceIn(-1f, 1f)
        }
    }

    fun addLookDelta(deltaYawDeg: Float, deltaPitchDeg: Float) {
        synchronized(lock) {
            val player = localPlayerLocked() ?: return
            val scopeFactor = when (scopeLevel) {
                1 -> 0.48f
                2 -> 0.22f
                else -> 1.0f
            }
            player.yawDeg = (player.yawDeg + deltaYawDeg * scopeFactor) % 360f
            player.pitchDeg = (player.pitchDeg + deltaPitchDeg * scopeFactor).coerceIn(-82f, 82f)
        }
    }

    fun setFireHeld(held: Boolean) {
        synchronized(lock) {
            val wasHeld = fireHeld
            fireHeld = held
            if (held && !wasHeld) {
                tryFireLocalWeaponLocked(System.currentTimeMillis())
            }
        }
    }

    fun setBombActionHeld(held: Boolean) {
        synchronized(lock) {
            bombActionHeld = held
            if (!held) playerBombProgressSec = 0f
        }
    }

    fun jump() {
        synchronized(lock) {
            val player = localPlayerLocked() ?: return
            if (!player.isAlive || phase == RoundPhase.FREEZE_TIME) return
            val (_, _, supportY) = world.resolveMovement(player.x, player.z, player.footY, player.x, player.z)
            if (player.footY <= supportY + 0.08f) {
                player.velY = 6.4f
                player.isCrouching = false
            }
        }
    }

    fun toggleCrouch() {
        synchronized(lock) {
            val player = localPlayerLocked() ?: return
            player.isCrouching = !player.isCrouching
            publishStatesLocked(System.currentTimeMillis(), _hudState.value.fpsEstimate)
        }
    }

    fun cycleScope() {
        synchronized(lock) {
            val player = localPlayerLocked() ?: return
            val w = player.activeWeapon()?.weaponId ?: return
            if (w.hasScope) {
                scopeLevel = (scopeLevel + 1) % 3
                publishStatesLocked(System.currentTimeMillis(), _hudState.value.fpsEstimate)
            }
        }
    }

    fun reload() {
        synchronized(lock) {
            val player = localPlayerLocked() ?: return
            val inst = player.activeWeapon() ?: return
            if (!inst.weaponId.isFirearm() || player.isReloading) return
            if (inst.ammoInMag < inst.weaponId.magSize && inst.reserveAmmo > 0) {
                val now = System.currentTimeMillis()
                player.isReloading = true
                player.reloadStartMs = now
                scopeLevel = 0
                publishStatesLocked(now, _hudState.value.fpsEstimate)
            }
        }
    }

    fun triggerInspect() {
        synchronized(lock) {
            inspectStartMs = System.currentTimeMillis()
        }
    }

    fun selectSlot(slot: WeaponSlot) {
        synchronized(lock) {
            val player = localPlayerLocked() ?: return
            if (player.inventory.containsKey(slot)) {
                player.activeSlot = slot
                player.isReloading = false
                scopeLevel = 0
                publishStatesLocked(System.currentTimeMillis(), _hudState.value.fpsEstimate)
            }
        }
    }

    fun buyWeapon(weaponId: WeaponId): Boolean {
        synchronized(lock) {
            val player = localPlayerLocked() ?: return false
            if (!canPlayerBuyLocked(player)) return false
            if (weaponId.teamRestriction != null && weaponId.teamRestriction != player.team) return false
            val cost = if (gameMode == GameMode.DEATHMATCH) 0 else weaponId.price
            if (player.cash < cost) return false
            if (weaponId.isGrenade() && player.inventory.containsKey(weaponId.slot)) return false

            player.cash -= cost
            player.inventory[weaponId.slot] = WeaponInstance(weaponId)
            player.activeSlot = weaponId.slot
            player.isReloading = false
            scopeLevel = 0
            if (!lastBoughtWeapons.contains(weaponId)) {
                lastBoughtWeapons.add(weaponId)
            }
            publishStatesLocked(System.currentTimeMillis(), _hudState.value.fpsEstimate)
            return true
        }
    }

    fun buyArmor(withHelmet: Boolean): Boolean {
        synchronized(lock) {
            val player = localPlayerLocked() ?: return false
            if (!canPlayerBuyLocked(player)) return false
            val cost = when {
                gameMode == GameMode.DEATHMATCH -> 0
                withHelmet && player.armor >= 80 && !player.hasHelmet -> 350
                withHelmet -> 1000
                else -> 650
            }
            if (player.hasHelmet && player.armor == 100) return false
            if (!withHelmet && player.armor == 100) return false
            if (player.cash < cost) return false
            player.cash -= cost
            player.armor = 100
            if (withHelmet) player.hasHelmet = true
            publishStatesLocked(System.currentTimeMillis(), _hudState.value.fpsEstimate)
            return true
        }
    }

    fun buyDefuseKit(): Boolean {
        synchronized(lock) {
            val player = localPlayerLocked() ?: return false
            if (!canPlayerBuyLocked(player) || player.team != TeamSide.CT || player.hasDefuseKit) return false
            val cost = if (gameMode == GameMode.DEATHMATCH) 0 else 400
            if (player.cash < cost) return false
            player.cash -= cost
            player.hasDefuseKit = true
            publishStatesLocked(System.currentTimeMillis(), _hudState.value.fpsEstimate)
            return true
        }
    }

    fun rebuyPrevious() {
        synchronized(lock) {
            buyArmor(withHelmet = true)
            buyDefuseKit()
            val snapshot = lastBoughtWeapons.toList()
            snapshot.forEach { buyWeapon(it) }
        }
    }

    private fun canPlayerBuyLocked(player: CombatantEntity): Boolean {
        if (!player.isAlive) return false
        if (gameMode == GameMode.DEATHMATCH) return true
        val nowMs = System.currentTimeMillis()
        if (phase == RoundPhase.FREEZE_TIME) return true
        if (phase == RoundPhase.LIVE && nowMs - phaseStartMs <= 20_000L) {
            val inSpawn = if (player.team == TeamSide.CT) player.z < -17f else player.z > 17f
            return inSpawn
        }
        return false
    }

    fun stepSimulation(dtSec: Float, nowMs: Long, fpsEstimate: Int) {
        synchronized(lock) {
            if (!_hudState.value.isInMatch) return
            val dt = dtSec.coerceIn(0.001f, 0.05f)

            // Decay visual effects
            recoilAccum = (recoilAccum - dt * 5.2f).coerceAtLeast(0f)
            muzzleFlashAlpha = (muzzleFlashAlpha - dt * 14f).coerceAtLeast(0f)
            hitMarkerAlpha = (hitMarkerAlpha - dt * 4.5f).coerceAtLeast(0f)
            damageFlashAlpha = (damageFlashAlpha - dt * 3.0f).coerceAtLeast(0f)
            flashBlindAlpha = (flashBlindAlpha - dt * 0.65f).coerceAtLeast(0f)

            smokes.removeAll { nowMs >= it.expiresAtMs }
            tracers.removeAll { nowMs >= it.second }
            killFeed.removeAll { nowMs - it.timestampMs > 7_000L }

            updateRoundPhaseLocked(nowMs)
            updateLocalPlayerLocked(dt, nowMs)
            updateGrenadesLocked(dt, nowMs)

            for (entity in combatants) {
                if (!entity.isLocalPlayer) {
                    BotCombatSystem.stepBotAi(
                        bot = entity,
                        dt = dt,
                        nowMs = nowMs,
                        phase = phase,
                        world = world,
                        combatants = combatants,
                        smokes = smokes,
                        difficulty = difficulty,
                        plantedC4Pos = plantedC4Pos,
                        onBotFire = { shooter, dx, dy, dz ->
                            executeFireRayLocked(
                                shooter = shooter,
                                ox = shooter.x,
                                oy = shooter.footY + shooter.eyeHeight(),
                                oz = shooter.z,
                                dx = dx,
                                dy = dy,
                                dz = dz,
                                weapon = shooter.activeWeapon()?.weaponId ?: WeaponId.AK_47,
                                nowMs = nowMs
                            )
                        },
                        onBotPlantedC4 = { planter, site ->
                            plantC4AtSiteLocked(planter, site, nowMs)
                        },
                        onBotDefusedC4 = { defuser ->
                            completeC4DefuseLocked(defuser, nowMs)
                        }
                    )
                }
            }

            publishStatesLocked(nowMs, fpsEstimate)
        }
    }

    private fun updateRoundPhaseLocked(nowMs: Long) {
        when (phase) {
            RoundPhase.FREEZE_TIME -> {
                if (nowMs - phaseStartMs >= 4_500L) {
                    phase = RoundPhase.LIVE
                    phaseStartMs = nowMs
                }
            }
            RoundPhase.LIVE -> {
                if (gameMode == GameMode.DEATHMATCH) {
                    val local = localPlayerLocked()
                    if (local != null && !local.isAlive && dmRespawnAtMs > 0L && nowMs >= dmRespawnAtMs) {
                        respawnCombatantLocked(local)
                        dmRespawnAtMs = 0L
                    }
                    combatants.filter { !it.isLocalPlayer && !it.isAlive }.forEach {
                        respawnCombatantLocked(it)
                    }
                    if (nowMs - phaseStartMs >= roundDurationMs) {
                        phase = RoundPhase.MATCH_OVER
                        val topTeam = if (ctScore >= tScore) TeamSide.CT else TeamSide.T
                        roundBannerText = "DEATHMATCH COMPLETE"
                        roundBannerTeam = topTeam
                    }
                } else {
                    val ctAlive = combatants.count { it.team == TeamSide.CT && it.isAlive }
                    val tAlive = combatants.count { it.team == TeamSide.T && it.isAlive }
                    when {
                        ctAlive == 0 -> endRoundLocked(TeamSide.T, "TERRORISTS WIN", nowMs)
                        tAlive == 0 -> endRoundLocked(TeamSide.CT, "COUNTER-TERRORISTS WIN", nowMs)
                        nowMs - phaseStartMs >= roundDurationMs ->
                            endRoundLocked(TeamSide.CT, "TIME EXPIRED — CT WIN", nowMs)
                    }
                }
            }
            RoundPhase.BOMB_PLANTED -> {
                val elapsed = nowMs - bombPlantedAtMs
                val remainingMs = (40_000L - elapsed).coerceAtLeast(0L)
                val beepInterval = when {
                    remainingMs < 5_000L -> 180L
                    remainingMs < 12_000L -> 380L
                    else -> 820L
                }
                if (nowMs - lastBombBeepMs >= beepInterval) {
                    lastBombBeepMs = nowMs
                    audioEngine.playBombBeep(urgent = remainingMs < 8_000L)
                }

                val ctAlive = combatants.count { it.team == TeamSide.CT && it.isAlive }
                if (ctAlive == 0 && remainingMs > 2_000L) {
                    endRoundLocked(TeamSide.T, "TERRORISTS ELIMINATED CT", nowMs)
                } else if (remainingMs <= 0L) {
                    audioEngine.playExplosionOrSmoke(isSmoke = false)
                    endRoundLocked(TeamSide.T, "TARGET BOMBED — TERRORISTS WIN", nowMs)
                }
            }
            RoundPhase.ROUND_OVER -> {
                if (nowMs - phaseStartMs >= 3_400L) {
                    roundNumber++
                    // Halftime swap in Premier (after round 6) or Wingman (after round 4)
                    val swapRound = gameMode.roundsToWin
                    var resetInv = false
                    if (roundNumber == swapRound) {
                        val oldCt = ctScore
                        ctScore = tScore
                        tScore = oldCt
                        combatants.forEach {
                            it.team = it.team.opposite()
                            it.cash = gameMode.startCash
                        }
                        resetInv = true
                    }
                    beginRoundLocked(nowMs, resetInventory = resetInv)
                }
            }
            RoundPhase.MATCH_OVER -> Unit
        }
    }

    private fun endRoundLocked(winner: TeamSide, banner: String, nowMs: Long) {
        if (phase == RoundPhase.ROUND_OVER || phase == RoundPhase.MATCH_OVER) return
        if (winner == TeamSide.CT) {
            ctScore++
            ctLossStreak = 0
            tLossStreak = (tLossStreak + 1).coerceAtMost(4)
        } else {
            tScore++
            tLossStreak = 0
            ctLossStreak = (ctLossStreak + 1).coerceAtMost(4)
        }

        val ctReward = if (winner == TeamSide.CT) 3250 else 1400 + ctLossStreak * 500
        val tReward = if (winner == TeamSide.T) 3250 else 1400 + tLossStreak * 500
        combatants.forEach { c ->
            val add = if (c.team == TeamSide.CT) ctReward else tReward
            c.cash = (c.cash + add).coerceAtMost(16000)
        }

        val local = localPlayerLocked()
        if (local != null) {
            audioEngine.playRoundStinger(won = local.team == winner)
        }

        roundBannerText = banner
        roundBannerTeam = winner
        phaseStartMs = nowMs

        if (ctScore >= gameMode.roundsToWin || tScore >= gameMode.roundsToWin) {
            phase = RoundPhase.MATCH_OVER
            roundBannerText = "${winner.fullName.uppercase()} VICTORY ($ctScore : $tScore)"
        } else {
            phase = RoundPhase.ROUND_OVER
        }
    }

    private fun respawnCombatantLocked(entity: CombatantEntity) {
        entity.isAlive = true
        entity.hp = 100
        entity.armor = 100
        entity.hasHelmet = true
        entity.isReloading = false
        val spawns = if (entity.team == TeamSide.CT) world.ctSpawns else world.tSpawns
        val sp = spawns.random()
        entity.x = sp.first
        entity.z = sp.second
        entity.footY = 0f
        if (!entity.isLocalPlayer) {
            BotCombatSystem.equipBotForRound(entity, gameMode, settings.preferredCtRifle)
        } else {
            entity.inventory.entries.forEach { (slot, inst) ->
                entity.inventory[slot] = WeaponInstance(inst.weaponId)
            }
        }
    }

    private fun updateLocalPlayerLocked(dt: Float, nowMs: Long) {
        val player = localPlayerLocked() ?: return
        if (!player.isAlive) return

        // Reload completion
        val inst = player.activeWeapon()
        if (player.isReloading && inst != null) {
            if (nowMs - player.reloadStartMs >= inst.weaponId.reloadDurationMs) {
                val needed = inst.weaponId.magSize - inst.ammoInMag
                val take = needed.coerceAtMost(inst.reserveAmmo)
                player.inventory[player.activeSlot] = inst.copy(
                    ammoInMag = inst.ammoInMag + take,
                    reserveAmmo = inst.reserveAmmo - take
                )
                player.isReloading = false
            }
        }

        // Movement (locked during Freeze Time)
        if (phase != RoundPhase.FREEZE_TIME && phase != RoundPhase.MATCH_OVER) {
            val yawRad = player.yawDeg * (PI.toFloat() / 180f)
            val fwdX = sin(yawRad)
            val fwdZ = -cos(yawRad)
            val rightX = cos(yawRad)
            val rightZ = sin(yawRad)

            val weaponSpeed = inst?.weaponId?.moveSpeedFactor ?: 1f
            val crouchFactor = if (player.isCrouching) 0.54f else 1.0f
            val scopeFactor = if (scopeLevel > 0) 0.62f else 1.0f
            val baseSpeed = 5.6f * weaponSpeed * crouchFactor * scopeFactor

            val wishX = fwdX * moveForwardInput + rightX * moveStrafeInput
            val wishZ = fwdZ * moveForwardInput + rightZ * moveStrafeInput
            val wishMag = sqrt(wishX * wishX + wishZ * wishZ)
            val scale = if (wishMag > 1f) 1f / wishMag else 1f

            val targetX = player.x + wishX * scale * baseSpeed * dt
            val targetZ = player.z + wishZ * scale * baseSpeed * dt

            // Gravity & vertical jump physics
            player.velY -= 17.5f * dt
            player.footY += player.velY * dt

            val (rx, rz, supportY) = world.resolveMovement(
                oldX = player.x,
                oldZ = player.z,
                footY = player.footY,
                targetX = targetX,
                targetZ = targetZ,
                bodyHeight = player.bodyHeight()
            )
            player.x = rx
            player.z = rz
            if (player.footY <= supportY) {
                player.footY = supportY
                player.velY = 0f
            }

            if (wishMag > 0.12f && player.footY <= supportY + 0.05f) {
                walkBobPhase += dt * 10.5f * wishMag.coerceAtMost(1f)
            }
        }

        // Plant or Defuse C4 action
        val site = world.bombSiteAt(player.x, player.z)
        val canPlant = player.team == TeamSide.T &&
            phase == RoundPhase.LIVE &&
            site != null &&
            player.inventory.containsKey(WeaponSlot.C4)
        val canDefuse = player.team == TeamSide.CT &&
            phase == RoundPhase.BOMB_PLANTED &&
            plantedC4Pos != null &&
            ((player.x - plantedC4Pos!!.first) * (player.x - plantedC4Pos!!.first) +
                (player.z - plantedC4Pos!!.third) * (player.z - plantedC4Pos!!.third)) <= 3.0f * 3.0f

        if (bombActionHeld && canPlant && site != null) {
            playerBombProgressSec += dt
            if (playerBombProgressSec >= 3.0f) {
                playerBombProgressSec = 0f
                bombActionHeld = false
                plantC4AtSiteLocked(player, site, nowMs)
            }
        } else if (bombActionHeld && canDefuse) {
            playerBombProgressSec += dt
            val req = if (player.hasDefuseKit) 4.5f else 8.0f
            if (playerBombProgressSec >= req) {
                playerBombProgressSec = 0f
                bombActionHeld = false
                completeC4DefuseLocked(player, nowMs)
            }
        } else {
            playerBombProgressSec = 0f
        }

        // Sustained automatic fire or Auto-Fire on Target
        if (fireHeld && inst?.weaponId?.isAutomatic == true) {
            tryFireLocalWeaponLocked(nowMs)
        } else if (settings.autoFireOnTarget && !fireHeld && phase != RoundPhase.FREEZE_TIME) {
            if (isCrosshairOnVisibleEnemyLocked(player, nowMs)) {
                tryFireLocalWeaponLocked(nowMs)
            }
        }
    }

    private fun isCrosshairOnVisibleEnemyLocked(player: CombatantEntity, nowMs: Long): Boolean {
        val (dx, dy, dz) = lookVector(player.yawDeg, player.pitchDeg)
        val ox = player.x
        val oy = player.footY + player.eyeHeight()
        val oz = player.z
        val wallDist = world.raycastWorld(ox, oy, oz, dx, dy, dz, 45f)
        for (other in combatants) {
            if (!other.isAlive || other.team == player.team) continue
            val box = Box3D(
                other.x - 0.36f, other.footY, other.z - 0.36f,
                other.x + 0.36f, other.footY + other.bodyHeight(), other.z + 0.36f
            )
            val t = ArenaWorld.intersectRayAabb(ox, oy, oz, dx, dy, dz, box, wallDist)
            if (t > 0f && t < wallDist) {
                val blockedBySmoke = smokes.any { it.blocksRay(ox, oy, oz, dx, dy, dz, t, nowMs) }
                if (!blockedBySmoke) return true
            }
        }
        return false
    }

    private fun tryFireLocalWeaponLocked(nowMs: Long) {
        val player = localPlayerLocked() ?: return
        if (!player.isAlive || phase == RoundPhase.FREEZE_TIME || phase == RoundPhase.MATCH_OVER) return
        val inst = player.activeWeapon() ?: return
        val weapon = inst.weaponId
        if (player.isReloading || nowMs - player.lastFireMs < weapon.fireIntervalMs) return

        if (weapon == WeaponId.C4_EXPLOSIVE) {
            val site = world.bombSiteAt(player.x, player.z)
            if (site != null && phase == RoundPhase.LIVE) {
                plantC4AtSiteLocked(player, site, nowMs)
            }
            return
        }

        if (weapon.isGrenade()) {
            player.lastFireMs = nowMs
            player.inventory.remove(weapon.slot)
            player.activeSlot = if (player.inventory.containsKey(WeaponSlot.PRIMARY)) {
                WeaponSlot.PRIMARY
            } else {
                WeaponSlot.SECONDARY
            }
            val (dx, dy, dz) = lookVector(player.yawDeg, player.pitchDeg)
            grenades.add(
                FlyingGrenadeEntity(
                    id = ++idCounter,
                    throwerId = player.id,
                    weaponId = weapon,
                    x = player.x + dx * 0.6f,
                    y = player.footY + player.eyeHeight() - 0.1f,
                    z = player.z + dz * 0.6f,
                    vx = dx * 15.5f,
                    vy = dy * 15.5f + 3.2f,
                    vz = dz * 15.5f,
                    detonateAtMs = nowMs + 1450L
                )
            )
            audioEngine.playWeaponFire(WeaponId.KNIFE)
            return
        }

        if (weapon != WeaponId.KNIFE && inst.ammoInMag <= 0) {
            reload()
            return
        }

        player.lastFireMs = nowMs
        if (weapon != WeaponId.KNIFE) {
            player.inventory[player.activeSlot] = inst.copy(ammoInMag = inst.ammoInMag - 1)
        }

        audioEngine.playWeaponFire(weapon)
        muzzleFlashAlpha = if (weapon == WeaponId.KNIFE) 0f else 1f

        val movePenalty = sqrt(moveForwardInput * moveForwardInput + moveStrafeInput * moveStrafeInput) *
            (if (player.isCrouching) 0.008f else 0.024f)
        val scopeBonus = if (scopeLevel > 0) 0.15f else (if (weapon.hasScope) 3.6f else 1.0f)
        val totalSpread = (weapon.baseSpread * scopeBonus) + movePenalty + recoilAccum * 0.008f

        val pitchWithRecoil = (player.pitchDeg + recoilAccum * 1.1f).coerceIn(-85f, 85f)
        val (bx, by, bz) = lookVector(player.yawDeg, pitchWithRecoil)
        val sx = bx + (Random.nextFloat() * 2f - 1f) * totalSpread
        val sy = by + (Random.nextFloat() * 2f - 1f) * totalSpread
        val sz = bz + (Random.nextFloat() * 2f - 1f) * totalSpread
        val norm = sqrt(sx * sx + sy * sy + sz * sz).coerceAtLeast(0.001f)

        val range = if (weapon == WeaponId.KNIFE) 2.55f else 90f
        executeFireRayLocked(
            shooter = player,
            ox = player.x,
            oy = player.footY + player.eyeHeight(),
            oz = player.z,
            dx = sx / norm,
            dy = sy / norm,
            dz = sz / norm,
            weapon = weapon,
            nowMs = nowMs,
            maxRange = range
        )

        // Apply CS2 camera recoil kick & spray accumulation
        recoilAccum = (recoilAccum + weapon.recoilPitchKick * 0.55f).coerceAtMost(7.5f)
        player.pitchDeg = (player.pitchDeg + weapon.recoilPitchKick * 0.42f).coerceIn(-82f, 82f)
        player.yawDeg += (Random.nextFloat() * 2f - 1f) * weapon.recoilYawVariance * 0.35f

        if (weapon == WeaponId.AWP || weapon == WeaponId.SSG_08) {
            scopeLevel = 0
        }
    }

    private fun executeFireRayLocked(
        shooter: CombatantEntity,
        ox: Float,
        oy: Float,
        oz: Float,
        dx: Float,
        dy: Float,
        dz: Float,
        weapon: WeaponId,
        nowMs: Long,
        maxRange: Float = 90f
    ) {
        val result = BotCombatSystem.performHitscan(
            shooter = shooter,
            world = world,
            combatants = combatants,
            smokes = smokes,
            ox = ox,
            oy = oy,
            oz = oz,
            dx = dx,
            dy = dy,
            dz = dz,
            weapon = weapon,
            maxRange = maxRange,
            nowMs = nowMs
        )

        if (weapon != WeaponId.KNIFE) {
            tracers.add(
                Pair(
                    TracerRenderItem(
                        startX = ox + dx * 0.45f,
                        startY = oy - 0.12f,
                        startZ = oz + dz * 0.45f,
                        endX = result.hitX,
                        endY = result.hitY,
                        endZ = result.hitZ,
                        alpha = 0.85f
                    ),
                    nowMs + 95L
                )
            )
        }

        if (result.passedThroughSmoke && shooter.isLocalPlayer) {
            smokeCarvedUntilMs = nowMs + 1400L
        }

        val victim = result.victim ?: return
        applyDamageLocked(
            attacker = shooter,
            victim = victim,
            damage = result.damageDealt,
            weapon = weapon,
            isHeadshot = result.isHeadshot,
            throughSmoke = result.passedThroughSmoke,
            nowMs = nowMs
        )
    }

    private fun applyDamageLocked(
        attacker: CombatantEntity,
        victim: CombatantEntity,
        damage: Int,
        weapon: WeaponId,
        isHeadshot: Boolean,
        throughSmoke: Boolean,
        nowMs: Long
    ) {
        if (!victim.isAlive) return
        victim.hp = (victim.hp - damage).coerceAtLeast(0)

        if (attacker.isLocalPlayer) {
            hitMarkerAlpha = 1f
            hitMarkerHeadshot = isHeadshot
            audioEngine.playHitMarker(isHeadshot)
        }
        if (victim.isLocalPlayer) {
            damageFlashAlpha = 0.78f
        }

        if (victim.hp == 0) {
            victim.isAlive = false
            victim.deaths++
            victim.isReloading = false
            attacker.kills++
            attacker.cash = (attacker.cash + weapon.killReward).coerceAtMost(16000)

            if (gameMode == GameMode.DEATHMATCH) {
                if (attacker.team == TeamSide.CT) ctScore++ else tScore++
                if (victim.isLocalPlayer) {
                    dmRespawnAtMs = nowMs + 2_000L
                }
            } else if (victim.inventory.containsKey(WeaponSlot.C4)) {
                victim.inventory.remove(WeaponSlot.C4)
                val otherT = combatants.firstOrNull { it.team == TeamSide.T && it.isAlive }
                otherT?.inventory?.put(WeaponSlot.C4, WeaponInstance(WeaponId.C4_EXPLOSIVE))
            }

            killFeed.add(
                0,
                KillFeedEntry(
                    id = ++idCounter,
                    killerName = attacker.name,
                    killerTeam = attacker.team,
                    victimName = victim.name,
                    victimTeam = victim.team,
                    weaponName = weapon.shortCode,
                    isHeadshot = isHeadshot,
                    throughSmoke = throughSmoke,
                    timestampMs = nowMs
                )
            )
            if (killFeed.size > 5) {
                killFeed.removeAt(killFeed.lastIndex)
            }
        }
    }

    private fun updateGrenadesLocked(dt: Float, nowMs: Long) {
        val iter = grenades.iterator()
        while (iter.hasNext()) {
            val g = iter.next()
            g.vy -= 15.5f * dt
            val nx = g.x + g.vx * dt
            val ny = g.y + g.vy * dt
            val nz = g.z + g.vz * dt

            // Bounce off ground
            if (ny <= 0.18f) {
                g.y = 0.18f
                g.vy = -g.vy * 0.45f
                g.vx *= 0.72f
                g.vz *= 0.72f
            } else {
                g.y = ny
            }

            // Bounce off world walls
            val hitX = world.boxes.any { b ->
                b.solid && ny in b.minY..b.maxY &&
                    nx in (b.minX - 0.18f)..(b.maxX + 0.18f) &&
                    g.z in (b.minZ - 0.18f)..(b.maxZ + 0.18f)
            }
            if (hitX) g.vx = -g.vx * 0.55f else g.x = nx

            val hitZ = world.boxes.any { b ->
                b.solid && ny in b.minY..b.maxY &&
                    g.x in (b.minX - 0.18f)..(b.maxX + 0.18f) &&
                    nz in (b.minZ - 0.18f)..(b.maxZ + 0.18f)
            }
            if (hitZ) g.vz = -g.vz * 0.55f else g.z = nz

            if (nowMs >= g.detonateAtMs) {
                iter.remove()
                detonateGrenadeLocked(g, nowMs)
            }
        }
    }

    private fun detonateGrenadeLocked(g: FlyingGrenadeEntity, nowMs: Long) {
        val thrower = combatants.find { it.id == g.throwerId } ?: combatants.firstOrNull() ?: return
        when (g.weaponId) {
            WeaponId.SMOKE_GRENADE -> {
                audioEngine.playExplosionOrSmoke(isSmoke = true)
                smokes.add(
                    VolumetricSmokeCloud(
                        id = ++idCounter,
                        centerX = g.x,
                        centerY = g.y,
                        centerZ = g.z,
                        createdAtMs = nowMs,
                        expiresAtMs = nowMs + 18_000L
                    )
                )
            }
            WeaponId.HE_GRENADE -> {
                audioEngine.playExplosionOrSmoke(isSmoke = false)
                // CS2 mechanic: HE grenade blasts volumetric smokes open for 2.8 seconds!
                for (smoke in smokes) {
                    val dx = smoke.centerX - g.x
                    val dz = smoke.centerZ - g.z
                    if (dx * dx + dz * dz <= 6.2f * 6.2f) {
                        smoke.dispersedUntilMs = nowMs + 2_800L
                        smokeCarvedUntilMs = nowMs + 2_800L
                    }
                }
                for (c in combatants) {
                    if (!c.isAlive || (c.team == thrower.team && c.id != thrower.id)) continue
                    val dx = c.x - g.x
                    val dy = (c.footY + 0.9f) - g.y
                    val dz = c.z - g.z
                    val dist = sqrt(dx * dx + dy * dy + dz * dz)
                    if (dist <= 6.8f) {
                        val dmg = ((1f - dist / 6.8f) * 94f).toInt().coerceAtLeast(4)
                        applyDamageLocked(thrower, c, dmg, WeaponId.HE_GRENADE, false, false, nowMs)
                    }
                }
            }
            WeaponId.FLASHBANG -> {
                audioEngine.playHitMarker(isHeadshot = false)
                for (c in combatants) {
                    if (!c.isAlive) continue
                    val dx = g.x - c.x
                    val dy = g.y - (c.footY + c.eyeHeight())
                    val dz = g.z - c.z
                    val dist = sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(0.1f)
                    if (dist <= 22f) {
                        val wall = world.raycastWorld(
                            c.x, c.footY + c.eyeHeight(), c.z,
                            dx / dist, dy / dist, dz / dist, dist
                        )
                        if (wall >= dist - 0.3f) {
                            val (lx, ly, lz) = lookVector(c.yawDeg, c.pitchDeg)
                            val dot = (dx / dist) * lx + (dy / dist) * ly + (dz / dist) * lz
                            if (c.isLocalPlayer && dot > 0.1f) {
                                flashBlindAlpha = (dot * 1.15f).coerceIn(0.35f, 0.96f)
                            } else if (!c.isLocalPlayer && dot > -0.1f) {
                                c.blindedUntilMs = nowMs + 2_400L
                            }
                        }
                    }
                }
            }
            else -> Unit
        }
    }

    private fun plantC4AtSiteLocked(planter: CombatantEntity, site: BombSiteZone, nowMs: Long) {
        if (phase != RoundPhase.LIVE) return
        planter.inventory.remove(WeaponSlot.C4)
        if (planter.activeSlot == WeaponSlot.C4) {
            planter.activeSlot = if (planter.inventory.containsKey(WeaponSlot.PRIMARY)) {
                WeaponSlot.PRIMARY
            } else {
                WeaponSlot.SECONDARY
            }
        }
        planter.cash = (planter.cash + 300).coerceAtMost(16000)
        plantedC4Pos = Triple(planter.x, planter.footY + 0.08f, planter.z)
        plantedSiteLabel = site.label
        bombPlantedAtMs = nowMs
        lastBombBeepMs = nowMs
        phase = RoundPhase.BOMB_PLANTED
        audioEngine.playBombBeep(urgent = true)
    }

    private fun completeC4DefuseLocked(defuser: CombatantEntity, nowMs: Long) {
        if (phase != RoundPhase.BOMB_PLANTED) return
        defuser.cash = (defuser.cash + 300).coerceAtMost(16000)
        endRoundLocked(TeamSide.CT, "BOMB HAS BEEN DEFUSED — CT WIN", nowMs)
    }

    private fun publishStatesLocked(nowMs: Long, fpsEstimate: Int) {
        val player = localPlayerLocked() ?: return
        // Spectate surviving teammate if local player eliminated
        val camTarget = if (player.isAlive) {
            player
        } else {
            combatants.firstOrNull { it.team == player.team && it.isAlive } ?: player
        }

        val activeInst = camTarget.activeWeapon()
        val activeWep = activeInst?.weaponId ?: WeaponId.KNIFE
        val reloadProg = if (camTarget.isReloading && activeWep.reloadDurationMs > 0L) {
            ((nowMs - camTarget.reloadStartMs).toFloat() / activeWep.reloadDurationMs).coerceIn(0f, 1f)
        } else 0f

        val inspectProg = if (inspectStartMs > 0L && nowMs - inspectStartMs < 1800L) {
            (nowMs - inspectStartMs).toFloat() / 1800f
        } else 0f

        val fov = when (scopeLevel) {
            1 -> 34f
            2 -> 15f
            else -> 74f
        }

        // Build volumetric 3D smoke puffs with dynamic CS2 bullet-hole carving & HE dispersal!
        val smokePuffs = buildList {
            for (cloud in smokes) {
                val ageMs = nowMs - cloud.createdAtMs
                val bloom = (ageMs / 420f).coerceIn(0.2f, 1f)
                val fadeOut = ((cloud.expiresAtMs - nowMs) / 1500f).coerceIn(0f, 1f)
                val dispersed = cloud.isDispersed(nowMs)
                val puffOffsets = SMOKE_PUFF_OFFSETS
                for (off in puffOffsets) {
                    val scatter = if (dispersed) 2.25f else 1.0f
                    val px = cloud.centerX + off[0] * cloud.radius * bloom * scatter
                    val py = (cloud.centerY + 0.65f + off[1] * 2.1f * bloom).coerceAtLeast(0.4f)
                    val pz = cloud.centerZ + off[2] * cloud.radius * bloom * scatter
                    var sizeFactor = if (dispersed) 0.28f else 1.0f

                    // Carve holes along recent bullet rays!
                    for (ray in cloud.carveRays) {
                        if (nowMs < ray.expiresAtMs) {
                            val vx = px - ray.ox
                            val vy = py - ray.oy
                            val vz = pz - ray.oz
                            val proj = (vx * ray.dx + vy * ray.dy + vz * ray.dz).coerceAtLeast(0f)
                            val cx = ray.ox + ray.dx * proj
                            val cy = ray.oy + ray.dy * proj
                            val cz = ray.oz + ray.dz * proj
                            val dSq = (px - cx) * (px - cx) + (py - cy) * (py - cy) + (pz - cz) * (pz - cz)
                            if (dSq < 1.35f * 1.35f) {
                                sizeFactor *= 0.18f
                            }
                        }
                    }

                    if (sizeFactor > 0.2f) {
                        add(
                            SmokePuffRenderItem(
                                x = px,
                                y = py,
                                z = pz,
                                size = 1.65f * bloom * sizeFactor,
                                alpha = (0.78f * fadeOut * (if (dispersed) 0.25f else 1f))
                            )
                        )
                    }
                }
            }
        }

        latestRenderSnapshot = RenderFrameSnapshot(
            mapId = world.mapId,
            camX = camTarget.x,
            camY = camTarget.footY + camTarget.eyeHeight(),
            camZ = camTarget.z,
            camYawDeg = camTarget.yawDeg,
            camPitchDeg = camTarget.pitchDeg,
            fovYDeg = fov,
            activeWeapon = activeWep,
            weaponFinish = settings.globalWeaponFinish,
            leftHanded = settings.leftHandedViewmodel,
            recoilKickOffset = (recoilAccum / 7.5f).coerceIn(0f, 1f),
            walkBobPhase = walkBobPhase,
            reloadProgress = reloadProg,
            inspectProgress = inspectProg,
            muzzleFlashIntensity = muzzleFlashAlpha,
            isScoped = scopeLevel > 0,
            combatants = combatants.filter { it.id != camTarget.id && it.isAlive }.map { c ->
                CombatantRenderItem(
                    id = c.id,
                    team = c.team,
                    x = c.x,
                    footY = c.footY,
                    z = c.z,
                    yawDeg = c.yawDeg,
                    isCrouching = c.isCrouching,
                    isAlive = c.isAlive,
                    weaponId = c.activeWeapon()?.weaponId ?: WeaponId.AK_47,
                    isTeammate = c.team == player.team
                )
            },
            smokePuffs = smokePuffs,
            grenades = grenades.map { GrenadeRenderItem(it.x, it.y, it.z, it.weaponId) },
            tracers = tracers.map { it.first },
            plantedC4Pos = plantedC4Pos,
            c4BlinkOn = ((nowMs / 250L) % 2L == 0L)
        )

        val remainingSec = when (phase) {
            RoundPhase.FREEZE_TIME -> ((4_500L - (nowMs - phaseStartMs)) / 1000L).toInt().coerceAtLeast(0)
            RoundPhase.LIVE -> ((roundDurationMs - (nowMs - phaseStartMs)) / 1000L).toInt().coerceAtLeast(0)
            RoundPhase.BOMB_PLANTED -> ((40_000L - (nowMs - bombPlantedAtMs)) / 1000L).toInt().coerceAtLeast(0)
            else -> 0
        }

        val siteNow = world.bombSiteAt(player.x, player.z)
        val canPlantNow = player.isAlive &&
            player.team == TeamSide.T &&
            phase == RoundPhase.LIVE &&
            siteNow != null &&
            player.inventory.containsKey(WeaponSlot.C4)
        val canDefuseNow = player.isAlive &&
            player.team == TeamSide.CT &&
            phase == RoundPhase.BOMB_PLANTED &&
            plantedC4Pos != null &&
            ((player.x - plantedC4Pos!!.first) * (player.x - plantedC4Pos!!.first) +
                (player.z - plantedC4Pos!!.third) * (player.z - plantedC4Pos!!.third)) <= 3.0f * 3.0f

        val reqTime = if (canPlantNow) 3.0f else if (player.hasDefuseKit) 4.5f else 8.0f
        val moveAmt = sqrt(moveForwardInput * moveForwardInput + moveStrafeInput * moveStrafeInput)
        val spreadRatio = ((moveAmt * 0.45f) + (recoilAccum / 7.5f) * 0.75f).coerceIn(0f, 1f)

        _hudState.value = MatchHudState(
            isInMatch = true,
            mapId = world.mapId,
            gameMode = gameMode,
            playerTeam = player.team,
            roundNumber = roundNumber,
            ctScore = ctScore,
            tScore = tScore,
            phase = phase,
            timerSeconds = remainingSec,
            bombCountdownProgress = if (phase == RoundPhase.BOMB_PLANTED) {
                ((40_000L - (nowMs - bombPlantedAtMs)) / 40_000f).coerceIn(0f, 1f)
            } else 1f,
            plantedSiteLabel = plantedSiteLabel,
            ctAliveCount = combatants.count { it.team == TeamSide.CT && it.isAlive },
            tAliveCount = combatants.count { it.team == TeamSide.T && it.isAlive },
            playerHp = player.hp,
            playerArmor = player.armor,
            hasHelmet = player.hasHelmet,
            hasDefuseKit = player.hasDefuseKit,
            cash = player.cash,
            activeSlot = player.activeSlot,
            equippedWeapons = player.inventory.toMap(),
            isReloading = player.isReloading,
            reloadProgress = reloadProg,
            scopeLevel = scopeLevel,
            isCrouching = player.isCrouching,
            dynamicSpreadRatio = spreadRatio,
            hitMarkerAlpha = hitMarkerAlpha,
            hitMarkerHeadshot = hitMarkerHeadshot,
            damageFlashAlpha = damageFlashAlpha,
            flashbangBlindAlpha = flashBlindAlpha,
            currentCallout = world.calloutAt(player.x, player.z),
            canBuyNow = canPlayerBuyLocked(player),
            canPlantC4Now = canPlantNow,
            canDefuseC4Now = canDefuseNow,
            bombActionProgress = (playerBombProgressSec / reqTime).coerceIn(0f, 1f),
            roundBannerText = roundBannerText,
            roundBannerTeam = roundBannerTeam,
            smokeCarvedNotice = nowMs < smokeCarvedUntilMs,
            killFeed = killFeed.toList(),
            scoreboard = combatants.map { c ->
                ScoreboardEntry(
                    id = c.id,
                    name = c.name,
                    team = c.team,
                    isLocalPlayer = c.isLocalPlayer,
                    isAlive = c.isAlive,
                    hp = c.hp,
                    kills = c.kills,
                    deaths = c.deaths,
                    assists = c.assists,
                    cash = c.cash,
                    hasC4 = c.inventory.containsKey(WeaponSlot.C4),
                    hasDefuseKit = c.hasDefuseKit
                )
            },
            radarBlips = combatants.filter { it.isAlive }.map { c ->
                RadarBlip(
                    x = c.x,
                    z = c.z,
                    team = c.team,
                    isLocal = c.isLocalPlayer,
                    isAlive = c.isAlive,
                    yawDeg = c.yawDeg
                )
            },
            radarSmokes = smokes.map {
                RadarSmokeZone(it.centerX, it.centerZ, it.radius, it.isDispersed(nowMs))
            },
            c4WorldPos = plantedC4Pos?.let { Pair(it.first, it.third) }
                ?: combatants.firstOrNull { it.inventory.containsKey(WeaponSlot.C4) }
                    ?.takeIf { player.team == TeamSide.T }
                    ?.let { Pair(it.x, it.z) },
            fpsEstimate = fpsEstimate
        )
    }

    private fun localPlayerLocked(): CombatantEntity? =
        combatants.firstOrNull { it.isLocalPlayer }

    private fun lookVector(yawDeg: Float, pitchDeg: Float): Triple<Float, Float, Float> {
        val yawRad = yawDeg * (PI.toFloat() / 180f)
        val pitchRad = pitchDeg * (PI.toFloat() / 180f)
        val cosP = cos(pitchRad)
        return Triple(
            sin(yawRad) * cosP,
            sin(pitchRad),
            -cos(yawRad) * cosP
        )
    }

    companion object {
        // 19 volumetric puff offsets inside unit sphere for lush 3D smoke clouds
        private val SMOKE_PUFF_OFFSETS = arrayOf(
            floatArrayOf(0f, 0.2f, 0f),
            floatArrayOf(0.55f, 0.1f, 0f),
            floatArrayOf(-0.55f, 0.1f, 0f),
            floatArrayOf(0f, 0.1f, 0.55f),
            floatArrayOf(0f, 0.1f, -0.55f),
            floatArrayOf(0.42f, 0.45f, 0.42f),
            floatArrayOf(-0.42f, 0.45f, 0.42f),
            floatArrayOf(0.42f, 0.45f, -0.42f),
            floatArrayOf(-0.42f, 0.45f, -0.42f),
            floatArrayOf(0.78f, 0.05f, 0.25f),
            floatArrayOf(-0.78f, 0.05f, -0.25f),
            floatArrayOf(0.25f, 0.05f, 0.78f),
            floatArrayOf(-0.25f, 0.05f, -0.78f),
            floatArrayOf(0f, 0.78f, 0f),
            floatArrayOf(0.32f, 0.72f, -0.22f),
            floatArrayOf(-0.32f, 0.72f, 0.22f)
        )
    }
}

package com.example.engine

import com.example.model.ArenaMapId
import com.example.model.TeamSide
import com.example.model.WeaponFinish
import com.example.model.WeaponId
import com.example.model.WeaponInstance
import com.example.model.WeaponSlot

class CombatantEntity(
    val id: String,
    val name: String,
    var team: TeamSide,
    val isLocalPlayer: Boolean,
    var x: Float = 0f,
    var footY: Float = 0f,
    var z: Float = 0f,
    var velY: Float = 0f,
    var yawDeg: Float = 0f,
    var pitchDeg: Float = 0f,
    var hp: Int = 100,
    var armor: Int = 0,
    var hasHelmet: Boolean = false,
    var hasDefuseKit: Boolean = false,
    var cash: Int = 800,
    var isAlive: Boolean = true,
    var isCrouching: Boolean = false,
    var kills: Int = 0,
    var deaths: Int = 0,
    var assists: Int = 0,
    var activeSlot: WeaponSlot = WeaponSlot.SECONDARY,
    val inventory: MutableMap<WeaponSlot, WeaponInstance> = mutableMapOf(),
    var lastFireMs: Long = 0L,
    var reloadStartMs: Long = 0L,
    var isReloading: Boolean = false,
    // Bot AI state
    var targetWaypointId: Int = 5,
    var strafeDir: Float = 1f,
    var nextStrafeFlipMs: Long = 0L,
    var spottedEnemySinceMs: Long = 0L,
    var blindedUntilMs: Long = 0L,
    var botPlantingProgressSec: Float = 0f,
    var botDefusingProgressSec: Float = 0f
) {
    fun eyeHeight(): Float = if (isCrouching) 1.15f else 1.62f
    fun bodyHeight(): Float = if (isCrouching) 1.30f else 1.80f
    fun activeWeapon(): WeaponInstance? = inventory[activeSlot]
}

data class SmokeCarveRay(
    val ox: Float,
    val oy: Float,
    val oz: Float,
    val dx: Float,
    val dy: Float,
    val dz: Float,
    val expiresAtMs: Long
)

class VolumetricSmokeCloud(
    val id: Long,
    val centerX: Float,
    val centerY: Float,
    val centerZ: Float,
    val createdAtMs: Long,
    val expiresAtMs: Long,
    var dispersedUntilMs: Long = 0L,
    val carveRays: MutableList<SmokeCarveRay> = mutableListOf()
) {
    val radius: Float = 3.9f

    fun isDispersed(nowMs: Long): Boolean = nowMs < dispersedUntilMs

    /**
     * Checks if a sightline ray is blocked by this volumetric smoke (unless dispersed by HE or carved by bullets).
     */
    fun blocksRay(
        ox: Float,
        oy: Float,
        oz: Float,
        dx: Float,
        dy: Float,
        dz: Float,
        dist: Float,
        nowMs: Long
    ): Boolean {
        if (nowMs >= expiresAtMs || isDispersed(nowMs)) return false
        // Closest point on ray [0..dist] to smoke center
        val vx = centerX - ox
        val vy = (centerY + 1.2f) - oy
        val vz = centerZ - oz
        val proj = (vx * dx + vy * dy + vz * dz).coerceIn(0f, dist)
        val cx = ox + dx * proj
        val cy = oy + dy * proj
        val cz = oz + dz * proj
        val distSq =
            (cx - centerX) * (cx - centerX) +
                (cy - (centerY + 1.2f)) * (cy - (centerY + 1.2f)) +
                (cz - centerZ) * (cz - centerZ)
        if (distSq > radius * radius * 0.72f) return false

        // If a recent bullet carved a hole very close to this ray, sightline is open!
        for (carve in carveRays) {
            if (nowMs < carve.expiresAtMs) {
                val dot = dx * carve.dx + dy * carve.dy + dz * carve.dz
                if (dot > 0.992f) return false
            }
        }
        return true
    }
}

class FlyingGrenadeEntity(
    val id: Long,
    val throwerId: String,
    val weaponId: WeaponId,
    var x: Float,
    var y: Float,
    var z: Float,
    var vx: Float,
    var vy: Float,
    var vz: Float,
    val detonateAtMs: Long
)

data class TracerRenderItem(
    val startX: Float,
    val startY: Float,
    val startZ: Float,
    val endX: Float,
    val endY: Float,
    val endZ: Float,
    val alpha: Float
)

data class CombatantRenderItem(
    val id: String,
    val team: TeamSide,
    val x: Float,
    val footY: Float,
    val z: Float,
    val yawDeg: Float,
    val isCrouching: Boolean,
    val isAlive: Boolean,
    val weaponId: WeaponId,
    val isTeammate: Boolean
)

data class SmokePuffRenderItem(
    val x: Float,
    val y: Float,
    val z: Float,
    val size: Float,
    val alpha: Float
)

data class GrenadeRenderItem(
    val x: Float,
    val y: Float,
    val z: Float,
    val weaponId: WeaponId
)

data class RenderFrameSnapshot(
    val mapId: ArenaMapId,
    val camX: Float,
    val camY: Float,
    val camZ: Float,
    val camYawDeg: Float,
    val camPitchDeg: Float,
    val fovYDeg: Float,
    val activeWeapon: WeaponId,
    val weaponFinish: WeaponFinish,
    val leftHanded: Boolean,
    val recoilKickOffset: Float,
    val walkBobPhase: Float,
    val reloadProgress: Float,
    val inspectProgress: Float,
    val muzzleFlashIntensity: Float,
    val isScoped: Boolean,
    val combatants: List<CombatantRenderItem>,
    val smokePuffs: List<SmokePuffRenderItem>,
    val grenades: List<GrenadeRenderItem>,
    val tracers: List<TracerRenderItem>,
    val plantedC4Pos: Triple<Float, Float, Float>?,
    val c4BlinkOn: Boolean
)

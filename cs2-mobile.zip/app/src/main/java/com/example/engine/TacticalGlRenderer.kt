package com.example.engine

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.example.model.ArenaMapId
import com.example.model.TeamSide
import com.example.model.WeaponId
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

class TacticalGlRenderer(
    private val snapshotProvider: () -> RenderFrameSnapshot
) : GLSurfaceView.Renderer {

    private var programId = 0
    private var aPositionLoc = 0
    private var aNormalLoc = 0
    private var uMvpMatrixLoc = 0
    private var uModelMatrixLoc = 0
    private var uBaseColorLoc = 0
    private var uAlphaLoc = 0
    private var uPatternModeLoc = 0
    private var uFogColorLoc = 0

    private lateinit var unitCubeBuffer: FloatBuffer

    private val projMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val vpMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val mvpMatrix = FloatArray(16)
    private val vmProjMatrix = FloatArray(16)

    private var viewportWidth = 1
    private var viewportHeight = 1
    private var cachedMapId: ArenaMapId? = null
    private var cachedWorld: ArenaWorld? = null

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        unitCubeBuffer = buildUnitCubeBuffer()
        programId = createShaderProgram(VERTEX_SHADER, FRAGMENT_SHADER)
        aPositionLoc = GLES20.glGetAttribLocation(programId, "aPosition")
        aNormalLoc = GLES20.glGetAttribLocation(programId, "aNormal")
        uMvpMatrixLoc = GLES20.glGetUniformLocation(programId, "uMvpMatrix")
        uModelMatrixLoc = GLES20.glGetUniformLocation(programId, "uModelMatrix")
        uBaseColorLoc = GLES20.glGetUniformLocation(programId, "uBaseColor")
        uAlphaLoc = GLES20.glGetUniformLocation(programId, "uAlpha")
        uPatternModeLoc = GLES20.glGetUniformLocation(programId, "uPatternMode")
        uFogColorLoc = GLES20.glGetUniformLocation(programId, "uFogColor")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportWidth = width.coerceAtLeast(1)
        viewportHeight = height.coerceAtLeast(1)
        GLES20.glViewport(0, 0, viewportWidth, viewportHeight)
    }

    override fun onDrawFrame(gl: GL10?) {
        val snap = snapshotProvider()
        val map = snap.mapId
        if (cachedMapId != map || cachedWorld == null) {
            cachedMapId = map
            cachedWorld = ArenaWorld.build(map)
        }
        val world = cachedWorld ?: return

        val skyH = map.skyHorizonRgb
        GLES20.glClearColor(skyH[0], skyH[1], skyH[2], 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        GLES20.glUseProgram(programId)
        GLES20.glUniform3f(uFogColorLoc, skyH[0], skyH[1], skyH[2])

        val aspect = viewportWidth.toFloat() / viewportHeight.toFloat()
        Matrix.perspectiveM(projMatrix, 0, snap.fovYDeg, aspect, 0.12f, 120f)

        val yawRad = snap.camYawDeg * (PI.toFloat() / 180f)
        val pitchRad = snap.camPitchDeg * (PI.toFloat() / 180f)
        val dirX = sin(yawRad) * cos(pitchRad)
        val dirY = sin(pitchRad)
        val dirZ = -cos(yawRad) * cos(pitchRad)

        Matrix.setLookAtM(
            viewMatrix, 0,
            snap.camX, snap.camY, snap.camZ,
            snap.camX + dirX, snap.camY + dirY, snap.camZ + dirZ,
            0f, 1f, 0f
        )
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, viewMatrix, 0)

        bindCubeAttributes()

        // 1. Sky upper canopy slab for realistic horizon-to-zenith sky feel
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, snap.camX, 32f, snap.camZ)
        Matrix.scaleM(modelMatrix, 0, 140f, 1f, 140f)
        drawBoundBox(vpMatrix, map.skyTopRgb[0], map.skyTopRgb[1], map.skyTopRgb[2], 1f, 0)

        // 2. Render 3D Arena World Geometry
        for (box in world.boxes) {
            val cx = (box.minX + box.maxX) * 0.5f
            val cy = (box.minY + box.maxY) * 0.5f
            val cz = (box.minZ + box.maxZ) * 0.5f
            val sx = box.maxX - box.minX
            val sy = box.maxY - box.minY
            val sz = box.maxZ - box.minZ

            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, cx, cy, cz)
            Matrix.scaleM(modelMatrix, 0, sx, sy, sz)

            when (box.material) {
                SurfaceMaterial.GROUND ->
                    drawBoundBox(vpMatrix, map.groundRgb[0], map.groundRgb[1], map.groundRgb[2], 1f, 1)
                SurfaceMaterial.WALL_PRIMARY ->
                    drawBoundBox(vpMatrix, map.wallPrimaryRgb[0], map.wallPrimaryRgb[1], map.wallPrimaryRgb[2], 1f, 2)
                SurfaceMaterial.WALL_ACCENT_CRATE ->
                    drawBoundBox(vpMatrix, map.wallAccentRgb[0], map.wallAccentRgb[1], map.wallAccentRgb[2], 1f, 3)
                SurfaceMaterial.SITE_MARKER_A ->
                    drawBoundBox(vpMatrix, 0.86f, 0.24f, 0.18f, 0.85f, 4)
                SurfaceMaterial.SITE_MARKER_B ->
                    drawBoundBox(vpMatrix, 0.90f, 0.42f, 0.14f, 0.85f, 4)
                SurfaceMaterial.METAL_TRIM ->
                    drawBoundBox(vpMatrix, 0.30f, 0.36f, 0.43f, 1f, 0)
                SurfaceMaterial.HAZARD_STRIPE ->
                    drawBoundBox(vpMatrix, 0.92f, 0.68f, 0.10f, 1f, 4)
            }
        }

        // 3. Render Planted C4 Explosive + Blinking Beacon
        snap.plantedC4Pos?.let { (bx, by, bz) ->
            drawTransformBox(vpMatrix, bx, by, bz, 0f, 0.42f, 0.14f, 0.30f, 0.24f, 0.28f, 0.22f, 1f, 0)
            if (snap.c4BlinkOn) {
                drawTransformBox(vpMatrix, bx, by + 0.14f, bz, 0f, 0.16f, 0.16f, 0.16f, 1.0f, 0.15f, 0.12f, 0.95f, 0)
            }
        }

        // 4. Render Articulated 3D CT & T Operators
        for (c in snap.combatants) {
            drawCombatantModel(c)
        }

        // 5. Render Flying 3D Grenades & Bullet Tracers
        for (g in snap.grenades) {
            val (gr, gg, gb) = when (g.weaponId) {
                WeaponId.HE_GRENADE -> Triple(0.85f, 0.22f, 0.18f)
                WeaponId.SMOKE_GRENADE -> Triple(0.55f, 0.62f, 0.66f)
                else -> Triple(0.95f, 0.88f, 0.32f)
            }
            drawTransformBox(vpMatrix, g.x, g.y, g.z, 0f, 0.22f, 0.28f, 0.22f, gr, gg, gb, 1f, 0)
        }

        for (t in snap.tracers) {
            val mx = (t.startX + t.endX) * 0.5f
            val my = (t.startY + t.endY) * 0.5f
            val mz = (t.startZ + t.endZ) * 0.5f
            drawTransformBox(vpMatrix, mx, my, mz, 0f, 0.06f, 0.06f, 0.06f, 1f, 0.86f, 0.35f, t.alpha, 0)
            drawTransformBox(vpMatrix, t.endX, t.endY, t.endZ, 0f, 0.14f, 0.14f, 0.14f, 1f, 0.72f, 0.22f, t.alpha, 0)
        }

        // 6. Render CS2 Volumetric Reactive Smoke Clouds (transparent depth-tested pass)
        GLES20.glDepthMask(false)
        for (puff in snap.smokePuffs) {
            drawTransformBox(
                vpMatrix,
                puff.x, puff.y, puff.z,
                yawDeg = 25f,
                sx = puff.size, sy = puff.size * 0.88f, sz = puff.size,
                r = 0.74f, g = 0.77f, b = 0.81f,
                alpha = puff.alpha,
                pattern = 0
            )
        }
        GLES20.glDepthMask(true)

        // 7. Render First-Person 3D Weapon Viewmodel (foreground pass, hidden when scoped in)
        if (!snap.isScoped) {
            GLES20.glClear(GLES20.GL_DEPTH_BUFFER_BIT)
            Matrix.perspectiveM(vmProjMatrix, 0, 58f, aspect, 0.04f, 6f)
            drawFirstPersonWeapon(snap)
        }
    }

    private fun drawCombatantModel(c: CombatantRenderItem) {
        val crouchScale = if (c.isCrouching) 0.70f else 1.0f
        val (torsoR, torsoG, torsoB) = if (c.team == TeamSide.CT) {
            Triple(0.14f, 0.30f, 0.48f) // CT Navy Kevlar Rig
        } else {
            Triple(0.68f, 0.44f, 0.22f) // T Desert Tactical Jacket
        }
        val (accentR, accentG, accentB) = if (c.team == TeamSide.CT) {
            Triple(0.22f, 0.74f, 0.96f) // CT Visor Cyan
        } else {
            Triple(0.92f, 0.28f, 0.20f) // T Crimson Headband/Scarf
        }

        val legH = 0.74f * crouchScale
        val torsoH = 0.66f * crouchScale
        val headY = c.footY + legH + torsoH + 0.19f

        // Left & Right Legs
        val yawRad = c.yawDeg * (PI.toFloat() / 180f)
        val rx = cos(yawRad) * 0.15f
        val rz = sin(yawRad) * 0.15f
        drawTransformBox(vpMatrix, c.x - rx, c.footY + legH * 0.5f, c.z - rz, -c.yawDeg, 0.22f, legH, 0.24f, 0.16f, 0.19f, 0.23f, 1f, 0)
        drawTransformBox(vpMatrix, c.x + rx, c.footY + legH * 0.5f, c.z + rz, -c.yawDeg, 0.22f, legH, 0.24f, 0.16f, 0.19f, 0.23f, 1f, 0)

        // Armored Torso
        drawTransformBox(vpMatrix, c.x, c.footY + legH + torsoH * 0.5f, c.z, -c.yawDeg, 0.54f, torsoH, 0.32f, torsoR, torsoG, torsoB, 1f, 0)

        // Helmeted Head + Visor/Band
        drawTransformBox(vpMatrix, c.x, headY, c.z, -c.yawDeg, 0.34f, 0.36f, 0.34f, 0.24f, 0.27f, 0.31f, 1f, 0)
        val fx = sin(yawRad) * 0.16f
        val fz = -cos(yawRad) * 0.16f
        drawTransformBox(vpMatrix, c.x + fx, headY + 0.02f, c.z + fz, -c.yawDeg, 0.28f, 0.11f, 0.08f, accentR, accentG, accentB, 1f, 0)

        // Held 3D Rifle
        val gx = c.x + fx * 2.2f + rx * 0.9f
        val gz = c.z + fz * 2.2f + rz * 0.9f
        drawTransformBox(vpMatrix, gx, c.footY + legH + torsoH * 0.62f, gz, -c.yawDeg, 0.10f, 0.14f, 0.72f, 0.15f, 0.16f, 0.18f, 1f, 0)

        // Friendly Teammate Overhead Diamond Indicator
        if (c.isTeammate) {
            drawTransformBox(vpMatrix, c.x, headY + 0.42f, c.z, 45f, 0.14f, 0.14f, 0.14f, 0.22f, 0.82f, 0.98f, 0.92f, 0)
        }
    }

    private fun drawFirstPersonWeapon(snap: RenderFrameSnapshot) {
        val sideSign = if (snap.leftHanded) -1f else 1f
        val bobX = sin(snap.walkBobPhase) * 0.014f
        val bobY = cos(snap.walkBobPhase * 2f) * 0.011f
        val kickZ = snap.recoilKickOffset * 0.075f
        val kickPitch = snap.recoilKickOffset * 11f
        val reloadDip = sin(snap.reloadProgress * PI.toFloat()) * 0.24f
        val inspectYaw = sin(snap.inspectProgress * PI.toFloat()) * 34f * sideSign

        val baseX = 0.24f * sideSign + bobX
        val baseY = -0.22f + bobY - reloadDip
        val baseZ = -0.54f + kickZ

        val body = snap.weaponFinish.bodyRgb
        val acc = snap.weaponFinish.accentRgb
        val w = snap.activeWeapon

        if (w == WeaponId.KNIFE) {
            // Angled tactical combat knife + glove forearm
            drawViewmodelPart(baseX, baseY - 0.04f, baseZ + 0.08f, inspectYaw - 18f * sideSign, 14f + kickPitch, 0.05f, 0.05f, 0.16f, 0.15f, 0.17f, 0.20f)
            drawViewmodelPart(baseX - 0.02f * sideSign, baseY + 0.03f, baseZ - 0.08f, inspectYaw - 18f * sideSign, 22f + kickPitch, 0.022f, 0.045f, 0.26f, acc[0], acc[1], acc[2])
            return
        }

        if (w.isGrenade() || w == WeaponId.C4_EXPLOSIVE) {
            val (r, g, b) = when (w) {
                WeaponId.C4_EXPLOSIVE -> Triple(0.68f, 0.58f, 0.36f)
                WeaponId.HE_GRENADE -> Triple(0.28f, 0.42f, 0.26f)
                WeaponId.SMOKE_GRENADE -> Triple(0.46f, 0.52f, 0.56f)
                else -> Triple(0.82f, 0.78f, 0.28f)
            }
            drawViewmodelPart(baseX, baseY, baseZ + 0.06f, inspectYaw, kickPitch, 0.11f, 0.14f, 0.11f, r, g, b)
            drawViewmodelPart(baseX, baseY + 0.08f, baseZ + 0.06f, inspectYaw, kickPitch, 0.06f, 0.04f, 0.06f, 0.92f, 0.22f, 0.18f)
            return
        }

        // Receiver body
        val receiverLen = when {
            w == WeaponId.AWP || w == WeaponId.SSG_08 -> 0.48f
            w.slot.name == "PRIMARY" -> 0.38f
            else -> 0.22f
        }
        drawViewmodelPart(baseX, baseY, baseZ, inspectYaw, kickPitch, 0.068f, 0.088f, receiverLen, body[0], body[1], body[2])

        // Top accent rail / slide
        drawViewmodelPart(baseX, baseY + 0.046f, baseZ - 0.02f, inspectYaw, kickPitch, 0.052f, 0.024f, receiverLen * 0.92f, acc[0], acc[1], acc[2])

        // Barrel & Suppressor (M4A1-S / USP-S / AWP)
        val barrelLen = when {
            w == WeaponId.AWP -> 0.42f
            w.isSuppressed -> 0.34f
            w.slot.name == "PRIMARY" -> 0.24f
            else -> 0.09f
        }
        val barrelThick = if (w.isSuppressed) 0.036f else 0.022f
        drawViewmodelPart(
            baseX, baseY + 0.022f, baseZ - (receiverLen * 0.5f + barrelLen * 0.45f),
            inspectYaw, kickPitch,
            barrelThick, barrelThick, barrelLen,
            0.14f, 0.16f, 0.19f
        )

        // Magazine (curved/extended on Rifles & SMGs)
        if (w.slot.name == "PRIMARY") {
            drawViewmodelPart(
                baseX, baseY - 0.10f, baseZ - 0.04f,
                inspectYaw, kickPitch - 14f,
                0.044f, 0.15f, 0.065f,
                acc[0] * 0.85f, acc[1] * 0.85f, acc[2] * 0.85f
            )
        }

        // Sniper Optic Scope tube on AWP / SSG 08
        if (w.hasScope) {
            drawViewmodelPart(
                baseX, baseY + 0.092f, baseZ - 0.02f,
                inspectYaw, kickPitch,
                0.048f, 0.048f, 0.26f,
                0.10f, 0.12f, 0.15f
            )
        }

        // Dynamic Muzzle Flash
        if (snap.muzzleFlashIntensity > 0.05f && !w.isSuppressed) {
            val s = 0.09f * snap.muzzleFlashIntensity
            drawViewmodelPart(
                baseX, baseY + 0.025f, baseZ - (receiverLen * 0.5f + barrelLen + 0.04f),
                45f, 0f,
                s, s, s * 0.5f,
                1.0f, 0.82f, 0.28f
            )
        }
    }

    private fun drawViewmodelPart(
        tx: Float,
        ty: Float,
        tz: Float,
        yawDeg: Float,
        pitchDeg: Float,
        sx: Float,
        sy: Float,
        sz: Float,
        r: Float,
        g: Float,
        b: Float
    ) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, tx, ty, tz)
        if (yawDeg != 0f) Matrix.rotateM(modelMatrix, 0, yawDeg, 0f, 1f, 0f)
        if (pitchDeg != 0f) Matrix.rotateM(modelMatrix, 0, pitchDeg, 1f, 0f, 0f)
        Matrix.scaleM(modelMatrix, 0, sx, sy, sz)
        drawBoundBox(vmProjMatrix, r, g, b, 1f, 0)
    }

    private fun drawTransformBox(
        vp: FloatArray,
        cx: Float,
        cy: Float,
        cz: Float,
        yawDeg: Float,
        sx: Float,
        sy: Float,
        sz: Float,
        r: Float,
        g: Float,
        b: Float,
        alpha: Float,
        pattern: Int
    ) {
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.translateM(modelMatrix, 0, cx, cy, cz)
        if (yawDeg != 0f) {
            Matrix.rotateM(modelMatrix, 0, yawDeg, 0f, 1f, 0f)
        }
        Matrix.scaleM(modelMatrix, 0, sx, sy, sz)
        drawBoundBox(vp, r, g, b, alpha, pattern)
    }

    private fun drawBoundBox(
        vp: FloatArray,
        r: Float,
        g: Float,
        b: Float,
        alpha: Float,
        patternMode: Int
    ) {
        Matrix.multiplyMM(mvpMatrix, 0, vp, 0, modelMatrix, 0)
        GLES20.glUniformMatrix4fv(uMvpMatrixLoc, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(uModelMatrixLoc, 1, false, modelMatrix, 0)
        GLES20.glUniform3f(uBaseColorLoc, r, g, b)
        GLES20.glUniform1f(uAlphaLoc, alpha)
        GLES20.glUniform1i(uPatternModeLoc, patternMode)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 36)
    }

    private fun bindCubeAttributes() {
        val stride = 6 * 4
        unitCubeBuffer.position(0)
        GLES20.glEnableVertexAttribArray(aPositionLoc)
        GLES20.glVertexAttribPointer(aPositionLoc, 3, GLES20.GL_FLOAT, false, stride, unitCubeBuffer)

        unitCubeBuffer.position(3)
        GLES20.glEnableVertexAttribArray(aNormalLoc)
        GLES20.glVertexAttribPointer(aNormalLoc, 3, GLES20.GL_FLOAT, false, stride, unitCubeBuffer)
    }

    private fun buildUnitCubeBuffer(): FloatBuffer {
        // 36 vertices * (posXYZ + normalXYZ)
        val verts = floatArrayOf(
            // Front (+Z)
            -0.5f, -0.5f, 0.5f, 0f, 0f, 1f,  0.5f, -0.5f, 0.5f, 0f, 0f, 1f,  0.5f, 0.5f, 0.5f, 0f, 0f, 1f,
            -0.5f, -0.5f, 0.5f, 0f, 0f, 1f,  0.5f, 0.5f, 0.5f, 0f, 0f, 1f, -0.5f, 0.5f, 0.5f, 0f, 0f, 1f,
            // Back (-Z)
             0.5f, -0.5f, -0.5f, 0f, 0f, -1f, -0.5f, -0.5f, -0.5f, 0f, 0f, -1f, -0.5f, 0.5f, -0.5f, 0f, 0f, -1f,
             0.5f, -0.5f, -0.5f, 0f, 0f, -1f, -0.5f, 0.5f, -0.5f, 0f, 0f, -1f,  0.5f, 0.5f, -0.5f, 0f, 0f, -1f,
            // Left (-X)
            -0.5f, -0.5f, -0.5f, -1f, 0f, 0f, -0.5f, -0.5f, 0.5f, -1f, 0f, 0f, -0.5f, 0.5f, 0.5f, -1f, 0f, 0f,
            -0.5f, -0.5f, -0.5f, -1f, 0f, 0f, -0.5f, 0.5f, 0.5f, -1f, 0f, 0f, -0.5f, 0.5f, -0.5f, -1f, 0f, 0f,
            // Right (+X)
             0.5f, -0.5f, 0.5f, 1f, 0f, 0f,  0.5f, -0.5f, -0.5f, 1f, 0f, 0f,  0.5f, 0.5f, -0.5f, 1f, 0f, 0f,
             0.5f, -0.5f, 0.5f, 1f, 0f, 0f,  0.5f, 0.5f, -0.5f, 1f, 0f, 0f,  0.5f, 0.5f, 0.5f, 1f, 0f, 0f,
            // Top (+Y)
            -0.5f, 0.5f, 0.5f, 0f, 1f, 0f,  0.5f, 0.5f, 0.5f, 0f, 1f, 0f,  0.5f, 0.5f, -0.5f, 0f, 1f, 0f,
            -0.5f, 0.5f, 0.5f, 0f, 1f, 0f,  0.5f, 0.5f, -0.5f, 0f, 1f, 0f, -0.5f, 0.5f, -0.5f, 0f, 1f, 0f,
            // Bottom (-Y)
            -0.5f, -0.5f, -0.5f, 0f, -1f, 0f,  0.5f, -0.5f, -0.5f, 0f, -1f, 0f,  0.5f, -0.5f, 0.5f, 0f, -1f, 0f,
            -0.5f, -0.5f, -0.5f, 0f, -1f, 0f,  0.5f, -0.5f, 0.5f, 0f, -1f, 0f, -0.5f, -0.5f, 0.5f, 0f, -1f, 0f
        )
        return ByteBuffer.allocateDirect(verts.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply {
                put(verts)
                position(0)
            }
    }

    private fun createShaderProgram(vsSource: String, fsSource: String): Int {
        val vs = compileShader(GLES20.GL_VERTEX_SHADER, vsSource)
        val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fsSource)
        val prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, vs)
        GLES20.glAttachShader(prog, fs)
        GLES20.glLinkProgram(prog)
        return prog
    }

    private fun compileShader(type: Int, src: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, src)
        GLES20.glCompileShader(shader)
        return shader
    }

    companion object {
        private const val VERTEX_SHADER = """
            uniform mat4 uMvpMatrix;
            uniform mat4 uModelMatrix;
            attribute vec3 aPosition;
            attribute vec3 aNormal;
            varying vec3 vWorldPos;
            varying vec3 vNormal;
            varying vec3 vLocalPos;
            varying float vClipW;
            void main() {
                vec4 world = uModelMatrix * vec4(aPosition, 1.0);
                vWorldPos = world.xyz;
                vLocalPos = aPosition;
                vNormal = normalize(mat3(uModelMatrix[0].xyz, uModelMatrix[1].xyz, uModelMatrix[2].xyz) * aNormal);
                vec4 clip = uMvpMatrix * vec4(aPosition, 1.0);
                vClipW = clip.w;
                gl_Position = clip;
            }
        """

        private const val FRAGMENT_SHADER = """
            precision mediump float;
            uniform vec3 uBaseColor;
            uniform float uAlpha;
            uniform int uPatternMode;
            uniform vec3 uFogColor;
            varying vec3 vWorldPos;
            varying vec3 vNormal;
            varying vec3 vLocalPos;
            varying float vClipW;

            void main() {
                vec3 sunDir = normalize(vec3(0.45, 0.82, 0.35));
                float ndotl = max(dot(normalize(vNormal), sunDir), 0.0);
                float light = 0.54 + 0.46 * ndotl;
                vec3 col = uBaseColor;

                if (uPatternMode == 1) {
                    // Tactical cobblestone / concrete grid tiles
                    float gx = abs(fract(vWorldPos.x * 0.5) - 0.5);
                    float gz = abs(fract(vWorldPos.z * 0.5) - 0.5);
                    if (gx > 0.47 || gz > 0.47) {
                        col *= 0.85;
                    } else if (mod(floor(vWorldPos.x * 0.5) + floor(vWorldPos.z * 0.5), 2.0) < 0.5) {
                        col *= 0.95;
                    }
                } else if (uPatternMode == 2) {
                    // Sandstone / Concrete masonry courses
                    float row = floor(vWorldPos.y * 1.4);
                    float shift = mod(row, 2.0) * 0.5;
                    float mortarH = abs(fract(vWorldPos.y * 1.4) - 0.5);
                    float mortarV = abs(fract((vWorldPos.x + vWorldPos.z) * 0.55 + shift) - 0.5);
                    if (mortarH > 0.46 || mortarV > 0.47) {
                        col *= 0.82;
                    }
                    // Subtle lower wall AOplinth
                    if (vWorldPos.y < 0.38) {
                        col *= 0.78;
                    }
                } else if (uPatternMode == 3) {
                    // Military tactical crate framing + cross brace
                    float bx = abs(vLocalPos.x);
                    float by = abs(vLocalPos.y);
                    float bz = abs(vLocalPos.z);
                    if ((bx > 0.41 && by > 0.41) || (by > 0.41 && bz > 0.41) || (bx > 0.41 && bz > 0.41)) {
                        col *= 0.72;
                    }
                } else if (uPatternMode == 4) {
                    // Bombsite / Hazard diagonal stripes
                    float stripe = mod(floor((vWorldPos.x + vWorldPos.z + vWorldPos.y) * 2.5), 2.0);
                    if (stripe < 0.5) {
                        col *= 0.76;
                    }
                }

                vec3 lit = col * light;
                float fogFactor = clamp((vClipW - 22.0) / 58.0, 0.0, 0.42);
                vec3 finalRgb = mix(lit, uFogColor, fogFactor);
                gl_FragColor = vec4(finalRgb, uAlpha);
            }
        """
    }
}

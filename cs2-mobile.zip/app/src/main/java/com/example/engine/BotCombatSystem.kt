package com.example.engine

import com.example.model.BotDifficulty
import com.example.model.GameMode
import com.example.model.RoundPhase
import com.example.model.TeamSide
import com.example.model.WeaponId
import com.example.model.WeaponInstance
import com.example.model.WeaponSlot
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

data class HitscanResult(
    val hitX: Float,
    val hitY: Float,
    val hitZ: Float,
    val victim: CombatantEntity?,
    val isHeadshot: Boolean,
    val passedThroughSmoke: Boolean,
    val damageDealt: Int
)

object BotCombatSystem {

    fun equipBotForRound(bot: CombatantEntity, gameMode: GameMode, preferredCtRifle: WeaponId) {
        val defaultPistol = if (bot.team == TeamSide.CT) WeaponId.USP_S else WeaponId.GLOCK_18
        if (!bot.inventory.containsKey(WeaponSlot.MELEE)) {
            bot.inventory[WeaponSlot.MELEE] = WeaponInstance(WeaponId.KNIFE)
        }
        if (!bot.inventory.containsKey(WeaponSlot.SECONDARY)) {
            bot.inventory[WeaponSlot.SECONDARY] = WeaponInstance(defaultPistol)
        } else {
            val sec = bot.inventory[WeaponSlot.SECONDARY]!!.weaponId
            bot.inventory[WeaponSlot.SECONDARY] = WeaponInstance(sec)
        }

        // Refill existing primary if survived
        bot.inventory[WeaponSlot.PRIMARY]?.let { existing ->
            bot.inventory[WeaponSlot.PRIMARY] = WeaponInstance(existing.weaponId)
        }

        if (gameMode == GameMode.DEATHMATCH) {
            val dmChoices = if (bot.team == TeamSide.CT) {
                listOf(preferredCtRifle, WeaponId.AWP, WeaponId.MP9)
            } else {
                listOf(WeaponId.AK_47, WeaponId.AWP, WeaponId.MAC_10)
            }
            val pick = dmChoices.random()
            bot.inventory[WeaponSlot.PRIMARY] = WeaponInstance(pick)
            bot.armor = 100
            bot.hasHelmet = true
            bot.activeSlot = WeaponSlot.PRIMARY
            return
        }

        // Economy buy AI
        if (bot.armor < 50 && bot.cash >= 1000) {
            bot.cash -= 1000
            bot.armor = 100
            bot.hasHelmet = true
        } else if (bot.armor < 50 && bot.cash >= 650) {
            bot.cash -= 650
            bot.armor = 100
        }

        if (bot.inventory[WeaponSlot.PRIMARY] == null) {
            val rifle = if (bot.team == TeamSide.CT) preferredCtRifle else WeaponId.AK_47
            val smg = if (bot.team == TeamSide.CT) WeaponId.MP9 else WeaponId.MAC_10
            when {
                bot.cash >= 4900 && Random.nextFloat() < 0.25f -> {
                    bot.cash -= WeaponId.AWP.price
                    bot.inventory[WeaponSlot.PRIMARY] = WeaponInstance(WeaponId.AWP)
                }
                bot.cash >= rifle.price -> {
                    bot.cash -= rifle.price
                    bot.inventory[WeaponSlot.PRIMARY] = WeaponInstance(rifle)
                }
                bot.cash >= smg.price + 300 -> {
                    bot.cash -= smg.price
                    bot.inventory[WeaponSlot.PRIMARY] = WeaponInstance(smg)
                }
                bot.cash >= WeaponId.DESERT_EAGLE.price + 200 -> {
                    bot.cash -= WeaponId.DESERT_EAGLE.price
                    bot.inventory[WeaponSlot.SECONDARY] = WeaponInstance(WeaponId.DESERT_EAGLE)
                }
            }
        }

        if (bot.team == TeamSide.CT && !bot.hasDefuseKit && bot.cash >= 400) {
            bot.cash -= 400
            bot.hasDefuseKit = true
        }

        bot.activeSlot = if (bot.inventory.containsKey(WeaponSlot.PRIMARY)) {
            WeaponSlot.PRIMARY
        } else {
            WeaponSlot.SECONDARY
        }
    }

    fun performHitscan(
        shooter: CombatantEntity,
        world: ArenaWorld,
        combatants: List<CombatantEntity>,
        smokes: List<VolumetricSmokeCloud>,
        ox: Float,
        oy: Float,
        oz: Float,
        dx: Float,
        dy: Float,
        dz: Float,
        weapon: WeaponId,
        maxRange: Float,
        nowMs: Long
    ): HitscanResult {
        val wallDist = world.raycastWorld(ox, oy, oz, dx, dy, dz, maxRange)
        var bestDist = wallDist
        var hitVictim: CombatantEntity? = null
        var hitHead = false

        for (target in combatants) {
            if (!target.isAlive || target.id == shooter.id) continue
            // Friendly fire off in Premier/DM
            if (target.team == shooter.team) continue

            val bodyH = target.bodyHeight()
            // Head hitbox (top 26% of height)
            val headMinY = target.footY + bodyH - 0.42f
            val headMaxY = target.footY + bodyH + 0.06f
            val headBox = Box3D(
                target.x - 0.24f, headMinY, target.z - 0.24f,
                target.x + 0.24f, headMaxY, target.z + 0.24f
            )
            val tHead = ArenaWorld.intersectRayAabb(ox, oy, oz, dx, dy, dz, headBox, bestDist)
            if (tHead >= 0f && tHead < bestDist) {
                bestDist = tHead
                hitVictim = target
                hitHead = true
                continue
            }

            // Torso & legs hitbox
            val bodyBox = Box3D(
                target.x - 0.40f, target.footY, target.z - 0.40f,
                target.x + 0.40f, headMinY, target.z + 0.40f
            )
            val tBody = ArenaWorld.intersectRayAabb(ox, oy, oz, dx, dy, dz, bodyBox, bestDist)
            if (tBody >= 0f && tBody < bestDist) {
                bestDist = tBody
                hitVictim = target
                hitHead = false
            }
        }

        // Carve through any volumetric smoke clouds intersected by bullet ray [0..bestDist]
        var throughSmoke = false
        for (smoke in smokes) {
            if (nowMs >= smoke.expiresAtMs) continue
            val vx = smoke.centerX - ox
            val vy = (smoke.centerY + 1.2f) - oy
            val vz = smoke.centerZ - oz
            val proj = (vx * dx + vy * dy + vz * dz).coerceIn(0f, bestDist)
            val cx = ox + dx * proj
            val cy = oy + dy * proj
            val cz = oz + dz * proj
            val dSq = (cx - smoke.centerX) * (cx - smoke.centerX) +
                (cy - (smoke.centerY + 1.2f)) * (cy - (smoke.centerY + 1.2f)) +
                (cz - smoke.centerZ) * (cz - smoke.centerZ)
            if (dSq <= smoke.radius * smoke.radius) {
                throughSmoke = true
                smoke.carveRays.removeAll { it.expiresAtMs <= nowMs }
                if (smoke.carveRays.size < 16) {
                    smoke.carveRays.add(
                        SmokeCarveRay(ox, oy, oz, dx, dy, dz, nowMs + 1650L)
                    )
                }
            }
        }

        var finalDamage = 0
        if (hitVictim != null) {
            val distAtten = (1f - (bestDist / 95f) * 0.18f).coerceIn(0.68f, 1f)
            val mult = if (hitHead) 3.85f else 1.0f
            val raw = weapon.baseDamage * mult * distAtten
            val armored = if (hitHead) hitVictim.hasHelmet else hitVictim.armor > 0
            finalDamage = if (armored) {
                val absorbed = (raw * (1f - weapon.armorPenetration) * 0.5f).toInt()
                hitVictim.armor = (hitVictim.armor - absorbed).coerceAtLeast(0)
                (raw * weapon.armorPenetration).toInt().coerceAtLeast(1)
            } else {
                raw.toInt().coerceAtLeast(1)
            }
        }

        return HitscanResult(
            hitX = ox + dx * bestDist,
            hitY = oy + dy * bestDist,
            hitZ = oz + dz * bestDist,
            victim = hitVictim,
            isHeadshot = hitHead,
            passedThroughSmoke = throughSmoke,
            damageDealt = finalDamage
        )
    }

    fun stepBotAi(
        bot: CombatantEntity,
        dt: Float,
        nowMs: Long,
        phase: RoundPhase,
        world: ArenaWorld,
        combatants: List<CombatantEntity>,
        smokes: List<VolumetricSmokeCloud>,
        difficulty: BotDifficulty,
        plantedC4Pos: Triple<Float, Float, Float>?,
        onBotFire: (CombatantEntity, Float, Float, Float) -> Unit,
        onBotPlantedC4: (CombatantEntity, BombSiteZone) -> Unit,
        onBotDefusedC4: (CombatantEntity) -> Unit
    ) {
        if (!bot.isAlive || phase == RoundPhase.FREEZE_TIME || phase == RoundPhase.ROUND_OVER || phase == RoundPhase.MATCH_OVER) {
            return
        }

        // Check reload completion
        val activeInst = bot.activeWeapon()
        if (bot.isReloading && activeInst != null) {
            if (nowMs - bot.reloadStartMs >= activeInst.weaponId.reloadDurationMs) {
                val needed = activeInst.weaponId.magSize - activeInst.ammoInMag
                val take = needed.coerceAtMost(activeInst.reserveAmmo)
                bot.inventory[bot.activeSlot] = activeInst.copy(
                    ammoInMag = activeInst.ammoInMag + take,
                    reserveAmmo = activeInst.reserveAmmo - take
                )
                bot.isReloading = false
            }
        }

        if (nowMs < bot.blindedUntilMs) {
            // Blinded by flashbang: strafe randomly
            val moveX = bot.x + cos(nowMs * 0.005f) * 2.0f * dt
            val moveZ = bot.z + sin(nowMs * 0.005f) * 2.0f * dt
            val (rx, rz, supY) = world.resolveMovement(bot.x, bot.z, bot.footY, moveX, moveZ)
            bot.x = rx
            bot.z = rz
            bot.footY = supY
            return
        }

        // Find nearest visible enemy
        val eyeY = bot.footY + bot.eyeHeight()
        var visibleTarget: CombatantEntity? = null
        var bestDist = 46f

        for (other in combatants) {
            if (!other.isAlive || other.team == bot.team) continue
            val tx = other.x - bot.x
            val ty = (other.footY + other.eyeHeight() * 0.82f) - eyeY
            val tz = other.z - bot.z
            val d = sqrt(tx * tx + ty * ty + tz * tz)
            if (d < 0.2f || d > bestDist) continue
            val nx = tx / d
            val ny = ty / d
            val nz = tz / d

            val wallHit = world.raycastWorld(bot.x, eyeY, bot.z, nx, ny, nz, d)
            if (wallHit < d - 0.35f) continue

            val smokeBlocked = smokes.any { it.blocksRay(bot.x, eyeY, bot.z, nx, ny, nz, d, nowMs) }
            if (smokeBlocked) continue

            bestDist = d
            visibleTarget = other
        }

        if (visibleTarget != null) {
            bot.botPlantingProgressSec = 0f
            bot.botDefusingProgressSec = 0f
            if (bot.spottedEnemySinceMs == 0L) {
                bot.spottedEnemySinceMs = nowMs
            }

            // Face enemy smoothly
            val tx = visibleTarget.x - bot.x
            val ty = (visibleTarget.footY + visibleTarget.eyeHeight() * 0.84f) - eyeY
            val tz = visibleTarget.z - bot.z
            val horiz = sqrt(tx * tx + tz * tz).coerceAtLeast(0.01f)
            bot.yawDeg = (atan2(tx, -tz) * 180f / PI.toFloat())
            bot.pitchDeg = (atan2(ty, horiz) * 180f / PI.toFloat()).coerceIn(-45f, 45f)

            // Tactical strafe during duel
            if (nowMs >= bot.nextStrafeFlipMs) {
                bot.strafeDir = if (Random.nextBoolean()) 1f else -1f
                bot.nextStrafeFlipMs = nowMs + Random.nextLong(450L, 1100L)
            }
            val yawRad = bot.yawDeg * (PI.toFloat() / 180f)
            val rightX = cos(yawRad)
            val rightZ = sin(yawRad)
            val nx = bot.x + rightX * bot.strafeDir * difficulty.strafeSpeed * dt
            val nz = bot.z + rightZ * bot.strafeDir * difficulty.strafeSpeed * dt
            val (rx, rz, supY) = world.resolveMovement(bot.x, bot.z, bot.footY, nx, nz)
            bot.x = rx
            bot.z = rz
            bot.footY = supY

            // Fire if reaction time elapsed
            val inst = bot.activeWeapon()
            if (inst != null && !bot.isReloading && nowMs - bot.spottedEnemySinceMs >= difficulty.reactionDelayMs) {
                if (inst.ammoInMag <= 0) {
                    if (inst.reserveAmmo > 0) {
                        bot.isReloading = true
                        bot.reloadStartMs = nowMs
                    } else {
                        bot.activeSlot = WeaponSlot.SECONDARY
                    }
                } else if (nowMs - bot.lastFireMs >= inst.weaponId.fireIntervalMs + 55L) {
                    bot.lastFireMs = nowMs
                    bot.inventory[bot.activeSlot] = inst.copy(ammoInMag = inst.ammoInMag - 1)
                    val d = sqrt(tx * tx + ty * ty + tz * tz).coerceAtLeast(0.1f)
                    val spreadX = (Random.nextFloat() * 2f - 1f) * difficulty.aimSpreadRad
                    val spreadY = (Random.nextFloat() * 2f - 1f) * difficulty.aimSpreadRad
                    val spreadZ = (Random.nextFloat() * 2f - 1f) * difficulty.aimSpreadRad
                    val dirX = tx / d + spreadX
                    val dirY = ty / d + spreadY
                    val dirZ = tz / d + spreadZ
                    val norm = sqrt(dirX * dirX + dirY * dirY + dirZ * dirZ).coerceAtLeast(0.001f)
                    onBotFire(bot, dirX / norm, dirY / norm, dirZ / norm)
                }
            }
            return
        } else {
            bot.spottedEnemySinceMs = 0L
        }

        // Objective checks: T bot with C4 on bombsite OR CT bot near planted C4
        if (bot.team == TeamSide.T && phase == RoundPhase.LIVE && bot.inventory.containsKey(WeaponSlot.C4)) {
            val site = world.bombSiteAt(bot.x, bot.z)
            if (site != null) {
                bot.botPlantingProgressSec += dt
                if (bot.botPlantingProgressSec >= 3.2f) {
                    bot.botPlantingProgressSec = 0f
                    onBotPlantedC4(bot, site)
                }
                return
            }
        }

        if (bot.team == TeamSide.CT && phase == RoundPhase.BOMB_PLANTED && plantedC4Pos != null) {
            val dx = plantedC4Pos.first - bot.x
            val dz = plantedC4Pos.third - bot.z
            val distSq = dx * dx + dz * dz
            if (distSq <= 2.6f * 2.6f) {
                bot.botDefusingProgressSec += dt
                val needed = if (bot.hasDefuseKit) 5.0f else 8.5f
                if (bot.botDefusingProgressSec >= needed) {
                    bot.botDefusingProgressSec = 0f
                    onBotDefusedC4(bot)
                }
                return
            }
            // Navigate directly toward planted C4 site waypoint
            val targetSiteWp = if (plantedC4Pos.first < 0f) 4 else 6
            bot.targetWaypointId = targetSiteWp
        }

        // Move toward current waypoint
        val wp = world.waypoints.find { it.id == bot.targetWaypointId } ?: world.waypoints[5]
        val dx = wp.x - bot.x
        val dz = wp.z - bot.z
        val dist = sqrt(dx * dx + dz * dz)
        if (dist < 1.8f) {
            val nextId = if (bot.team == TeamSide.T && bot.inventory.containsKey(WeaponSlot.C4)) {
                // Bias T bomb carrier toward Site A (4) or Site B (6)
                wp.neighbors.minByOrNull { nid ->
                    val nwp = world.waypoints.find { it.id == nid } ?: wp
                    val siteX = if (bot.id.hashCode() % 2 == 0) -16f else 16f
                    (nwp.x - siteX) * (nwp.x - siteX) + (nwp.z + 15f) * (nwp.z + 15f)
                } ?: wp.neighbors.random()
            } else {
                wp.neighbors.random()
            }
            bot.targetWaypointId = nextId
        } else {
            val speed = 4.6f
            val vx = (dx / dist) * speed * dt
            val vz = (dz / dist) * speed * dt
            bot.yawDeg = atan2(dx, -dz) * (180f / PI.toFloat())
            bot.pitchDeg = 0f
            val (rx, rz, supY) = world.resolveMovement(bot.x, bot.z, bot.footY, bot.x + vx, bot.z + vz)
            bot.x = rx
            bot.z = rz
            bot.footY = supY
        }
    }
}

package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.example.model.WeaponId
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

class TacticalAudioEngine(context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val sampleRate = 22050

    private val vibrator: Vibrator? = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vm?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }.getOrNull()

    @Volatile
    var soundEnabled: Boolean = true

    @Volatile
    var hapticsEnabled: Boolean = true

    fun playWeaponFire(weaponId: WeaponId) {
        if (hapticsEnabled) {
            val ms = when (weaponId) {
                WeaponId.AWP -> 48L
                WeaponId.DESERT_EAGLE, WeaponId.SSG_08 -> 30L
                WeaponId.AK_47 -> 20L
                else -> 12L
            }
            vibratePulse(ms, if (weaponId == WeaponId.AWP) 240 else 150)
        }
        if (!soundEnabled) return
        scope.launch {
            val pcm = when {
                weaponId == WeaponId.AWP -> synthShot(durationMs = 260, baseFreq = 78f, noiseMix = 0.82f, decay = 8.5f)
                weaponId == WeaponId.DESERT_EAGLE -> synthShot(durationMs = 180, baseFreq = 115f, noiseMix = 0.78f, decay = 13f)
                weaponId.isSuppressed -> synthShot(durationMs = 95, baseFreq = 190f, noiseMix = 0.45f, decay = 28f)
                weaponId == WeaponId.KNIFE -> synthShot(durationMs = 75, baseFreq = 920f, noiseMix = 0.65f, decay = 34f)
                else -> synthShot(durationMs = 135, baseFreq = 138f, noiseMix = 0.75f, decay = 18f)
            }
            playPcmBuffer(pcm)
        }
    }

    fun playHitMarker(isHeadshot: Boolean) {
        if (hapticsEnabled) {
            vibratePulse(if (isHeadshot) 26L else 10L, if (isHeadshot) 220 else 110)
        }
        if (!soundEnabled) return
        scope.launch {
            val freq = if (isHeadshot) 1680f else 1120f
            val durationMs = if (isHeadshot) 95 else 45
            val samples = (sampleRate * durationMs) / 1000
            val pcm = ShortArray(samples)
            for (i in 0 until samples) {
                val t = i.toFloat() / sampleRate
                val env = exp(-t * (if (isHeadshot) 24f else 48f))
                val tone = sin(2.0 * PI * freq * t) + 0.45 * sin(2.0 * PI * (freq * 1.52f) * t)
                pcm[i] = (tone * env * 13000).toInt().coerceIn(-32000, 32000).toShort()
            }
            playPcmBuffer(pcm)
        }
    }

    fun playBombBeep(urgent: Boolean = false) {
        if (hapticsEnabled && urgent) {
            vibratePulse(14L, 140)
        }
        if (!soundEnabled) return
        scope.launch {
            val freq = if (urgent) 2640f else 2180f
            val samples = (sampleRate * 55) / 1000
            val pcm = ShortArray(samples)
            for (i in 0 until samples) {
                val t = i.toFloat() / sampleRate
                val env = exp(-t * 26f)
                val tone = sin(2.0 * PI * freq * t)
                pcm[i] = (tone * env * 12000).toInt().coerceIn(-32000, 32000).toShort()
            }
            playPcmBuffer(pcm)
        }
    }

    fun playExplosionOrSmoke(isSmoke: Boolean) {
        if (hapticsEnabled) {
            vibratePulse(if (isSmoke) 22L else 65L, if (isSmoke) 120 else 255)
        }
        if (!soundEnabled) return
        scope.launch {
            val pcm = if (isSmoke) {
                synthShot(durationMs = 310, baseFreq = 320f, noiseMix = 0.96f, decay = 7f)
            } else {
                synthShot(durationMs = 380, baseFreq = 58f, noiseMix = 0.88f, decay = 5.5f)
            }
            playPcmBuffer(pcm)
        }
    }

    fun playRoundStinger(won: Boolean) {
        if (!soundEnabled) return
        scope.launch {
            val notes = if (won) floatArrayOf(440f, 554.37f, 659.25f) else floatArrayOf(330f, 293.66f, 246.94f)
            val totalSamples = (sampleRate * 360) / 1000
            val pcm = ShortArray(totalSamples)
            val step = totalSamples / notes.size
            for (i in 0 until totalSamples) {
                val idx = (i / step).coerceAtMost(notes.lastIndex)
                val localT = (i % step).toFloat() / sampleRate
                val env = exp(-localT * 10f)
                val sample = sin(2.0 * PI * notes[idx] * localT) * env * 11000
                pcm[i] = sample.toInt().coerceIn(-32000, 32000).toShort()
            }
            playPcmBuffer(pcm)
        }
    }

    private fun synthShot(durationMs: Int, baseFreq: Float, noiseMix: Float, decay: Float): ShortArray {
        val samples = (sampleRate * durationMs) / 1000
        val out = ShortArray(samples)
        for (i in 0 until samples) {
            val t = i.toFloat() / sampleRate
            val env = exp(-t * decay)
            val sweepFreq = baseFreq * exp(-t * 9f)
            val thump = sin(2.0 * PI * sweepFreq * t).toFloat()
            val crack = (Random.nextFloat() * 2f - 1f)
            val mixed = ((1f - noiseMix) * thump + noiseMix * crack) * env
            out[i] = (mixed * 22000f).toInt().coerceIn(-32000, 32000).toShort()
        }
        return out
    }

    private fun playPcmBuffer(pcm: ShortArray) {
        runCatching {
            val byteSize = pcm.size * 2
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(byteSize.coerceAtLeast(2048))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()
            track.write(pcm, 0, pcm.size)
            track.play()
            Thread.sleep(((pcm.size * 1000L) / sampleRate) + 35L)
            track.stop()
            track.release()
        }
    }

    private fun vibratePulse(durationMs: Long, amplitude: Int) {
        runCatching {
            val vib = vibrator ?: return
            if (!vib.hasVibrator()) return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(
                    VibrationEffect.createOneShot(
                        durationMs,
                        amplitude.coerceIn(1, 255)
                    )
                )
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(durationMs)
            }
        }
    }
}

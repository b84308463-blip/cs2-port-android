package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.CrosshairColorPreset
import com.example.model.PlayerSettings
import com.example.model.WeaponFinish
import com.example.model.WeaponId
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.tacticalDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "strike_tactical_prefs"
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val CROSSHAIR_LENGTH = floatPreferencesKey("crosshair_length")
        val CROSSHAIR_GAP = floatPreferencesKey("crosshair_gap")
        val CROSSHAIR_THICKNESS = floatPreferencesKey("crosshair_thickness")
        val CROSSHAIR_DOT = booleanPreferencesKey("crosshair_dot")
        val DYNAMIC_CROSSHAIR = booleanPreferencesKey("dynamic_crosshair")
        val CROSSHAIR_COLOR = stringPreferencesKey("crosshair_color")
        val TOUCH_SENS = floatPreferencesKey("touch_sens")
        val GYRO_ENABLED = booleanPreferencesKey("gyro_enabled")
        val GYRO_SENS = floatPreferencesKey("gyro_sens")
        val AUTO_FIRE = booleanPreferencesKey("auto_fire")
        val LEFT_HANDED = booleanPreferencesKey("left_handed")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val HAPTICS_ENABLED = booleanPreferencesKey("haptics_enabled")
        val PREFERRED_CT_RIFLE = stringPreferencesKey("preferred_ct_rifle")
        val GLOBAL_FINISH = stringPreferencesKey("global_finish")
    }

    val settingsFlow: Flow<PlayerSettings> = context.tacticalDataStore.data.map { prefs ->
        val colorName = prefs[Keys.CROSSHAIR_COLOR]
        val colorPreset = CrosshairColorPreset.entries.find { it.name == colorName }
            ?: CrosshairColorPreset.CLASSIC_GREEN

        val ctRifleName = prefs[Keys.PREFERRED_CT_RIFLE]
        val ctRifle = if (ctRifleName == WeaponId.M4A4.name) WeaponId.M4A4 else WeaponId.M4A1_S

        val finishName = prefs[Keys.GLOBAL_FINISH]
        val finish = WeaponFinish.entries.find { it.name == finishName } ?: WeaponFinish.AMBER_BLAZE

        PlayerSettings(
            crosshairLengthDp = prefs[Keys.CROSSHAIR_LENGTH] ?: 7f,
            crosshairGapDp = prefs[Keys.CROSSHAIR_GAP] ?: 3.5f,
            crosshairThicknessDp = prefs[Keys.CROSSHAIR_THICKNESS] ?: 2f,
            crosshairCenterDot = prefs[Keys.CROSSHAIR_DOT] ?: false,
            dynamicCrosshair = prefs[Keys.DYNAMIC_CROSSHAIR] ?: true,
            crosshairColor = colorPreset,
            touchSensitivity = prefs[Keys.TOUCH_SENS] ?: 1.0f,
            gyroEnabled = prefs[Keys.GYRO_ENABLED] ?: false,
            gyroSensitivity = prefs[Keys.GYRO_SENS] ?: 1.2f,
            autoFireOnTarget = prefs[Keys.AUTO_FIRE] ?: false,
            leftHandedViewmodel = prefs[Keys.LEFT_HANDED] ?: false,
            soundEnabled = prefs[Keys.SOUND_ENABLED] ?: true,
            hapticsEnabled = prefs[Keys.HAPTICS_ENABLED] ?: true,
            preferredCtRifle = ctRifle,
            globalWeaponFinish = finish
        )
    }

    suspend fun updateSettings(transform: (PlayerSettings) -> PlayerSettings) {
        context.tacticalDataStore.edit { prefs ->
            val current = PlayerSettings(
                crosshairLengthDp = prefs[Keys.CROSSHAIR_LENGTH] ?: 7f,
                crosshairGapDp = prefs[Keys.CROSSHAIR_GAP] ?: 3.5f,
                crosshairThicknessDp = prefs[Keys.CROSSHAIR_THICKNESS] ?: 2f,
                crosshairCenterDot = prefs[Keys.CROSSHAIR_DOT] ?: false,
                dynamicCrosshair = prefs[Keys.DYNAMIC_CROSSHAIR] ?: true,
                crosshairColor = CrosshairColorPreset.entries.find {
                    it.name == prefs[Keys.CROSSHAIR_COLOR]
                } ?: CrosshairColorPreset.CLASSIC_GREEN,
                touchSensitivity = prefs[Keys.TOUCH_SENS] ?: 1.0f,
                gyroEnabled = prefs[Keys.GYRO_ENABLED] ?: false,
                gyroSensitivity = prefs[Keys.GYRO_SENS] ?: 1.2f,
                autoFireOnTarget = prefs[Keys.AUTO_FIRE] ?: false,
                leftHandedViewmodel = prefs[Keys.LEFT_HANDED] ?: false,
                soundEnabled = prefs[Keys.SOUND_ENABLED] ?: true,
                hapticsEnabled = prefs[Keys.HAPTICS_ENABLED] ?: true,
                preferredCtRifle = if (prefs[Keys.PREFERRED_CT_RIFLE] == WeaponId.M4A4.name) {
                    WeaponId.M4A4
                } else {
                    WeaponId.M4A1_S
                },
                globalWeaponFinish = WeaponFinish.entries.find {
                    it.name == prefs[Keys.GLOBAL_FINISH]
                } ?: WeaponFinish.AMBER_BLAZE
            )
            val updated = transform(current)
            prefs[Keys.CROSSHAIR_LENGTH] = updated.crosshairLengthDp
            prefs[Keys.CROSSHAIR_GAP] = updated.crosshairGapDp
            prefs[Keys.CROSSHAIR_THICKNESS] = updated.crosshairThicknessDp
            prefs[Keys.CROSSHAIR_DOT] = updated.crosshairCenterDot
            prefs[Keys.DYNAMIC_CROSSHAIR] = updated.dynamicCrosshair
            prefs[Keys.CROSSHAIR_COLOR] = updated.crosshairColor.name
            prefs[Keys.TOUCH_SENS] = updated.touchSensitivity
            prefs[Keys.GYRO_ENABLED] = updated.gyroEnabled
            prefs[Keys.GYRO_SENS] = updated.gyroSensitivity
            prefs[Keys.AUTO_FIRE] = updated.autoFireOnTarget
            prefs[Keys.LEFT_HANDED] = updated.leftHandedViewmodel
            prefs[Keys.SOUND_ENABLED] = updated.soundEnabled
            prefs[Keys.HAPTICS_ENABLED] = updated.hapticsEnabled
            prefs[Keys.PREFERRED_CT_RIFLE] = updated.preferredCtRifle.name
            prefs[Keys.GLOBAL_FINISH] = updated.globalWeaponFinish.name
        }
    }
}

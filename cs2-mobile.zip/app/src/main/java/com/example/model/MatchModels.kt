package com.example.model

import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.Color
import com.example.R

enum class GameMode(
    val titleRes: Int,
    val descRes: Int,
    val teamSize: Int,
    val roundsToWin: Int,
    val startCash: Int,
    val roundSeconds: Int,
    val hasBombObjective: Boolean
) {
    PREMIER_5V5(
        titleRes = R.string.mode_premier_title,
        descRes = R.string.mode_premier_desc,
        teamSize = 5,
        roundsToWin = 7, // MR6 competitive mobile format (first to 7, halftime swap at 6)
        startCash = 800,
        roundSeconds = 105,
        hasBombObjective = true
    ),
    WINGMAN_2V2(
        titleRes = R.string.mode_wingman_title,
        descRes = R.string.mode_wingman_desc,
        teamSize = 2,
        roundsToWin = 5,
        startCash = 1000,
        roundSeconds = 85,
        hasBombObjective = true
    ),
    DEATHMATCH(
        titleRes = R.string.mode_deathmatch_title,
        descRes = R.string.mode_deathmatch_desc,
        teamSize = 5,
        roundsToWin = 1,
        startCash = 16000,
        roundSeconds = 180,
        hasBombObjective = false
    )
}

enum class ArenaMapId(
    val nameRes: Int,
    val codeRes: Int,
    val descRes: Int,
    @DrawableRes val bannerRes: Int,
    val skyTopRgb: FloatArray,
    val skyHorizonRgb: FloatArray,
    val groundRgb: FloatArray,
    val wallPrimaryRgb: FloatArray,
    val wallAccentRgb: FloatArray
) {
    DUST_ARENA(
        nameRes = R.string.map_dust_name,
        codeRes = R.string.map_dust_code,
        descRes = R.string.map_dust_desc,
        bannerRes = R.drawable.img_hero_dust_arena,
        skyTopRgb = floatArrayOf(0.22f, 0.47f, 0.78f),
        skyHorizonRgb = floatArrayOf(0.84f, 0.76f, 0.62f),
        groundRgb = floatArrayOf(0.76f, 0.66f, 0.50f),
        wallPrimaryRgb = floatArrayOf(0.82f, 0.71f, 0.54f),
        wallAccentRgb = floatArrayOf(0.42f, 0.48f, 0.34f) // Olive military crates
    ),
    PALACE_MIRAGE(
        nameRes = R.string.map_mirage_name,
        codeRes = R.string.map_mirage_code,
        descRes = R.string.map_mirage_desc,
        bannerRes = R.drawable.img_map_mirage,
        skyTopRgb = floatArrayOf(0.15f, 0.39f, 0.75f),
        skyHorizonRgb = floatArrayOf(0.92f, 0.72f, 0.54f),
        groundRgb = floatArrayOf(0.68f, 0.56f, 0.46f),
        wallPrimaryRgb = floatArrayOf(0.84f, 0.62f, 0.47f), // Terracotta plaster
        wallAccentRgb = floatArrayOf(0.55f, 0.36f, 0.22f)  // Cedar crates
    ),
    REACTOR_FACILITY(
        nameRes = R.string.map_facility_name,
        codeRes = R.string.map_facility_code,
        descRes = R.string.map_facility_desc,
        bannerRes = R.drawable.img_map_facility,
        skyTopRgb = floatArrayOf(0.08f, 0.14f, 0.24f),
        skyHorizonRgb = floatArrayOf(0.18f, 0.32f, 0.46f),
        groundRgb = floatArrayOf(0.28f, 0.32f, 0.37f),
        wallPrimaryRgb = floatArrayOf(0.42f, 0.47f, 0.53f), // Concrete bunker
        wallAccentRgb = floatArrayOf(0.88f, 0.66f, 0.12f)  // Hazard yellow silos
    )
}

enum class BotDifficulty(
    val labelRes: Int,
    val reactionDelayMs: Long,
    val aimSpreadRad: Float,
    val strafeSpeed: Float
) {
    SILVER(R.string.diff_recruit, 680L, 0.11f, 2.2f),
    MASTER_GUARDIAN(R.string.diff_veteran, 390L, 0.058f, 3.3f),
    GLOBAL_ELITE(R.string.diff_elite, 210L, 0.026f, 4.2f)
}

enum class RoundPhase {
    FREEZE_TIME,
    LIVE,
    BOMB_PLANTED,
    ROUND_OVER,
    MATCH_OVER
}

enum class CrosshairColorPreset(val displayName: String, val color: Color) {
    CLASSIC_GREEN("Classic Green", Color(0xFF22C55E)),
    TACTICAL_CYAN("Premier Cyan", Color(0xFF38BDF8)),
    AMBER_GOLD("Solar Amber", Color(0xFFFBBF24)),
    PURE_WHITE("Crisp White", Color(0xFFF8FAFC)),
    NEON_PINK("Esports Magenta", Color(0xFFF43F5E))
}

data class PlayerSettings(
    val crosshairLengthDp: Float = 7f,
    val crosshairGapDp: Float = 3.5f,
    val crosshairThicknessDp: Float = 2f,
    val crosshairCenterDot: Boolean = false,
    val dynamicCrosshair: Boolean = true,
    val crosshairColor: CrosshairColorPreset = CrosshairColorPreset.CLASSIC_GREEN,
    val touchSensitivity: Float = 1.0f,
    val gyroEnabled: Boolean = false,
    val gyroSensitivity: Float = 1.2f,
    val autoFireOnTarget: Boolean = false,
    val leftHandedViewmodel: Boolean = false,
    val soundEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val preferredCtRifle: WeaponId = WeaponId.M4A1_S,
    val globalWeaponFinish: WeaponFinish = WeaponFinish.AMBER_BLAZE
)

data class KillFeedEntry(
    val id: Long,
    val killerName: String,
    val killerTeam: TeamSide,
    val victimName: String,
    val victimTeam: TeamSide,
    val weaponName: String,
    val isHeadshot: Boolean,
    val throughSmoke: Boolean = false,
    val timestampMs: Long
)

data class ScoreboardEntry(
    val id: String,
    val name: String,
    val team: TeamSide,
    val isLocalPlayer: Boolean,
    val isAlive: Boolean,
    val hp: Int,
    val kills: Int,
    val deaths: Int,
    val assists: Int,
    val cash: Int,
    val hasC4: Boolean = false,
    val hasDefuseKit: Boolean = false
)

data class RadarBlip(
    val x: Float,
    val z: Float,
    val team: TeamSide,
    val isLocal: Boolean = false,
    val isAlive: Boolean = true,
    val yawDeg: Float = 0f
)

data class RadarSmokeZone(
    val x: Float,
    val z: Float,
    val radius: Float,
    val isDispersedByHe: Boolean
)

data class MatchHudState(
    val isInMatch: Boolean = false,
    val mapId: ArenaMapId = ArenaMapId.DUST_ARENA,
    val gameMode: GameMode = GameMode.PREMIER_5V5,
    val playerTeam: TeamSide = TeamSide.CT,
    val roundNumber: Int = 1,
    val ctScore: Int = 0,
    val tScore: Int = 0,
    val phase: RoundPhase = RoundPhase.FREEZE_TIME,
    val timerSeconds: Int = 105,
    val bombCountdownProgress: Float = 1f, // 1f -> 0f over 40s
    val plantedSiteLabel: String? = null,
    val ctAliveCount: Int = 5,
    val tAliveCount: Int = 5,
    val playerHp: Int = 100,
    val playerArmor: Int = 0,
    val hasHelmet: Boolean = false,
    val hasDefuseKit: Boolean = false,
    val cash: Int = 800,
    val activeSlot: WeaponSlot = WeaponSlot.SECONDARY,
    val equippedWeapons: Map<WeaponSlot, WeaponInstance> = emptyMap(),
    val isReloading: Boolean = false,
    val reloadProgress: Float = 0f,
    val scopeLevel: Int = 0, // 0 = unscoped, 1 = zoom1, 2 = zoom2
    val isCrouching: Boolean = false,
    val dynamicSpreadRatio: Float = 0f, // 0f..1f for dynamic crosshair
    val hitMarkerAlpha: Float = 0f,
    val hitMarkerHeadshot: Boolean = false,
    val damageFlashAlpha: Float = 0f,
    val flashbangBlindAlpha: Float = 0f,
    val currentCallout: String = "Spawn",
    val canBuyNow: Boolean = true,
    val canPlantC4Now: Boolean = false,
    val canDefuseC4Now: Boolean = false,
    val bombActionProgress: Float = 0f, // 0f..1f while planting/defusing
    val roundBannerText: String? = null,
    val roundBannerTeam: TeamSide? = null,
    val smokeCarvedNotice: Boolean = false,
    val killFeed: List<KillFeedEntry> = emptyList(),
    val scoreboard: List<ScoreboardEntry> = emptyList(),
    val radarBlips: List<RadarBlip> = emptyList(),
    val radarSmokes: List<RadarSmokeZone> = emptyList(),
    val c4WorldPos: Pair<Float, Float>? = null,
    val fpsEstimate: Int = 60
)

package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.TacticalAudioEngine
import com.example.data.SettingsRepository
import com.example.engine.RenderFrameSnapshot
import com.example.engine.TacticalMatchEngine
import com.example.model.ArenaMapId
import com.example.model.BotDifficulty
import com.example.model.GameMode
import com.example.model.MatchHudState
import com.example.model.PlayerSettings
import com.example.model.TeamSide
import com.example.model.WeaponId
import com.example.model.WeaponSlot
import com.example.sensors.GyroAimController
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class LobbyTab {
    PLAY,
    ARMORY,
    SETTINGS
}

data class LobbyUiState(
    val activeTab: LobbyTab = LobbyTab.PLAY,
    val selectedMap: ArenaMapId = ArenaMapId.DUST_ARENA,
    val selectedMode: GameMode = GameMode.PREMIER_5V5,
    val selectedTeam: TeamSide = TeamSide.CT,
    val selectedDifficulty: BotDifficulty = BotDifficulty.MASTER_GUARDIAN,
    val inspectedWeapon: WeaponId = WeaponId.AK_47
)

class GameViewModel(application: Application) : AndroidViewModel(application) {

    private val settingsRepository = SettingsRepository(application)
    private val audioEngine = TacticalAudioEngine(application)
    val matchEngine = TacticalMatchEngine(audioEngine)

    private val gyroController = GyroAimController(application) { dYaw, dPitch ->
        if (hudState.value.isInMatch) {
            matchEngine.addLookDelta(dYaw, dPitch)
        }
    }

    val isGyroHardwareAvailable: Boolean = gyroController.isAvailable

    private val _lobbyState = MutableStateFlow(LobbyUiState())
    val lobbyState: StateFlow<LobbyUiState> = _lobbyState.asStateFlow()

    val settings: StateFlow<PlayerSettings> = settingsRepository.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = PlayerSettings()
    )

    val hudState: StateFlow<MatchHudState> = matchEngine.hudState

    private val _isBuyMenuOpen = MutableStateFlow(false)
    val isBuyMenuOpen: StateFlow<Boolean> = _isBuyMenuOpen.asStateFlow()

    private val _isScoreboardOpen = MutableStateFlow(false)
    val isScoreboardOpen: StateFlow<Boolean> = _isScoreboardOpen.asStateFlow()

    init {
        viewModelScope.launch {
            settings.collect { current ->
                matchEngine.updatePlayerSettings(current)
                gyroController.updateSensitivity(current.gyroSensitivity)
                syncGyroSensor(current, hudState.value.isInMatch)
            }
        }

        // 60Hz tactical simulation loop
        viewModelScope.launch {
            var lastTimeNs = System.nanoTime()
            var frameCounter = 0
            var fpsWindowMs = System.currentTimeMillis()
            var measuredFps = 60

            while (isActive) {
                val nowNs = System.nanoTime()
                val dtSec = ((nowNs - lastTimeNs) * 1e-9f).coerceIn(0.002f, 0.05f)
                lastTimeNs = nowNs
                val nowMs = System.currentTimeMillis()

                if (hudState.value.isInMatch) {
                    frameCounter++
                    if (nowMs - fpsWindowMs >= 1000L) {
                        measuredFps = frameCounter.coerceIn(30, 120)
                        frameCounter = 0
                        fpsWindowMs = nowMs
                    }
                    matchEngine.stepSimulation(dtSec, nowMs, measuredFps)
                }
                delay(16L)
            }
        }
    }

    private fun syncGyroSensor(currentSettings: PlayerSettings, inMatch: Boolean) {
        if (inMatch && currentSettings.gyroEnabled && gyroController.isAvailable) {
            gyroController.start(currentSettings.gyroSensitivity)
        } else {
            gyroController.stop()
        }
    }

    fun selectTab(tab: LobbyTab) {
        _lobbyState.value = _lobbyState.value.copy(activeTab = tab)
    }

    fun selectMap(mapId: ArenaMapId) {
        _lobbyState.value = _lobbyState.value.copy(selectedMap = mapId)
    }

    fun selectMode(mode: GameMode) {
        _lobbyState.value = _lobbyState.value.copy(selectedMode = mode)
    }

    fun selectTeam(team: TeamSide) {
        _lobbyState.value = _lobbyState.value.copy(selectedTeam = team)
    }

    fun selectDifficulty(difficulty: BotDifficulty) {
        _lobbyState.value = _lobbyState.value.copy(selectedDifficulty = difficulty)
    }

    fun selectInspectedWeapon(weaponId: WeaponId) {
        _lobbyState.value = _lobbyState.value.copy(inspectedWeapon = weaponId)
    }

    fun updateSettings(transform: (PlayerSettings) -> PlayerSettings) {
        viewModelScope.launch {
            settingsRepository.updateSettings(transform)
        }
    }

    fun deployMatch() {
        val lobby = _lobbyState.value
        _isBuyMenuOpen.value = false
        _isScoreboardOpen.value = false
        matchEngine.startNewMatch(
            mapId = lobby.selectedMap,
            mode = lobby.selectedMode,
            playerTeam = lobby.selectedTeam,
            botDifficulty = lobby.selectedDifficulty
        )
        syncGyroSensor(settings.value, inMatch = true)
    }

    fun leaveMatch() {
        _isBuyMenuOpen.value = false
        _isScoreboardOpen.value = false
        matchEngine.leaveMatch()
        gyroController.stop()
    }

    fun setBuyMenuOpen(open: Boolean) {
        _isBuyMenuOpen.value = open
        if (open) _isScoreboardOpen.value = false
    }

    fun setScoreboardOpen(open: Boolean) {
        _isScoreboardOpen.value = open
        if (open) _isBuyMenuOpen.value = false
    }

    fun onMoveJoystick(forward: Float, strafe: Float) {
        matchEngine.setMoveInput(forward, strafe)
    }

    fun onTouchLook(deltaXPx: Float, deltaYPx: Float) {
        val sens = settings.value.touchSensitivity
        val dYaw = deltaXPx * 0.16f * sens
        val dPitch = -deltaYPx * 0.14f * sens
        matchEngine.addLookDelta(dYaw, dPitch)
    }

    fun onFireHeld(held: Boolean) = matchEngine.setFireHeld(held)
    fun onBombActionHeld(held: Boolean) = matchEngine.setBombActionHeld(held)
    fun onJump() = matchEngine.jump()
    fun onToggleCrouch() = matchEngine.toggleCrouch()
    fun onCycleScope() = matchEngine.cycleScope()
    fun onReload() = matchEngine.reload()
    fun onInspectWeapon() = matchEngine.triggerInspect()
    fun onSelectSlot(slot: WeaponSlot) = matchEngine.selectSlot(slot)
    fun onBuyWeapon(weaponId: WeaponId) = matchEngine.buyWeapon(weaponId)
    fun onBuyArmor(withHelmet: Boolean) = matchEngine.buyArmor(withHelmet)
    fun onBuyDefuseKit() = matchEngine.buyDefuseKit()
    fun onRebuyPrevious() = matchEngine.rebuyPrevious()

    fun currentRenderSnapshot(): RenderFrameSnapshot = matchEngine.latestRenderSnapshot

    override fun onCleared() {
        super.onCleared()
        gyroController.stop()
    }
}
